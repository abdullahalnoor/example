<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Cron
Route::get('/cron', 'VisitorController@Cron'); 

//Payment IPN
Route::get('/ipnbchain', 'PaymentController@ipnBchain')->name('ipn.bchain');
Route::get('/ipnblockbtc', 'PaymentController@blockIpnBtc')->name('ipn.block.btc');
Route::get('/ipnblocklite', 'PaymentController@blockIpnLite')->name('ipn.block.lite');
Route::get('/ipnblockdog', 'PaymentController@blockIpnDog')->name('ipn.block.dog');
Route::post('/ipnpaypal', 'PaymentController@ipnpaypal')->name('ipn.paypal');
Route::post('/ipnperfect', 'PaymentController@ipnperfect')->name('ipn.perfect');
Route::post('/ipnstripe', 'PaymentController@ipnstripe')->name('ipn.stripe');
Route::post('/ipnskrill', 'PaymentController@skrillIPN')->name('ipn.skrill');
Route::post('/ipncoinpaybtc', 'PaymentController@ipnCoinPayBtc')->name('ipn.coinPay.btc');
Route::post('/ipncoinpayeth', 'PaymentController@ipnCoinPayEth')->name('ipn.coinPay.eth');
Route::post('/ipncoinpaybch', 'PaymentController@ipnCoinPayBch')->name('ipn.coinPay.bch');
Route::post('/ipncoinpaydash', 'PaymentController@ipnCoinPayDash')->name('ipn.coinPay.dash');
Route::post('/ipncoinpaydoge', 'PaymentController@ipnCoinPayDoge')->name('ipn.coinPay.doge');
Route::post('/ipncoinpayltc', 'PaymentController@ipnCoinPayLtc')->name('ipn.coinPay.ltc');
Route::post('/ipncoin', 'PaymentController@ipnCoin')->name('ipn.coinpay');
//Payment IPN



Route::get('/', 'VisitorController@index')->name('user.index'); 

Route::get('/404', function () {
    return view('404');
})->name('404');
Auth::routes();

//verification
Route::get('/verifiaction', 'VisitorController@verification')->name('user.verify');        
Route::post('/send-vcode', 'VisitorController@sendVcode')->name('user.send-vcode');        
Route::post('/email-verify', 'VisitorController@emailVerify')->name('user.email-verify');        
Route::post('/sms-verify', 'VisitorController@smsVerify')->name('user.sms-verify');        



//Password Reset
Route::get('/password-resetreq', 'VisitorController@resetEmail')->name('password.resetreq');        
Route::post('/password-sendemail', 'VisitorController@sendEmail')->name('password.sendemail');        
Route::get('/password-reset/{token}', 'VisitorController@resetForm')->name('password.resetform');        
Route::post('/reset-password', 'VisitorController@resetPassword')->name('password.resetpassword');
        

//User Routes
Route::group(['middleware' => ['auth','uverify']], function() {
    Route::group(['prefix' => 'home'], function () 
    {
        Route::get('/', 'HomeController@index')->name('home');        
        Route::get('/change-password', 'HomeController@changePasswordForm')->name('user.change-password');        
        Route::post('/change-password', 'HomeController@changePassword')->name('user.change-passwordpost');               
        Route::get('/transactions', 'HomeController@transactionLog')->name('user.transactions'); 
        Route::get('/manage-balance', 'HomeController@balance')->name('user.balance');               
        Route::post('/deposit-preview', 'HomeController@depositPreview')->name('deposit.preview');        
        Route::post('/deposit-confirm', 'PaymentController@depositConfirm')->name('deposit.confirm');        
        Route::post('/withdraw-post', 'HomeController@withdrawPost')->name('withdraw.post');        
        Route::post('/withdraw-post', 'HomeController@withdrawPost')->name('withdraw.post');
        
        Route::get('/wallets', 'HomeController@wallets')->name('user.wallets');
        Route::put('/withd-coin/{wallet}', 'HomeController@walletWithdraw')->name('user.walletwith');
        Route::get('/packages', 'HomeController@packages')->name('user.packages');
        Route::get('/lendings', 'HomeController@lendings')->name('user.lendings');
        Route::put('/lending/{package}', 'HomeController@lendPost')->name('user.lend');
        
        
    });
});

Route::group(['middleware' => ['auth:admin']], function() {
Route::prefix('admin')->group(function() {
    
    Route::get('/dashboard', 'AdminController@dashboard')->name('admin.dashboard');

    //Coin Lending
    Route::get('/coins', 'CoinController@coins')->name('admin.coins');
    Route::put('/coin-status/{coin}', 'CoinController@coinsStatus')->name('admin.coinstatus');
    
    //General Settings
    Route::get('/general', 'AdminController@general')->name('admin.general');
    Route::post('/general-update', 'AdminController@generalUpdate')->name('admin.gnlupdate');
    
    //Payment Gateway
    Route::get('/gateway', 'AdminController@gateway')->name('admin.gateway');
    Route::post('/gateway-craete', 'AdminController@gatewayCreate')->name('admin.gatecre');
    Route::put('/gateway-update/{gateway}', 'AdminController@gatewayUpdate')->name('admin.gateup');
    
    //Lending Package
    Route::get('/lendings', 'AdminController@lendings')->name('admin.lendings');
    Route::get('/packages', 'PackageController@index')->name('admin.package');
    Route::post('/package-craete', 'PackageController@store')->name('admin.packstore');
    Route::put('/package-update/{package}', 'PackageController@update')->name('admin.packup');
    
    //Logo-Icon
    Route::get('/logo-icon', 'AdminController@logoIcon')->name('admin.logo');
    Route::post('/logo-update', 'AdminController@logoUpdate')->name('admin.logoupdate');
    //Email-SMS
    Route::get('/email-sms', 'AdminController@emailSms')->name('admin.email');
    Route::post('/email-update', 'AdminController@emailUpdate')->name('admin.emailup');

    //User Management
    Route::get('/users', 'AdminController@userIndex')->name('admin.users');
    Route::post('/user-search', 'AdminController@userSearch')->name('admin.search-users');
    Route::get('/user/{user}', 'AdminController@singleUser')->name('admin.user-single');
    Route::get('/user-banned', 'AdminController@bannedUser')->name('admin.user-ban');
    Route::get('/mail/{user}', 'AdminController@email')->name('admin.user-email');
    Route::post('/sendmail', 'AdminController@sendemail')->name('admin.send-email');
    Route::put('/user/pass-change/{user}', 'AdminController@userPasschange')->name('admin.user-pass');
    Route::put('/user/status/{user}', 'AdminController@statupdate')->name('admin.user-status');
    Route::get('/broadcast', 'AdminController@broadcast')->name('admin.broadcast');
    Route::post('/broadcast/email', 'AdminController@broadcastemail')->name('admin.broadcast-email');
    Route::get('/deposits', 'AdminController@deposits')->name('admin.deposits');
    Route::put('/deposit-approve/{depo}', 'AdminController@depoApprove')->name('admin.depo-approve');
    Route::put('/deposit-cancel/{depo}', 'AdminController@depoCancel')->name('admin.depo-cancel');
    Route::get('/withdraw-request', 'AdminController@withdrawRequest')->name('admin.withdraw-request');
    Route::get('/withdraw-log', 'AdminController@withdrawLog')->name('admin.withdraw-log');
    Route::put('/withdraw-approve/{withdraw}', 'AdminController@withdrawApprove')->name('admin.withdraw-approve');
    Route::put('/withdraw-cancel/{withdraw}', 'AdminController@withdrawCancel')->name('admin.withdraw-cancel');
    
        
    //Password Change
    Route::get('/change-password', 'AdminController@changePassword')->name('admin.change-password');
    Route::post('/password-update', 'AdminController@updatePassword')->name('admin.password-update');

    //Register New Admin
    Route::get('/new-admin', 'AdminController@newAdmin')->name('admin.new-admin');
    Route::get('/list-admin', 'AdminController@listAdmin')->name('admin.list-admin');
    Route::post('/create-admin', 'AdminController@createAdmin')->name('admin.create-admin');

     //Slider Content
     Route::get('/slider-section', 'FrontendController@sliderSection')->name('admin.slidersection');
     Route::post('/slider-store', 'FrontendController@sliderStore')->name('admin.slide-store');
     Route::put('/slide-update/{slide}', 'FrontendController@sliderUpdate')->name('admin.slide-update');
     Route::put('/slide-delete/{slide}', 'FrontendController@sliderDestroy')->name('admin.slide-delete');
     
     //Social Content
     Route::get('/social-section', 'FrontendController@socialSection')->name('admin.socialsection');
     Route::post('/social-store', 'FrontendController@socialStore')->name('admin.social-store');
     Route::put('/social-update/{social}', 'FrontendController@socialUpdate')->name('admin.social-update');
     Route::put('/social-delete/{social}', 'FrontendController@socialDestroy')->name('admin.social-delete');
     
     //About Content
     Route::get('/about-section', 'FrontendController@aboutSection')->name('admin.aboutsection');
     Route::post('/about-update', 'FrontendController@aboutUpdate')->name('admin.about-update');
     
     //Footer Content
     Route::get('/footer-section', 'FrontendController@footerSection')->name('admin.footersection');
     Route::post('/footer-update', 'FrontendController@footerUpdate')->name('admin.footer-update');
  
        
    });
   });

    //Admin Auth
Route::prefix('admin')->group(function() {
  Route::get('/', 'AdminController@showLoginForm')->name('admin.login')->middleware('guest:admin');
  Route::post('/login', 'AdminController@login')->name('admin.loginpost')->middleware('guest:admin');
  Route::get('/register', 'AdminController@showRegistrationForm')->name('admin.register')->middleware('auth:admin');
  Route::post('/register-post', 'AdminController@register')->name('admin.registerpost')->middleware('auth:admin');
  Route::post('/logout', 'AdminController@logout')->name('admin.logout');
  
});

//Coin Insert-Update
Route::get('/coin-insert', 'CoinController@coininsert');
Route::get('/coin-cron', 'CoinController@coinPrice');

