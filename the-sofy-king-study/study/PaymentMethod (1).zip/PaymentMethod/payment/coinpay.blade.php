@extends('layouts.user')
@section('content')
<section class="get-in-touch gray-bg sec-pad" id="contact">
	<div class="thm-container" style="margin-top:20px;">
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="form-content">
					<div class="inner">
						<div class="title text-center">
							<h3>{{$page_title}}</h3>
							@include('layouts.error') 
						</div>
						
						<div class="panel panel-primary">
							<div class="panel-body text-center">

								<h5>{{$amon}} {{$gnl->cur}}<i class="fa fa-exchange"></i> 
									<i class="fa fa-bitcoin"></i>{{ $bcoin }}</h5>

								<b style="color: red;"> Minimum 3 Confirmation Required to Credited Your Account.<br/>(It May Take Upto 2 to 24 Hours)</b>
								<br/>
								<br/>
								<p>{!! $form !!}</p>
								<br>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

@endsection