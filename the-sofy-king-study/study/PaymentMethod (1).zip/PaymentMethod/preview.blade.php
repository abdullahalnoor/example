@extends('layouts.user')

@section('content')

<section class="get-in-touch gray-bg sec-pad" id="contact">
    
    <div class="thm-container" style="margin-top:5px;">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="form-content">
                    <div class="inner">
                        <div class="title text-center">
                            <h3>Deposit Preview</h3>
                            @include('layouts.error') 
                        </div><!-- /.title -->
                        <form  class="contact-form" method="POST" action="{{ route('deposit.confirm') }}">
                            @csrf
                            <input type="hidden" name="gateway" value="{{$gate->id}}"/>
                            <ul class="list-group text-center">
                                <li class="list-group-item"><img src="{{asset('assets/images/gateway')}}/{{$gate->id}}.jpg" style="max-width:100px; max-height:100px; margin:0 auto;"/></li>
                                <li class="list-group-item">Amount: <strong>{{$amount}} {{$gnl->cur}}</strong></li>
                                <li class="list-group-item">Charge: <strong>{{$charge}} {{$gnl->cur}}</strong></li>
                                <li class="list-group-item">Payable: <strong>{{$charge+$amount}} {{$gnl->cur}}</strong></li>
                            </ul>
                            
                            <div class="frm-grp">
                                <button type="submit">
                                    Pay Now
                                </button>
                            </div>
                        </form>
                    </div><!-- /.inner -->
                </div><!-- /.form-content -->
            </div><!-- /.col-md-5 -->
        </div><!-- /.row -->
    </div><!-- /.thm-container -->
</section><!-- /.get-in-touch -->
@endsection
