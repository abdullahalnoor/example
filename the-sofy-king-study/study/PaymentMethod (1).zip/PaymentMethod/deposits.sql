-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2018 at 07:39 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `betting`
--

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `gateway_id` int(11) DEFAULT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usd_amo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `btc_amo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `btc_wallet` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trx` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `try` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `user_id`, `gateway_id`, `amount`, `charge`, `usd_amo`, `btc_amo`, `btc_wallet`, `trx`, `status`, `try`, `created_at`, `updated_at`) VALUES
(1, 8, 502, '2000', '11', '2011', '0.26682058', '36L6VpJLtSftLPwTMfwqG2Ma1WTdyPocpV', 'DpYNX6VFu8NVCMoD', 0, 1, '2018-05-31 09:07:08', '2018-05-31 11:09:05'),
(2, 8, 502, '5000', '26', '62.825', '0.00834275', '3HXQn8QSm2TzSceHSUBU3GCzEBLaPpv6Gr', '7p3p1Qa1qHFFSgNF', 0, 1, '2018-05-31 09:13:31', '2018-05-31 11:09:05'),
(3, 8, 505, '5050', '127.77000000000001', '64.722125', '0.00857026', NULL, 'ZGj6vETXjJYNkYVF', 0, 0, '2018-05-31 09:39:28', '2018-05-31 09:39:28'),
(4, 8, 505, '5050', '127.77000000000001', '64.722125', '0.00857275', NULL, 'SjWhSMM62an72gVJ', 0, 0, '2018-05-31 09:45:54', '2018-05-31 09:45:54'),
(5, 8, 503, '5000', '50.4', '63.129999999999995', '0.52731373', '32bA3yjzE96wycC4PUkyERsqupvULJzYas', 'cxppvOirby0ZOiUI', 0, 1, '2018-05-31 09:46:06', '2018-05-31 11:12:02'),
(6, 8, 505, '5858', '148.1316', '75.076645', '0.00996409', NULL, 'ZLYgNvdFM1anb5RU', 0, 0, '2018-05-31 09:58:48', '2018-05-31 09:58:48'),
(7, 8, 505, '5858', '148.1316', '75.076645', '0.00995139', '32wKJHZh1TiAn7DpQq9wjKGfAnhMJXPWcd', 'JT43aISSJL6qSfdq', 0, 0, '2018-05-31 10:01:52', '2018-05-31 10:10:22'),
(8, 8, 506, '1000', '25.71', '12.821375', '0.02240735', '0x03876116aebb8915f0f5b7b3d71afdbdd0d8252b', 'OGedpwoWL9oXZ3je', 0, 0, '2018-05-31 10:12:18', '2018-05-31 10:12:23'),
(9, 8, 506, '2500', '63.51', '32.043875', '0', NULL, '9k5btm05jgacyrpW', 0, 0, '2018-05-31 10:22:42', '2018-05-31 10:22:42'),
(10, 8, 103, '1000', '33', '12.9125', NULL, NULL, 'n5eyFr2K1NvSf35u', 0, 0, '2018-05-31 10:45:08', '2018-05-31 10:45:08'),
(11, 8, 103, '1000', '33', '12.9125', NULL, NULL, 'ZhVFznxYZP9TEoHh', 0, 0, '2018-05-31 10:47:12', '2018-05-31 10:47:12'),
(12, 8, 101, '100', '3.031', '1.2878875', NULL, NULL, 'r9upl8rWBxBeHx95', 0, 0, '2018-05-31 10:47:28', '2018-05-31 10:47:28'),
(13, 8, 101, '100', '3.031', '1.2878875', NULL, NULL, 'd3KUOwpN8Gqgdohy', 0, 0, '2018-05-31 10:49:12', '2018-05-31 10:49:12'),
(14, 8, 101, '100', '3.031', '1.2878875', NULL, NULL, '228iGUX92clRSrD0', 0, 0, '2018-05-31 10:50:09', '2018-05-31 10:50:09'),
(15, 8, 102, '1000', '12', '1012', NULL, NULL, 'QtFqopsgIXhi14LG', 0, 0, '2018-05-31 10:50:56', '2018-05-31 10:50:56'),
(16, 8, 101, '1000', '25.711', '12.8213875', NULL, NULL, 'zicI8UZFw9K0Wy73', 0, 0, '2018-05-31 10:53:14', '2018-05-31 10:53:14'),
(17, 8, 104, '100', '6', '106', NULL, NULL, 'TGTwWukEpmM5rW6e', 0, 0, '2018-05-31 10:56:53', '2018-05-31 10:56:53'),
(18, 8, 104, '100', '6', '1.325', NULL, NULL, 'yYp226Mp0TsL7y7D', 0, 0, '2018-05-31 10:57:57', '2018-05-31 10:57:57'),
(19, 8, 501, '100', '1.5', '1.26875', '0', NULL, 'JEdQ2azKrZoJYlJz', 0, 0, '2018-05-31 11:01:22', '2018-05-31 11:01:22'),
(20, 8, 502, '1000', '6', '12.575', '0.00166561', '39PLpGbPoZcGRzdSbRzjwvLjummq9Y1g8j', 'l6JepLuuhwfbGhTX', 0, 1, '2018-05-31 11:06:14', '2018-05-31 11:09:07'),
(21, 8, 503, '100', '1.4', '1.2675', '0.0106138', '3Ghi2Zxo2h1hypb3NoL7rTTJyaTB6TqYcP', '4dvGMcZrqgz1uzTT', 0, 1, '2018-05-31 11:10:29', '2018-05-31 11:12:03'),
(22, 8, 504, '111', '3.3072', '1.4288399999999999', '0', NULL, 'NxXyRHKxW8HzwXCU', 0, 0, '2018-05-31 11:15:14', '2018-05-31 11:15:14'),
(23, 8, 505, '1000', '25.71', '12.821375', '0.00169983', '3LtYJizbKcGJi4V4K1EMygqrRrLxVKGpHf', 'wf9Z7rnSrTYYqQ5w', 0, 0, '2018-05-31 11:33:21', '2018-05-31 11:33:25'),
(24, 8, 506, '1000', '25.71', '12.821375', '0', NULL, 'jzrea5dWXZQVo8Kn', 0, 0, '2018-05-31 11:37:49', '2018-05-31 11:37:49'),
(25, 8, 506, '1000', '25.71', '12.821375', '0.10729862', 'LcawJaNJLkzbLUsiH3LqCoLto7AKxGvK6v', 'mnPC8woxxiHZMJfU', 0, 0, '2018-05-31 11:38:51', '2018-05-31 11:38:55'),
(26, 8, 506, '1000', '25.71', '12.821375', '0.10730341', 'LQxdUewf8miRPG9iosdeqx6Pfx5CZKivvS', 'NWKjfziR0WdMl5kW', 0, 0, '2018-05-31 11:49:27', '2018-05-31 11:49:31'),
(27, 8, 507, '100', '3.0300000000000002', '1.287875', '0.00127257', '1GVFAiKY8ngj8LCwsjpqj4kwCPU2FfwEZ8', 'SbpaytfxG2KmaQEi', 0, 0, '2018-05-31 11:52:06', '2018-05-31 11:52:10'),
(28, 8, 508, '1000', '25.71', '12.821375', '0.04150350', 'Xy8MukTygU9goiJCWmQP9Nd445QRVsNsWf', 'Yq2Rw7olKQLB1Yjh', 0, 0, '2018-05-31 11:55:27', '2018-05-31 11:55:31'),
(29, 8, 509, '1000', '25.71', '12.821375', '3777.26172842', 'DC8tbVK9pPLLWStThBaTL1KcDy3RqmwE3W', 'rSXUhjm6JUQvXUyb', 0, 0, '2018-05-31 11:57:19', '2018-05-31 11:57:23'),
(30, 8, 510, '1000', '25.71', '12.821375', '0.10748063', 'LSqrGjbPRzbSV5jjFfFitu18MMsPvksdtQ', 'RhhPEDcfwmwg76aM', 0, 0, '2018-05-31 11:58:56', '2018-05-31 11:59:00'),
(31, 8, 513, '1000', '55', '13.1875', '0', NULL, '5tFDpes8LAGjnPK9', 0, 0, '2018-05-31 12:02:49', '2018-05-31 12:02:49'),
(32, 8, 507, '50', '1.77', '0.6471250000000001', '0.00056218', '17nF8AwHbhAYAiTaQASRdE5irmS4asuBfG', 'zgAj75FRhArfxUDG', 0, 0, '2018-06-07 06:22:43', '2018-06-07 06:22:47'),
(33, 8, 506, '100', '3.0300000000000002', '1.287875', '0', NULL, 'askcBbnhwTZ3mYm8', 0, 0, '2018-06-07 06:23:09', '2018-06-07 06:23:09'),
(34, 8, 103, '50', '4.5', '0.68125', NULL, NULL, 't1YICYhHgkXoYk1B', 0, 0, '2018-06-13 06:04:23', '2018-06-13 06:04:23'),
(35, 8, 505, '100', '3.0300000000000002', '1.287875', '0.00019631', '3LzSj7p2Z5CVa5xdUCHVJPUdFLE2R49gmz', 'i3RARq9l7rikn3vR', 0, 0, '2018-06-13 07:55:55', '2018-06-13 07:56:00'),
(36, 8, 507, '100', '3.0300000000000002', '1.287875', '0.00147416', '14JqXJKcwarAE3GNGH7JooUa8AEuH3C29p', 'J1rAvuPyMJJAPqcX', 0, 0, '2018-06-20 11:50:50', '2018-06-20 11:50:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
