<?php

namespace App\Http\Controllers;

use Auth;
use App\Coin;
use App\User;
use App\Wallet;
use App\Deposit;
use App\Gateway;
use App\Lending;
use App\Package;
use App\Withdraw;
use Carbon\Carbon;
use App\Transaction;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
       
    public function index()
    {
        $deposits = Deposit::where('user_id',Auth::id())->where('status',1)->orderBy('id','DESC')->take(25)->get();
        $withdraws = Withdraw::where('user_id',Auth::id())->where('status',1)->orderBy('id','DESC')->take(25)->get();
        $totdp = Deposit::where('user_id',Auth::id())->where('status',1)->sum('amount');
        $totwd = Withdraw::where('user_id',Auth::id())->where('status',1)->sum('amount');
        return view('user.home',compact('deposits','withdraws','totdp','totwd'));
    }
    

    public function balance()
    {
        $gates = Gateway::where('status',1)->get();
        return view('user.balance', compact('gates'));
    }

    

    public function depositPreview(Request $request)
    {
        $this->validate($request,
        [
        'amount' => 'required',
        'gateway' => 'required',
        ]);

        if($request->amount<=0)
        {
            return back()->with('alert', 'Invalid Amount');            
        }
        else
        {
            $gate = Gateway::findOrFail($request->gateway);
    
            if(isset($gate))
            {
                if($gate->minamo <= $request->amount || $gate->maxamo >= $request->amount)
                {
                    $charge = $gate->fixed_charge + ($request->amount*$gate->percent_charge/100);

                    $depo['user_id'] = Auth::id();
                    $depo['gateway_id'] = $gate->id;
                    $depo['amount'] = $request->amount;
                    $depo['charge'] = $charge;
                    $depo['usd_amo'] = $request->amount + $charge;
                    $depo['btc_amo'] = 0;
                    $depo['btc_wallet'] = "";
                    $depo['trx'] = str_random(16);
                    $depo['try'] = 0;
                    $depo['status'] = 0;
                    Deposit::create($depo);

                    Session::put('Track', $depo['trx']);

                    $amount = $request->amount;
        
                    return view('user.preview',compact('amount','gate','charge'));

                }
                else
                {
                    return back()->with('alert', 'Please Follow Deposit Limit');
                }
            }
            else
            {
                return back()->with('alert', 'Please Select Deposit gateway');
            }
        }
      
    }
        
    public function withdrawPost(Request $request)
    {
        $this->validate($request,
        [
        'amount' => 'required',
        'account' => 'required'
        ]);
        
        if($request->amount<=0)
        {
            return back()->with('alert', 'Invalid Amount');
        }
        else
        {
            $user = User::find(Auth::id());
            $user['balance'] = $user->balance - $request->amount;
            $user->update();
            
            $with['user_id'] = Auth::id();
            $with['amount'] = $request->amount;
            $with['account'] = $request->account;
            $with['status'] = 0;
            Withdraw::create($with);
    
            $tlog['user_id'] = $user->id;
            $tlog['amount'] = $request->amount;
            $tlog['balance'] = $user->balance;
            $tlog['type'] = 0;
            $tlog['details'] = 'Balance Withdarw';
            $tlog['trxid'] = str_random(16);
            Transaction::create($tlog);
    
            return back()->with('success', 'Withdraw Request Sent Successfully!');
        }
     
        
    }
    public function walletWithdraw(Request $request,Wallet $wallet)
    {
        $this->validate($request, ['amount' => 'required']);
        
        if($wallet->user_id == Auth::id())
        {
            if($request->amount <= 0 || $request->amount > $wallet->balance)
            {
                return back()->with('alert', 'Invalid Amount');
            }
            else
            {
                $user = User::find(Auth::id());
    
                $wallet->balance = $wallet->balance - $request->amount;
                $wallet->update(); 
    
                $wlog['user_id'] = $user->id;
                $wlog['amount'] = $request->amount;
                $wlog['balance'] = $wallet->balance;
                $wlog['type'] = 0;
                $wlog['coin_id'] = $wallet->coin_id;
                $wlog['details'] = 'Withdarw from '.$wallet->coin->name.' Wallet';
                $wlog['trxid'] = str_random(16);
                Transaction::create($wlog);
    
                $amount = $request->amount*$wallet->coin->price;
    
                $user['balance'] = $user->balance + $amount;
                $user->update();
            
                $tlog['user_id'] = $user->id;
                $tlog['amount'] = $amount;
                $tlog['balance'] = $user->balance;
                $tlog['type'] = 1;
                $tlog['details'] = 'Withdarw from '.$wallet->coin->name.' Wallet';
                $tlog['trxid'] = str_random(16);
                Transaction::create($tlog);
        
                return back()->with('success', 'Withdraw Successfull');
            }
        }    
        else
        {
            return back()->with('alert', 'Invalid Request');
        }
        
    }

     
}
    