<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// frontend part

Route::get('/','WelcomeController@index')->name('website');
Route::post('/search-product','WelcomeController@searchProduct')->name('search-product');
Route::get('/product-category/{id}','WelcomeController@viewProductCategory')->name('view-product-category');
Route::get('/product-detail/{id}','WelcomeController@viewProductDetail')->name('product-detail');
Route::get('/product-rate/{id}/{rate}','WelcomeController@rateProduct')->name('product-rate');
Route::post('/product-review','WelcomeController@reviewProduct')->name('product-review');




Auth::routes();

// user part






Route::group(['prefix'=>'user','middleware'=>'auth'],function(){

    Route::post('/user/logout', 'Auth\LoginController@userLogout')->name('user.logout');


    Route::get('/authorization', 'UserAuthorizationController@verifyUser')->name('user.authorization');

    Route::get('/mail-verification', 'UserAuthorizationController@userMailVerification')->name('user.mail-verification');
    Route::post('/mail-verification', 'UserAuthorizationController@verifyEmail')->name('user.mail-verification');

    Route::get('/sms-verification', 'UserAuthorizationController@userSmsVerification')->name('user.sms-verification');
    Route::post('/sms-verification', 'UserAuthorizationController@verifySMS')->name('user.sms-verification');


    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/change-password', 'HomeController@showChangePasswordForm')->name('user.change-password');
    Route::post('/change-password', 'HomeController@updatePassword')->name('user.change-password');

    //user verifiction
   


    Route::get('create-product','UserProductController@create')->name('user.product.create');
    Route::post('store-product','UserProductController@store')->name('user.product.store');
    Route::get('edit-product/{id}','UserProductController@edit')->name('user.product.edit');
    Route::post('update-product','UserProductController@update')->name('user.product.update');

    Route::get('products','UserProductManagementController@index')->name('user.products');
    Route::get('pending-products','UserProductManagementController@userPendingProducts')->name('user.pending-products');
    Route::get('active-products','UserProductManagementController@userActiveProducts')->name('user.active-products');
    Route::get('deactive-products','UserProductManagementController@userDeactiveProducts')->name('user.deactive-products');
    
});

// Admin Part

Route::get('/admin','AdminAuth\AdminLoginController@showLoginForm')->name('admin.login');
Route::post('/admin/login','AdminAuth\AdminLoginController@login')->name('admin.login.submit');


Route::group(['prefix'=>'admin','middleware'=>'auth:admin'],function(){

    Route::post('/logout','AdminAuth\AdminLoginController@logout')->name('admin.logout');
    Route::get('/dashboard','AdminHomeController@index')->name('admin.dashboard');
    Route::get('/change-password','AdminHomeController@showChangePasswordForm')->name('admin.change-password');
    Route::post('/change-password','AdminHomeController@updatePassword')->name('admin.change-password');
    

    // general,email & sms setting route part use in GeneralSettingController

    Route::get('/general-setting','GeneralSettingController@generalSetting')->name('admin.general-setting');
    Route::post('/general-setting','GeneralSettingController@updateGeneralInfo')->name('admin.update.general-setting');
    
    Route::get('/email-setting','GeneralSettingController@emailSetting')->name('admin.email-setting');
    Route::post('/email-setting','GeneralSettingController@updateEmailInfo')->name('admin.upadet.email-setting');
    
    Route::get('/sms-setting','GeneralSettingController@smsSetting')->name('admin.sms-setting');
    Route::post('/sms-setting','GeneralSettingController@updateSmsInfo')->name('admin.update.sms-setting');
 
    

    // contact,logo & icon route part use in 
        Route::get('contact','GeneralSettingController@editContact')->name('admin.contact');
        Route::post('upadte-contact','GeneralSettingController@upadteContact')->name('admin.contact.upadte');
        Route::get('logo','GeneralSettingController@viewLogo')->name('admin.logo');
        Route::post('update-logo','GeneralSettingController@updateLogo')->name('admin.logo.update');
        Route::get('banner','GeneralSettingController@editBanner')->name('admin.banner');
        Route::post('update-banner','GeneralSettingController@updateBanner')->name('admin.banner.update');
        Route::get('sub-banner','GeneralSettingController@editSubBanner')->name('admin.sub-banner');
        Route::post('update-sub-banner','GeneralSettingController@updateSubBanner')->name('admin.sub-banner.update');


    // menu route part use in MenuController
    Route::get('menu','MenuController@index')->name('admin.menu');
    Route::get('create-menu','MenuController@create')->name('admin.menu.create');    
    Route::post('create-menu','MenuController@store')->name('admin.menu.submit');    
    Route::get('edit-menu/{id}','MenuController@edit')->name('admin.menu.edit');    
    Route::post('update-menu','MenuController@update')->name('admin.menu.update');    
    Route::get('delete-menu/{id}','MenuController@delete')->name('admin.menu.delete'); 
       
    // category route part use in CategoryController
    Route::get('/categoy-header','GeneralSettingController@categoyHeader')->name('admin.categoy-header');
    Route::post('/categoy-header','GeneralSettingController@updateCategoyHeader')->name('admin.update.categoy-header');
    Route::get('category','CategoryController@index')->name('admin.category');
    Route::get('create-category','CategoryController@create')->name('admin.category.create');    
    Route::post('create-category','CategoryController@store')->name('admin.category.submit');    
    Route::get('edit-category/{id}','CategoryController@edit')->name('admin.category.edit');    
    Route::post('update-category','CategoryController@update')->name('admin.category.update');
    
    
     // news route part use in NewsController
     Route::get('/news-header','GeneralSettingController@newsHeader')->name('admin.news-header');
    Route::post('/news-header','GeneralSettingController@updateNewsHeader')->name('admin.update.news-header');
     Route::get('news','NewsController@index')->name('admin.news');
     Route::get('create-news','NewsController@create')->name('admin.news.create');    
     Route::post('create-news','NewsController@store')->name('admin.news.submit');    
     Route::get('edit-news/{id}','NewsController@edit')->name('admin.news.edit');    
     Route::post('update-news','NewsController@update')->name('admin.news.update');

     // location route part use in LocationController

     Route::get('location','LocationController@index')->name('admin.location');
     Route::get('create-location','LocationController@create')->name('admin.location.create');    
     Route::post('create-location','LocationController@store')->name('admin.location.submit');    
     Route::get('edit-location/{id}','LocationController@edit')->name('admin.location.edit');    
     Route::post('update-location','LocationController@update')->name('admin.location.update');

    // producr route part use in ProductController
    
    Route::get('create-product','ProductController@create')->name('admin.product.create');    
    Route::post('create-product','ProductController@store')->name('admin.product.submit');    
    Route::get('edit-product/{id}','ProductController@edit')->name('admin.product.edit');    
    Route::post('update-product','ProductController@update')->name('admin.product.update');   
    Route::get('delete-product/{id}','ProductController@delete')->name('admin.product.delete');  
    // producr manage route part use in ProductManagementController
    
    Route::get('all-products','ProductManagementController@allProducts')->name('admin.all-products');
    Route::get('pending-products','ProductManagementController@pendingProducts')->name('admin.pending-products');
    Route::get('active-products','ProductManagementController@activeProducts')->name('admin.active-products');
    Route::get('deactive-products','ProductManagementController@deactiveProducts')->name('admin.deactive-products');

    // user management route in use UserManagementController
    Route::get('users','UserManagementController@index')->name('admin.users');
    Route::post('search-users','UserManagementController@searchUsers')->name('admin.search-users');
    Route::get('user-detail/{id}','UserManagementController@userDetail')->name('admin.user.detail');
    Route::get('new-users','UserManagementController@newUsers')->name('admin.new-users');
    Route::get('active-users','UserManagementController@activeUserList')->name('admin.active-users');
    Route::post('search-active-users','UserManagementController@searchActiveUsers')->name('admin.search-active-users');
    Route::get('deactive-users','UserManagementController@deactiveUserList')->name('admin.deactive-users');
    Route::post('search-deactive-users','UserManagementController@searchDeactiveUsers')->name('admin.search-deactive-users');
    Route::get('user-posts/{id}/{type?}','UserManagementController@userPosts')->name('admin.user.posts');
     
});





