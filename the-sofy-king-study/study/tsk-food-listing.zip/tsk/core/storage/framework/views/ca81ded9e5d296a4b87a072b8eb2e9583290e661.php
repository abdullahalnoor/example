 <?php $__env->startSection('content'); ?>


<div class="page-content-wrapper">
    <div class="page-content">
        
        <h3 class="page-title"> User Dashboard

        </h3>
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i>
                        <span style="text-transform: capitalize">
                            <?php echo e($userStatistics['user']['name']); ?>'s Activities

                        </span>
                    </div>
                    <div class="panel-body ">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3>
                                            <i class="font-green-sharp fa fa-registered" title="Registered Date"></i>
                                            <br>
                                        </h3>
                                        <small>
                                            <?php echo e(date('d F Y', strtotime($userStatistics['user']['created_at']))); ?>

                                        </small>
                                    </div>
                                    <div class="icon">
                                        <?php if($userStatistics['user']['status'] == 1): ?>
                                        <a class="label label-success">
                                            <i class="fa fa-check"></i>
                                            Active
                                        </a>
                                        <?php else: ?>

                                        <a class="label label-danger">
                                            <i class="fa fa-times"></i>
                                            Blocked
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: 100%;" class="progress-bar progress-bar-success green-sharp">
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> Last Post </div>
                                        <div class="status-number" style="text-transform: lowercase">
                                            <?php echo e($userStatistics['userLastPro'] == null ?'No Post':$userStatistics['userLastPro']['created_at']->diffforhumans()); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-blue-sharp">
                                            <span data-counter="counterup" data-value="7800">
                                                <?php if($userStatistics['userPro']): ?> <?php echo e($userStatistics['userPendingPro']); ?> of <?php echo e($userStatistics['userPro']); ?> <?php else: ?>
                                                <i class="fa fa-search"></i>
                                                <?php endif; ?>
                                            </span>

                                        </h3>
                                        <small>PENDING PRODUCT</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-bar-chart" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e(round($userStatistics['totalAvg'])); ?>%;" class="progress-bar progress-bar-success blue-sharp">

                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> contribution </div>
                                        <div class="status-number"> <?php echo e(round($userStatistics['totalAvg'])); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-green-sharp">
                                            <span data-counter="counterup" data-value="7800">
                                                <?php if($userStatistics['userActivePro']): ?> <?php echo e($userStatistics['userActivePro']); ?> <?php else: ?>
                                                <i class="fa fa-search-plus"></i>
                                                <?php endif; ?>

                                            </span>
                                            <small class="font-green-sharp"></small>
                                        </h3>
                                        <small>Active PRODUCT </small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e(round($userStatistics['activeProAvg'])); ?>%;" class="progress-bar progress-bar-success green-sharp">
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> success </div>
                                        <div class="status-number"> <?php echo e(round($userStatistics['activeProAvg'])); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-red-haze">
                                            <span data-counter="counterup" data-value="1349">
                                                <?php if($userStatistics['userDeactivePro']): ?> <?php echo e($userStatistics['userDeactivePro']); ?> <?php else: ?>
                                                <i class="fa fa-search-minus"></i>
                                                <?php endif; ?>
                                            </span>
                                        </h3>
                                        <small>Deactive PRODUCT</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e(round($userStatistics['deactiveProAvg'])); ?>%" class="progress-bar progress-bar-success red-haze">
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> unsuccess </div>
                                        <div class="status-number"><?php echo e(round($userStatistics['deactiveProAvg'])); ?>%</div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>










    </div>
    <!-- END CONTENT BODY -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>