<!DOCTYPE html>

<html lang="en">
 
    <head>
        <meta charset="utf-8" />
        <title>User | <?php echo $__env->yieldContent('title'); ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <link href="<?php echo e(asset('assets/admin/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin/css/simple-line-icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin/css/jquery.fileupload.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- <link href="<?php echo e(asset('assets/admin/css/uniform.default.css')); ?>" rel="stylesheet" type="text/css" /> -->
        <link href="<?php echo e(asset('assets/admin/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin/css/components-rounded.min.css')); ?>" rel="stylesheet" id="style_components" type="text/css"
        />
        <link href="<?php echo e(asset('assets/admin/css/plugins.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin/css/layout.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin/css/darkblue.min.css')); ?>" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo e(asset('assets/admin/css/custom.min.css')); ?>" rel="stylesheet" type="text/css" />
      
      </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
        <?php echo $__env->make('user.includes._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="clearfix"> </div>
     
        <div class="page-container">
            <!-- BEGIN SIDEBAR -->
        <?php echo $__env->make('user.includes._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->yieldContent('content'); ?>
          
          
            
        </div>
        <?php echo $__env->make('user.includes._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <script src="<?php echo e(asset('assets/user/js/respond.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/excanvas.min.js')); ?>"></script> --}}
        <script src="<?php echo e(asset('assets/user/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/bootstrap.min.js')); ?>"></script>
        <!-- <script src="<?php echo e(asset('assets/user/js.cookie.min.js')); ?>"></script> -->
        <script src="<?php echo e(asset('assets/user/js/bootstrap-hover-dropdown.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.blockui.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.uniform.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/bootstrap-switch.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/app.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/layout.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/demo.min.js')); ?>"></script>
    <?php echo Toastr::render(); ?>

        
    </body>

</html>