 <?php $__env->startSection('title'); ?> Contact Email <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> CONTACT FORM </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-envelope"></i> Upadte Contact Info
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('admin.contact.upadte')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>
                                        <strong style="text-transform:uppercase">EMAIL </strong>
                                    </label>
                                    <input type="email" class="form-control" name="email" value="<?php echo e($contact->email); ?>">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>
                                        <strong style="text-transform:uppercase">PHONE </strong>
                                    </label>
                                    <input type="text" class="form-control" name="phone" value="<?php echo e($contact->phone); ?>">
                                </div>
                            </div>
                            <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Address </strong>
                                        </label>
                                        <input type="text" class="form-control" name="address" value="<?php echo e($contact->address); ?>">
                                    </div>
                                </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn blue btn-block ">UPDATE</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>