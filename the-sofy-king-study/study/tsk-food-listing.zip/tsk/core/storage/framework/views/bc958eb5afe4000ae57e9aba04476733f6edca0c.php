 <?php $__env->startSection('title'); ?>User List <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <h3 class="page-title uppercase bold"> User List </h3>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 pull-right">
                <div class="form-group">
                    <form class="navbar-form" method="POST" action="<?php echo e(route('admin.search-users')); ?>" >
                        <?php echo e(csrf_field()); ?>

                        <div class="input-group add-on">
                            <input class="form-control" placeholder="Email, Name" name="find_user" id="find_user" type="text">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <hr>
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i> Users List
                    </div>
                    <div class="panel-body ">
                        <?php if(count($users)): ?>
                        <table class="table table-responsive table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID#</th>
                                    <th> Name</th>
                                    <th> Email</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td>
                                        <?php if($item->status == 0): ?>
                                        <a class="label label-danger">Blocked</a>
                                        <?php else: ?>
                                        <a class="label label-success">Active</a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="btn btn-primary" href="<?php echo e(route('admin.user.detail',$item->id)); ?>">
                                            <i class="fa fa-user"></i> view Details
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <div class="alert alert-danger text-center">
                            <h1>
                                <strong>
                                    No Record Found...
                                </strong>
                            </h1>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="text-center">
                        <?php echo e($users->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>