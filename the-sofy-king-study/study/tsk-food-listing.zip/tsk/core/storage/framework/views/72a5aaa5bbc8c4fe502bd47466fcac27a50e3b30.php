<header class="header-area header-area-bg">
    <!-- navbar area start -->
    <nav class="navbar-area">
        <div class="container">
            <div class="row navbar-bg">
                <div class="col-md-10 col-sm-6 col-xs-6">
                    <div class="responsive-menu"></div>
                    <ul id="main-menu">
                        <li class="<?php echo e(Request::is('home') ? 'class=active' : ''); ?>">
                            <a href="<?php echo e(route('website')); ?>">Home</a>
                        </li>
                        <li>
                            <a href="#">Category</a>
                            <ul class="sub-menu">
                                <?php if($categories->all()): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('view-product-category',$item->id)); ?>"><?php echo e($item->name); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </li>
                        <?php if($menus->all()): ?>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="index.html"><?php echo e($item->name); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-md-2 col-sm-6 col-xs-6">
                    <div class="navbar-right-area">
                        <ul>
                            <li>
                                <a href="#">
                                    <i class="far fa-user-circle"></i>
                                    <?php if(auth()->guard()->guest()): ?> Account <?php else: ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?>
                                </a>
                                <ul class="sub-menu">
                                    <?php if(auth()->guard()->guest()): ?>
                                    <li data-toggle="modal" data-target="#myModal">
                                        <a href="" class="rgistration">Rgistration</a>
                                    </li>
                                    <li>
                                        <a href="" class="loginFrm">Login</a>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>" onclick="event.preventDefault();
                                                                 document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!--end nav bar-->

    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="header-left-content">
                    <span><?php echo e($data->banner_text); ?></span>
                    <h1><?php echo e($data->banner_title); ?></h1>
                    <a href="#" class="boxed-btn">get started now</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="header-right-content">
                    <div class="search-form">
                        <?php if($message = Session::has('message')): ?>
                        <?php ($message = 'Please.. fill up at least one field to search..'); ?>
                        <p style="color: red;">
                            <?php echo e($message); ?>

                        </p>
                        <?php endif; ?>
                        <form action="<?php echo e(route('search-product')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">

                                <input type="text" class="form-control" placeholder="search your favourite food  item !! " name="name" >
                            </div>
                            <div class="form-element">
                                <div class="location">
                                    <svg width="16px" height="20px">
                                        <i class="fas fa-map-marker-alt"></i>

                                </div>
                                <select name="location_id" class="form-control">
                                    <option  value="">--Select Location--</option>
                                    <?php if($locations->all()): ?>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                            </div>
                            <div class="form-element">
                                <div class="category">
                                    <i class="fas fa-angle-down"></i>
                                </div>
                                <select name="category_id" class="form-control">
                                    <option value="">--Select Category--</option>
                                    <?php if($categories->all()): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <input type="submit" value="Search Your Favourite Food">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- end header-area -->