 <?php $__env->startSection('title','| Home'); ?> <?php $__env->startSection('content'); ?>

<!-- popular-category start -->
<section class="popular-category">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="section-title">
                    <h2>
                        <strong><?php echo e($data->category_title); ?></strong>
                    </h2>
                    <p><?php echo e($data->category_text); ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <?php
            $i = 0;
            ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $category= $categories->where('id',$maxRow[$i]['id'])->first();
            ?>
                <div class="col-md-3 col-sm-4">
                    <div class="single-category-box">
                        <img src="<?php echo e($category['image']); ?>" alt="category images" style="height:300px;">
                        <div class="hover">
                            <span><?php echo e($maxRow[$i]['amount']); ?> </span>
                            <a href="<?php echo e(route('view-product-category',$category['id'])); ?>">
                                <h3><?php echo e($category['name']); ?></h3>
                            </a>
                         
                        </div>
                    </div>
                </div>
                <?php
                $i++;
                ?>
                <?php if($i >= 8): ?>
                <?php break; ?>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- popular-category end -->



<!-- news updates start -->
<section class="news-update-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="section-title">
                    <span class="bg-text"><?php echo e($data->news_watermark); ?></span>
                    <h2>
                        <strong><?php echo e($data->news_title); ?></strong>
                    </h2>
                    <p><?php echo e($data->news_text); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="single-news-item">
                    <div class="thumb thumb-1-bg" style="background-image:url(<?php echo e(asset($item->image)); ?>);"></div>
                    <div class="content">
                        <span class="meta-time">
                            <?php echo e(date('jS \ F Y',strtotime($item->created_at))); ?>

                        </span>
                        <br>
                        <a href="#">
                            <h4><?php echo e($item->title); ?></h4>
                        </a>
                        <p><?php echo e($item->description); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>
<!-- news updates end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>