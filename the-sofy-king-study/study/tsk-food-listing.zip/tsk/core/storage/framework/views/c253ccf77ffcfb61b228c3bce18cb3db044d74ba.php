<?php $__env->startSection('title'); ?> 
Email-Setting 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> SET EMAIL TEMPLATE </h3>
        <hr>

        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                            <i class="fa fa-bookmark"></i> Short Code 
                    </div>
                    <div class="panel-body">
                        <div class="table-scrollable">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th> CODE </th>
                                        <th> DESCRIPTION </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> 1 </td>
                                        <td>
                                            <pre>{{message}}</pre> </td>
                                        <td> Details Text From Script</td>
                                    </tr>
                                    <tr>
                                        <td> 1 </td>
                                        <td>
                                            <pre>{{name}}</pre> </td>
                                        <td> Users Name. Will Pull From Database and Use in EMAIL text
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-envelope"></i> Sent Email 
                    </div>
                    <div class="panel-body">
                        <form  action="<?php echo e(route('admin.upadet.email-setting')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                                <div class="col-md-12 col-md-12">
                                        <div class="form-group">
                                                <label>
                                                    <strong style="text-transform:uppercase">EMAIL SENT FROM</strong>
                                                </label>
                                                <input type="text" class="form-control" name="email" value="<?php echo e($generalSetting->email); ?>">
                                        </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                            <label>
                                                <strong style="text-transform:uppercase">EMAIL TEMPLATE</strong>
                                            </label>
                                            <div class="table-responsive">
                                                        <textarea name="message" class="form-control" rows="30"  id="area2"><?php echo $generalSetting->message; ?></textarea>
                                            </div>
                                            
                                        </div>
                                </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn blue btn-block">SEND</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/nicEdit.js')); ?>" ></script>
<script>
    bkLib.onDomLoaded(function () {
        new nicEditor({
            iconsPath: '<?php echo e(asset("assets/admin/img/nicEditorIcons.gif")); ?>'
        }).panelInstance('area2');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>