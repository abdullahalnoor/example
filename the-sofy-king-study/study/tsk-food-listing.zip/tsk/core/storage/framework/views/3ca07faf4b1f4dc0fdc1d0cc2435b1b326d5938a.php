 
<?php $__env->startSection('title','| '.$product->title); ?>
<?php $__env->startPush('style'); ?>
<link href="<?php echo e(asset('assets/frontend/css/magnific-popup.css')); ?>">
<link href="<?php echo e(asset('assets/frontend/css/owl.carousel.min.css')); ?>"> <?php $__env->stopPush(); ?> <?php $__env->startSection('content'); ?>
<section class="listing-details-area">


    <div class="container">
        <div class="row">
            <div class="col-md-8 col-sm-12">
                <div class="listing-details-wrapper">
                    <div class="thumb">
                        <img src="<?php echo e(asset($product->image)); ?>" class="img-responsive" style="width: 100%" alt="listing details image">
                    </div>
                    <div class="listing-title">
                        <span class="category">food &amp; restaurant</span>
                        <div class="content">
                            <h4><?php echo e($product->title); ?></h4>
                            <span class="location">
                                <i class="fas fa-map-marker-alt"></i> Zing Lo Pasta, Halim, Sub-Sandwich House</span>
                            <div class="listing-btn-group">
                                <a href="#" class="btn varify">
                                    <i class="far fa-check-circle"></i> verified listings</a>

                                <ul class="reviews">
                                    <?php if(auth()->guard()->guest()): ?> <?php for($i=1;$i
                                    <=5; $i++): ?> <li>
                                        <a class="loginFrm">
                                            <i class="<?php echo e($i <= $avgRate ?'fas':'far'); ?> fa-star"></i>
                                        </a>
                                        </li>
                                        <?php endfor; ?> 
                                        <?php else: ?> 
                                        <?php for($i=1;$i
                                        <=5; $i++): ?> <li>
                                            <a href="<?php echo e(route('product-rate',['id'=>$product->id,'rate'=>$i])); ?>">
                                                <i class="<?php echo e($i <= $avgRate ?'fas':'far'); ?> fa-star"></i>
                                            </a>
                                            </li>
                                            <?php endfor; ?> 
                                            <?php endif; ?>
                                            <li><?php echo e($totalVoter); ?> Raters</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="listing-details">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#overview" aria-controls="overview" role="tab" data-toggle="tab">Overview</a>
                            </li>
                            <li role="presentation">
                                <a href="#pricing" aria-controls="pricing" role="tab" data-toggle="tab">Pricing</a>
                            </li>
                            
                            <li role="presentation">
                                <a href="#review" aria-controls="review" role="tab" data-toggle="tab">Reviews</a>
                            </li>
                           
                        </ul>
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="overview">
                                <div class="overvew-content">
                                    <?php echo e($product->description); ?>

                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="pricing">
                                <div class="pricing-content">
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil, sed. Consequatur odit,
                                        praesentium velit molestias, modi esse harum nemo facilis atque quos quasi, quidem
                                        libero sequi quo commodi quae sint error pariatur iusto quod similique nihil odio
                                        fugiat hic! Libero repudiandae excepturi distinctio exercitationem quia eius ab rem
                                        eligendi illo.</p>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="review">
                                    <?php if($productReview->all()): ?>
                                    <?php $__currentLoopData = $productReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($user = $users->where('id',$item->user_id)->first()); ?>
                                   
                                <div class="comments-content">
                                    <div class="single-comment-wrappe">
                                        <div class="icon">
                                            <i class="fas fa-quote-left"></i>
                                        </div>
                                        <div class="content">
                                                    <p>
                                                        <?php echo e($item->comment); ?>

                                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <i class="<?php echo e($i <=$item->rate?'fas':'far'); ?> fa-star"></i>
                                                        <?php endfor; ?>
                                                    </p>
                                                   
                                            <span class="comment-author">- <?php echo e($user->name); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="sidebar-area-listing-details">
                    <div class="widget-area picture">
                        <div class="widget-body">
                            <img src="assets/img/sidebar-picture.jpg" alt="sidebar image">
                        </div>
                    </div>
                    <div class="widget-area reservation">
                        <div class="widget-title">
                            <h4>Make a Reservation</h4>
                        </div>
                        <div class="widget-body">
                            <a href="#" class="boxed-btn">check availavilty</a>
                        </div>
                    </div>
                    <div class="widget-area hosted-profile">
                        <div class="widget-body">
                            <div class="profile-content">
                                <div class="thumb">
                                    <img src="assets/img/host-profile.png" alt="hoster profile picture">
                                </div>
                                <div class="content">
                                    <span class="meta-author">Hosted By</span>
                                    <h4>Alexis Dracula</h4>
                                </div>
                            </div>
                            <div class="social-profile">
                                <ul>
                                    <li>
                                        <a href="#" class="boxed-btn facebook">connect with facebook</a>
                                    </li>
                                    <li>
                                        <a href="#" class="boxed-btn dribbble">connect with dribble</a>
                                    </li>
                                    <li>
                                        <a href="#" class="boxed-btn twitter">connect with twitter</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="widget-area bookmark">
                        <div class="widget-body">
                            <div class="bookmark-btn-group">
                                <a href="#" class="boxed-btn">
                                    <svg width="16px" height="18px">
                                        <path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M16.000,1.943 C16.000,0.890 15.124,0.027 14.041,0.004 L14.041,0.000 L1.988,0.000 C0.892,0.000 -0.000,0.865 -0.000,1.928 L-0.000,17.999 L6.204,13.990 L12.408,17.999 L12.408,7.913 L16.000,7.913 L16.000,1.943 ZM11.755,16.817 L6.204,13.230 L0.653,16.817 L0.653,1.928 C0.653,1.214 1.252,0.634 1.988,0.634 L12.443,0.634 C12.122,0.938 11.893,1.334 11.801,1.776 L11.801,1.777 C11.786,1.848 11.775,1.919 11.767,1.992 C11.759,2.065 11.755,2.140 11.755,2.216 L11.755,7.913 L11.755,16.817 ZM15.347,7.280 L12.408,7.280 L12.408,2.216 C12.408,2.108 12.420,2.004 12.441,1.902 C12.567,1.304 13.047,0.826 13.658,0.682 C13.670,0.679 13.680,0.674 13.692,0.672 C13.771,0.655 13.855,0.649 13.938,0.644 C13.965,0.642 13.991,0.636 14.018,0.636 C14.752,0.648 15.347,1.231 15.347,1.943 L15.347,7.280 Z"
                                        />
                                    </svg>
                                    bookmark this listings
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<section class="subscription-area">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-12">
                <div class="subscription-left">
                    <span>get update from our panel</span>
                    <h2>Subscribe For Updates</h2>
                </div>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="subscription-form">
                    <div class="form-wrappe">
                        <input type="text" placeholder="Enter Your Email Address ....">
                        <input type="submit" value="Subscribe">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('frontend.user-form.comment.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('js'); ?> 

<?php if(Session::has('commentModal')): ?>
<script type="text/javascript">
    $(function () {
        $('#commentModal').modal('show');
    });
</script>
<?php endif; ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master-two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>