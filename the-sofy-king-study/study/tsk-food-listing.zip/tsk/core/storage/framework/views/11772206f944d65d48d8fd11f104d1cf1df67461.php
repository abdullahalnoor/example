 
<?php $__env->startSection('title'); ?> 
Sms-Setting 
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('css'); ?> 
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> SET SMS API </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                            <i class="fa fa-bookmark"></i> Short Code 
                    </div>
                    <div class="panel-body">
                        <div class="table-scrollable">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th> CODE </th>
                                        <th> DESCRIPTION </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> 1 </td>
                                        <td>
                                            <pre>{{message}}</pre> </td>
                                        <td> Details Text From Script</td>
                                    </tr>
                                    <tr>
                                        <td> 1 </td>
                                        <td>
                                            <pre>{{name}}</pre> </td>
                                        <td> Users Name. Will Pull From Database and Use in EMAIL text
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-send"></i> SMS API
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('admin.update.sms-setting')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-12">
                                <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">SMS API</strong>
                                        </label>
                                        <textarea name="sms_api" class="form-control" rows="3" style="width:100%"><?php echo e($generalSetting->sms_api); ?></textarea>
                                    </div>
                                </div>

                                    <div class="col-md-12">
                                        <button type="submit" class="btn blue btn-block">SEND</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>