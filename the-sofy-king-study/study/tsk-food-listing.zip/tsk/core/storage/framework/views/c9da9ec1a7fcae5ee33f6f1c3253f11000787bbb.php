<!DOCTYPE html>
<html lang="en">

<head>
        <?php echo $__env->make('frontend.includes._css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   
    <?php echo $__env->yieldContent('css'); ?>
     <?php echo $__env->yieldPushContent('style'); ?>

</head>

<body>

    <?php echo $__env->make('frontend.includes._support', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

    <?php echo $__env->make('frontend.includes._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
        <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('frontend.includes._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="index">
        <!-- modal content will be display here.. -->
    </div>
    
    <?php echo $__env->make('frontend.includes._js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>