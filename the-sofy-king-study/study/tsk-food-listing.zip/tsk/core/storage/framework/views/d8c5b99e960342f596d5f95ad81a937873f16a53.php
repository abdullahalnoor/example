<script src="<?php echo e(asset('assets/frontend/js/jquery.js')); ?>"></script>

<script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery.slicknav.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>
<?php echo $__env->make('frontend.user-form.suspend-user.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(Session::has('suspendUser')): ?>
<script>
    $(function () {
        $("#loginFrm").modal('hide');
        $('#suspendUser').modal('show');
    });
</script>
<?php endif; ?> 
<script>
    
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
        $("#index").empty();
         $('.rgistration').on('click', function (e) {
            e.preventDefault();
            $.get("<?php echo e(route('register')); ?>", function (data) {
                $('#index').empty().append(data);
                $('#rgistrationFrm').modal('show');
            });
        });
        $('#index').on('submit', '#regFrmData', function (e) {
            e.preventDefault();
            var frmData = $(this).serialize();
            $.ajax({
                
                url:"<?php echo e(route('register')); ?>",
                type: "POST",
                data: frmData,
            })
            .done(function(data){
                $("#index #rgistrationFrm").modal('hide');
                $("#index").empty();
                window.location.href = '<?php echo e(route("home")); ?>';
            })
            .fail(function(error){
               var error =  error.responseJSON;
               var data = error.errors;
               console.log(data);
               $("#index #errName").empty().append(data.name);
               $("#index #errEmail").empty().append(data.email);
               $("#index #errPass").empty().append(data.password);
            });
        });
        $('.loginFrm').on('click',function(e){
            e.preventDefault();
            $.get("<?php echo e(route('login')); ?>",function(data){
                $("#index").empty().append(data);
                $("#loginFrm").modal('show');
            });
        });
       
        $("#index").on('submit','#loginFrmData',function(e){
            e.preventDefault();
            var frmData = $(this).serialize();
            $.ajax({
                url:"<?php echo e(route('login')); ?>",
                type:"POST",
                data:frmData,
            })
            .done(function(data){
                $("#index").empty();
                $("#index #loginFrm").modal('hide');
                 window.location.href = "<?php echo e(route('home')); ?>";
              
            })
            .fail(function(error){
                var errors = error.responseJSON;
                var data   = errors.errors;
                $("#index #errName").empty().append(data.name);
            });
        });
    });
    
</script>