 <?php $__env->startSection('title'); ?>User Info <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet" type="text/css" /> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold">
            <?php echo e($user->name); ?>'s Info

          

        </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i>
                        <span style="text-transform: capitalize">
                            <?php echo e($user->name); ?>'s Activities

                        </span>
                    </div>
                    <div class="panel-body ">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3>
                                            <i class="font-green-sharp fa fa-registered" title="Registered Date"></i>
                                            <br>
                                        </h3>
                                        <small>
                                            <?php echo e(date('d F Y', strtotime($user->created_at))); ?>

                                        </small>
                                    </div>
                                    <div class="icon">
                                        <?php if($user->status == 1): ?>
                                        <a class="label label-success">
                                            <i class="fa fa-check"></i>
                                            Active
                                        </a>
                                        <?php else: ?>

                                        <a class="label label-danger">
                                            <i class="fa fa-times"></i>
                                            Blocked
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: 100%;" class="progress-bar progress-bar-success green-sharp">
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> Last Post </div>
                                        <div class="status-number" style="text-transform: lowercase">
                                            <?php echo e($userLastPro == null ?'No Post':$userLastPro->created_at->diffforhumans()); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-blue-sharp">
                                            <span data-counter="counterup" data-value="7800">
                                                <?php if($userPro): ?>
                                                 <?php echo e($userPendingPro); ?> of <?php echo e($userPro); ?> 
                                                <?php else: ?>
                                                <i class="fa fa-search"></i>
                                                <?php endif; ?>
                                            </span>

                                        </h3>
                                        <small>PENDING PRODUCT</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-bar-chart" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e(round($totalAvg)); ?>%;" class="progress-bar progress-bar-success blue-sharp">

                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> contribution </div>
                                        <div class="status-number"> <?php echo e(round($totalAvg)); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-green-sharp">
                                            <span data-counter="counterup" data-value="7800">
                                                <?php if($userActivePro): ?>
                                                <?php echo e($userActivePro); ?>

                                                <?php else: ?>
                                                <i class="fa fa-search-plus"></i>
                                                <?php endif; ?>
                                                
                                            </span>
                                            <small class="font-green-sharp"></small>
                                        </h3>
                                        <small>Active PRODUCT </small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e(round($activeProAvg)); ?>%;" class="progress-bar progress-bar-success green-sharp">
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> success </div>
                                        <div class="status-number"> <?php echo e(round($activeProAvg)); ?>% </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-red-haze">
                                            <span data-counter="counterup" data-value="1349">
                                                <?php if($userDeactivePro): ?>
                                                <?php echo e($userDeactivePro); ?>

                                                <?php else: ?>
                                                <i class="fa fa-search-minus"></i>
                                                <?php endif; ?> 
                                            </span>
                                        </h3>
                                        <small>Deactive PRODUCT</small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span style="width: <?php echo e(round($deactiveProAvg)); ?>%;" class="progress-bar progress-bar-success red-haze">
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title"> unsuccess </div>
                                        <div class="status-number"><?php echo e(round($deactiveProAvg)); ?>%</div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-info"></i>
                        <span style="text-transform: capitalize">
                            View <?php echo e($user->name); ?>'s Posts
                        </span>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-3 col-md-3 col-xs-12">
                            <p>
                                <a href="<?php echo e(route('admin.user.posts',$user->id)); ?>" class="btn btn-block btn-primary">
                                    <i class="fa fa-info-circle"></i>
                                    View All Posts
                                </a>
                            </p>
                        </div>
                        <div class="col-lg-3 col-md-3 col-xs-12">
                            <p>
                                <a href="<?php echo e(route('admin.user.posts',['id'=>$user->id,'type'=>'pending'])); ?>" class="btn btn-block btn-info">
                                    <i class="fa fa-question"></i>
                                    View Pending Posts
                                </a>
                            </p>
                        </div>
                        <div class="col-lg-3 col-md-3 col-xs-12">
                            <p>
                                <a href="<?php echo e(route('admin.user.posts',['id'=>$user->id,'type'=>'active'])); ?>" class="btn btn-block btn-success">
                                    <i class="fa fa-check"></i>
                                    View Active Posts
                                </a>
                            </p>
                        </div>
                        <div class="col-lg-3 col-md-3 col-xs-12">
                            <p>
                                <a href="<?php echo e(route('admin.user.posts',['id'=>$user->id,'type'=>'deactive'])); ?>" class="btn btn-block btn-danger">
                                    <i class="fa fa-times"></i>
                                    View Deactive Posts
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-cog"></i> Profile Setting
                    </div>
                    <div class="panel-body">
                        <form action="#" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label style="width: 100%;">
                                                <strong style="text-transform: uppercase">Name </strong>

                                            </label>
                                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform: uppercase">Email</strong>
                                            </label>
                                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform: uppercase">gender </strong>
                                            </label>
                                            <input type="text" class="form-control" name="currency_symbol">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform: uppercase">Status</strong>
                                            </label>
                                            <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" data-on="ACTIVE"
                                                data-off="BLOCKED" name="status" <?php echo e($user->status == 1?'checked':''); ?> >
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform: uppercase">EMAIL VERIFICATION </strong>
                                            </label>
                                            <input type="checkbox" name="email_verification" data-toggle="toggle" data-onstyle="success" data-on="VERIFIED" data-off="NOT VERIFIED"
                                                data-offstyle="danger" data-width="100%">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform: uppercase">SMS VERIFICATION</strong>
                                            </label>
                                            <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-on="VERIFIED" data-off="NOT VERIFIED"
                                                data-width="100%" name="sms_verification">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <button type="submit" class="btn blue btn-block ">UPDATE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>