<?php $__env->startSection('title'); ?>
General-Setting 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet" type="text/css" /> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
  <div class="page-content">
    <h3 class="page-title uppercase bold"> GENERAL SETTING </h3>
    <hr>

    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <i class="fa fa-plus"></i> General Setting
          </div>
          <div class="panel-body">
            <form  action="<?php echo e(route('admin.update.general-setting')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

                    <div class="col-md-12">
                        <div class="form-group">
                            <strong style="text-transform: uppercase">website title</strong>
                          
                            <input type="text" class="form-control" name="website_title" value="<?php echo e($generalSetting->website_title); ?>">
                        </div>
                      </div>
                  <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label style="width: 100%;">
                                  <strong style="text-transform: uppercase">SITE BASE COLOR CODE </strong>
                                  (without #)
                                </label>
                                <input type="text" class="form-control" name="color_code" value="<?php echo e($generalSetting->color_code); ?>"  style="background: #<?php echo e($generalSetting->color_code); ?>;
                                ">
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">BASE CURRENCY TEXT </strong>
                                </label>
                                <input type="text" class="form-control" name="base_currency" value="<?php echo e($generalSetting->base_currency); ?>">
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">BASE CURRENCY SYMBOL </strong>
                                </label>
                                <input type="text" class="form-control" name="currency_symbol" value="<?php echo e($generalSetting->currency_symbol); ?>">
                            </div>
                          </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">registration</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="registration_status"
                                  <?php echo e($generalSetting->registration_status == 1?'checked':''); ?>>
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">EMAIL VERIFICATION </strong>
                                </label>
                                <input type="checkbox" name="email_verification" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%"
                                  <?php echo e($generalSetting->email_verification == 0?'checked':''); ?> >
                              </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">SMS VERIFICATION</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="sms_verification"
                                  <?php echo e($generalSetting->sms_verification == 0?'checked':''); ?> >
                            </div>
                          </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4 col-sm-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">DECIMAL AFTER POINT</strong>
                                </label>
                                <input type="text" class="form-control" name="number" maxlength="2" value="<?php echo e($generalSetting->number); ?>">
                            </div>
                          </div>
                          <div class="col-md-4 col-sm-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">EMAIL NOTIFICATION</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="email_notification"
                                  <?php echo e($generalSetting->email_notification == 1?'checked':''); ?>>
                              </div>
                                  
                          </div>
                          <div class="col-md-4 col-sm-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">SMS NOTIFICATION</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="sms_notification"
                                  <?php echo e($generalSetting->sms_notification == 1?'checked':''); ?>>
                              </div>
                          </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <button type="submit" class="btn blue btn-block ">UPDATE</button>
                  </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>