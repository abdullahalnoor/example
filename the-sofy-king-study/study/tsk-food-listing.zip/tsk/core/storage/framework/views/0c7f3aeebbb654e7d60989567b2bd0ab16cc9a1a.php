<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Admin | <?php echo $__env->yieldContent('title'); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('assets/admin/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/simple-line-icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/jquery.fileupload.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/components-rounded.min.css')); ?>" rel="stylesheet" id="style_components" type="text/css"
    />
    <link href="<?php echo e(asset('assets/admin/css/plugins.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/layout.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/darkblue.min.css')); ?>" rel="stylesheet" type="text/css" id="style_color" />
    <link href="<?php echo e(asset('assets/admin/css/custom.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <?php echo $__env->yieldContent('css'); ?>
</head>



<body class="page-header-fixed page-sidebar-closed-hide-logo">
    <?php echo $__env->make('admin.includes._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="clearfix"> </div>
    <div class="page-container">
        <?php echo $__env->make('admin.includes._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    

    <?php echo $__env->make('admin.includes._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script src="<?php echo e(asset('assets/admin/js/respond.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/excanvas.min.js')); ?>"></script> --}}
    <script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-hover-dropdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.blockui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.uniform.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-switch.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/layout.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/demo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/toastr.min.js')); ?>"></script>
    <?php echo Toastr::render(); ?>

    <?php echo $__env->yieldContent('js'); ?>
    
</body>

</html>