 <?php $__env->startSection('title'); ?>Users products  <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> Users products 
            <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-primary btn-md pull-right">
                <i class="fa fa-plus"></i> ADD NEW
            </a>
        </h3>
        <hr>
        <div class="row">
               
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i> Product List
                    </div>
                    <div class="panel-body ">
                            <?php if(count($products)): ?> 
                        <table class="table table-responsive table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID#</th>
                                    <th> Name</th>
                                    <th>Category Name</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->category->name); ?></td>
                                    <td>
                                            <?php if($item->status == 2): ?>
                                            <strong class="label label-primary">Pending</strong>
                                            <?php elseif($item->status == 1): ?>
                                            <strong class="label label-success">Active</strong>
                                            <?php else: ?>
                                            <strong class="label label-danger" >Deactive</strong>
                                            <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="btn purple btn-sm" href="<?php echo e(route('admin.product.edit',$item->id)); ?>">
                                            <i class="fa fa-edit"></i> EDIT
                                        </a>
                                        <a class="btn btn-danger btn-sm" onclick="return confirm('Are You Sure to Delete this ?')" href="<?php echo e(route('admin.product.delete',$item->id)); ?>">
                                            <i class="fa fa-times"></i> DELETE
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                        <?php else: ?>
                              <div class="alert alert-danger text-center">
                                <h1>
                                        <strong>
                                                No Record Found...
                                        </strong>
                                </h1>
                              </div>
                        <?php endif; ?>
                    </div>
                    <div class="text-center">
                        <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?> 

<?php $__env->startSection('js'); ?>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>