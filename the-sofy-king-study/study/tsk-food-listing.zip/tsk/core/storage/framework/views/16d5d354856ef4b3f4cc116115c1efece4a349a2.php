<nav class="navbar-area">
    <div class="container">
        <div class="row navbar-bg">
            <div class="col-md-10 col-sm-6 col-xs-6">
                <div class="responsive-menu"></div>
                <ul id="main-menu">
                    <li class="<?php echo e(Request::is('home') ? 'class=active' : ''); ?>" >
                        <a href="<?php echo e(route('website')); ?>">Home</a>
                    </li>
                    <li>
                        <a href="#">Category</a>
                        <ul class="sub-menu">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('view-product-category',$item->id)); ?>"><?php echo e($item->name); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>    
                    </li>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="index.html"><?php echo e($item->name); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </ul>
            </div>
            <div class="col-md-2 col-sm-6 col-xs-6">
                <div class="navbar-right-area">
                    <ul>
                        <li>
                            <a href="#">
                                <i class="far fa-user-circle"></i>
                                <?php if(auth()->guard()->guest()): ?>
                                Account
                                <?php else: ?>
                                <?php echo e(Auth::user()->name); ?>

                                <?php endif; ?>
                            </a>
                                <ul class="sub-menu">
                                    <?php if(auth()->guard()->guest()): ?>
                                    <li data-toggle="modal" data-target="#myModal">
                                            <a href="" id="rgistration">Rgistration</a>
                                        </li>
                                        <li>
                                            <a href="" id="login">Login</a>
                                        </li>
                                    <?php else: ?>
                                    <li>
                                            <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Logout')); ?>

                                            </a>
                                            <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                    <?php endif; ?>    
                                    </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>