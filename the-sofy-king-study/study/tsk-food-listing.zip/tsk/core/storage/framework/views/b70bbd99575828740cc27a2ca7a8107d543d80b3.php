<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Food Listing</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />


    <link href="<?php echo e(asset('assets/admin/css/components-rounded.min.css')); ?>" rel="stylesheet" id="style_components" type="text/css"
    />
    <link href="<?php echo e(asset('assets/admin/css/login.min.css')); ?>" rel="stylesheet" type="text/css" />
</head>

<body class=" login">
    <div class="menu-toggler sidebar-toggler"></div>
    <div class="logo">

    </div>
    <div class="content">
           
        <form class="login-form" action="<?php echo e(route('admin.login.submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <h3 class="form-title font-green">Sign In</h3>
            <div class="alert alert-danger display-hide">
                <button class="close" data-close="alert"></button>
               
            </div>
            <?php if($message = Session::has('message')): ?>
            <span class="text-center font-red-mint "> 
                <?php ($message == 1); ?>
                <?php ($message = 'Your Information is Incorrect...'); ?>
               <strong><?php echo e($message); ?></strong>
               <br>
            </span>
            <?php endif; ?>
            <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Username</label>
                <input class="form-control<?php echo e($errors->has('user_name') ? ' is-invalid' : ''); ?> form-control-solid placeholder-no-fix" type="text"
                    autocomplete="off" placeholder="Username" name="user_name"  /> 
            </div>
            <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Password</label>
                <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> form-control-solid placeholder-no-fix" type="password"
                    autocomplete="off" placeholder="Password" name="password" />
            </div>
            <div class="">
                <label class="rememberme check">
                    <input type="checkbox" name="remember" <?php echo e(old( 'remember') ? 'checked' : ''); ?> />Remember </label>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn green uppercase" style="width: 100%"> <?php echo e(__('Login')); ?></button>
            </div>
        </form>
    </div>
    <div class="copyright"> 2018 © <?php echo e($data->website_title); ?> </div>

</body>

</html>