 <?php $__env->startSection('title'); ?> Contact Email <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> CONTACT FORM </h3>
        <hr>





        <div class="row">

            <div class="col-md-6">
                
                <div class="portlet box blue">
                        <div class="portlet-title">
                                <div class="caption">
                                    <i class="fa fa-comments"></i>Contextual Rows </div>
                                <div class="tools">
                                    <a href="javascript:;" class="collapse"> </a>
                                    <a href="#portlet-config" data-toggle="modal" class="config"> </a>
                                    <a href="javascript:;" class="reload"> </a>
                                    <a href="javascript:;" class="remove"> </a>
                                </div>
                            </div>
                    <div class="portlet-body form">
                        <form class="form-horizontal" role="form" action="<?php echo e(route('admin.contact')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-body">
                                <div class="form-group">
                                    <div class="col-md-12 col-md-12">
                                        <label>
                                            <strong style="text-transform:uppercase">EMAIL </strong>
                                        </label>
                                        <input type="email" class="form-control input-lg" name="email" value="<?php echo e($contact->email); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12 col-md-12">
                                        <label>
                                            <strong style="text-transform:uppercase">PHONE </strong>
                                        </label>
                                        <input type="text" class="form-control input-lg" name="phone" value="<?php echo e($contact->phone); ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn blue btn-block btn-lg">UPDATE</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="portlet box green">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="fa fa-envelope"></i>Contact Info </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse"> </a>
                            <a href="#portlet-config" data-toggle="modal" class="config"> </a>
                            <a href="javascript:;" class="reload"> </a>
                            <a href="javascript:;" class="remove"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="table-scrollable">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Email</th>
                                        <th> Phone </th>
                                        <th> Last Updated </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> <?php echo e($contact->phone); ?> </td>
                                        <td> <?php echo e($contact->email); ?> </td>
                                        <td>
                                            <span class="label label-sm label-success"> <?php echo e($contact->updated_at->diffforhumans()); ?> </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>