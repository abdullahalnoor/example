<!-- Modal -->
<?php if($data->registration_status == 1): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="modal fade rgistrationFrm" id="rgistrationFrm" role="dialog" <?php if(Session::has( 'pop-msg')): ?> style="display: block;"
            <?php endif; ?>>
            <div class="modal-dialog">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        User Registration Form
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="panel-body">
                        <div class="card-content">
                            <div class="card-body">
                                <form method="POST" id="regFrmData" action="">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label for="name"><?php echo e(__('Name')); ?></label>

                                        <div class="">
                                            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>"
                                                autofocus>
                                            <span style="color:red;">
                                                <strong id="errName">

                                                </strong>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                        <div class="">
                                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>"
                                                required>
                                            <span style="color:red;">
                                                <strong id="errEmail">
                                                </strong>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="password" class=" col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                        <div class="">
                                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"
                                                required min="6">
                                            <span style="color:red;">
                                                <strong id="errPass">
                                                </strong>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>

                                        <div class="">
                                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" min="6" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div>
                                            <button type="submit" class="btn btn-primary btn-block">
                                                <?php echo e(__('Register')); ?>

                                            </button>
                                            <br>
                                            <button type="button" class=" btn-block btn btn-danger" data-dismiss="modal">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</div>
<?php else: ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="modal fade rgistrationFrm" id="rgistrationFrm" role="dialog" <?php if(Session::has( 'pop-msg')): ?> style="display: block;"
            <?php endif; ?>>
            <div class="modal-dialog">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        User Registration Form
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="panel-body">
                        <div class="card-content">
                            <div class="card-body">
                                <h1 style="text-decoration: line-through" class="text-center text-danger">
                                        User Registration Off
                                </h1>
                                    <div class="form-group">
                                        <div>
                                            <button  type="submit" class="btn btn-primary btn-block disabled">
                                                <?php echo e(__('Register')); ?>

                                            </button>
                                            <br>
                                            <button type="button" class=" btn-block btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</div>
<?php endif; ?>