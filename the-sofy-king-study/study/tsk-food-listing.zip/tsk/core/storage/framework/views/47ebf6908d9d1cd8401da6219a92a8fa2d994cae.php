 <?php $__env->startSection('title'); ?> Product FORM <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?>
 <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> Product FORM
            
        </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-plus"></i> Create New Product 
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('user.product.store')); ?>" enctype="multipart/form-data" method="post">
                            <?php echo e(csrf_field()); ?>

                           
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Product Name </strong>
                                        </label>
                                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Write Product Name.."> <?php if($errors->has('name')): ?>
                                        <span class="font-red-mint">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Select Category </strong>
                                        </label>
                                        <select name="category_id" class="form-control">
                                            <option>--Select One--</option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('category_id') == $item->id?'selected':''); ?>>
                                                <?php echo e($item ->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('category_id')): ?>
                                        <span class="font-red-mint">
                                            <strong><?php echo e($errors->first('category_id')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Product Title </strong>
                                        </label>
                                        <input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Write Product Title.."> <?php if($errors->has('title')): ?>
                                        <span class="font-red-mint">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Product Price </strong>
                                        </label>
                                        <div class="input-group">
                                                <input type="number" class="form-control" name="price" value="<?php echo e(old('price')); ?>">
                                                <span class="input-group-addon">
                                                   <?php echo e($data->currency_symbol); ?>

                                                </span>
                                            </div>
                                        
                                        <?php if($errors->has('price')): ?>
                                        <span class="font-red-mint">
                                            <strong><?php echo e($errors->first('price')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Product Image </strong>
                                        </label>
                                        <br>
                                                <span style="background-color:#337ab7; border-color:#337ab7" class="btn green fileinput-button">
                                                        <i class="fa fa-plus"></i>
                                                        <span> Add Image... </span>
                                                        <input type="file"  class="form-control" name="image" > 
                                                </span>
                                         <?php if($errors->has('image')): ?>
                                        <span class="font-red-mint">
                                            <strong><?php echo e($errors->first('image')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Product description</strong>
                                        </label>
                                        <div class="table-responsive">
                                            <textarea name="description" class="form-control" style="width: 100%;" rows="10" id="area2"><?php echo e(old('description')); ?></textarea> <?php if($errors->has('description')): ?>
                                            <span class="font-red-mint">
                                                <strong><?php echo e($errors->first('description')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn blue btn-block ">CREATE  </button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/user/js/bootstrap-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/nicEdit.js')); ?>" type="text/javascript"></script>
<script>
    bkLib.onDomLoaded(function () {
        new nicEditor({
            iconsPath: '<?php echo e(asset("assets/user/img/nicEditorIcons.gif")); ?>'
        }).panelInstance('area2');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>