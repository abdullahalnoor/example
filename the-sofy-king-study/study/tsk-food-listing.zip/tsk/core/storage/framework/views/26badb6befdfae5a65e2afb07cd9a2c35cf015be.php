<div class="page-footer">
    <div class="page-footer-inner"> 2018 &copy; 
                <strong style="text-transform: uppercase;"><?php echo e($data->website_title); ?></strong>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>