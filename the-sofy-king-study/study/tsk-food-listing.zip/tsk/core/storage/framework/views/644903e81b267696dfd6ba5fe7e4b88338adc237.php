<div class="page-footer">
  <div class="page-footer-inner" > 2018 &copy; 
          <Strong style="text-transform: uppercase;"> <?php echo e($data->website_title); ?></Strong>
  </div>
  <div class="scroll-to-top">
      <i class="icon-arrow-up"></i>
  </div>
</div>