<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap2-toggle.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/admin/css/stylesheet.css')); ?>" rel="stylesheet" type="text/css" />
    <style>
            .toggle.android { border-radius: 5px;}
            .toggle.android .toggle-handle { border-radius: 5px; height: 35px;}
          </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="page-content">
    <h3 class="page-title uppercase bold"> General Setting</h3>
    <hr>
    <div class="row">
      <div class="col-md-12">
            
          <div class="portlet light bordered">
              <div class="portlet-body form">
                <form class="form-horizontal" role="form">
                    <div class="form-body">
                        <div class="row">
                                <div class="form-group">
                                        <div class="col-md-12">
                                                <input type="text" class="form-control" placeholder="E-Wallet">
                                            </div>    
                                </div>    
                        </div>



                        <div class="row">
                            <div class="col-md-4">
       
                                <label>SITE BASE COLOR CODE (without #)</label>
                                    <input type="text" class="form-control" placeholder="">
     
                        </div>
                        <div class="col-md-4">
             
                                <label>BASE CURRENCY TEXT</label>
                                    <input type="text" class="form-control" placeholder="BDT">
                   
                        </div>
                        <div class="col-md-4">
 
                                <label>BASE CURRENCY SYMBOL</label>
                                    <input type="text" class="form-control" placeholder="TK.">
                    
                        </div>
                    </div>
                        
                       
                  <div class="col-md-4">
                        <div class="form-group">
                                <div class="checkbox">
                                        <label >
                                                <input type="checkbox" checked data-toggle="toggle" data-on="On" data-off="Off" data-onstyle="success" data-offstyle="danger"
                                                data-width="325px"
                                                data-height="35"
                                                data-style="android"
                                                >
                                        </label>
                                </div>
                           </div>
                  </div>
                       
                    <div class="form-actions">
                        <div class="row">
                            <div class="col-md-offset-3 col-md-9">
                                <button type="submit" class="btn green">Submit</button>
                                <button type="button" class="btn default">Cancel</button>
                            </div>
                        </div>
                    </div>
                </form>
              </div>
            </div>    
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/bootstrap2-toggle.min.js')); ?>" type="text/javascript"></script>
<script>
        $(function() {
          $('#toggle-two').bootstrapToggle({
            on: 'Enabled',
            off: 'Disabled'
          });
        })
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>