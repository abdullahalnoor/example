<?php $__env->startSection('title','| Search Result '); ?>
<?php $__env->startPush('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/magnific-popup.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/owl.carousel.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="listing-page-area">
    <div class="container">
      <br>
      <br>
        <div class="row">
               <?php if(is_array($products)): ?>
                     <?php if($product->all()): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(array_key_exists($product->category_id,$cats)): ?>
                               
                                    <div class="col-md-4 col-sm-6">
                                        <div class="single-listings-item">
                                            <div class="thumb">
                                                <img src="<?php echo e(asset($product['image'])); ?>" alt="listing images">
                                                <div class="tags">
                                                    <a href="<?php echo e(route('product-detail',$product['id'])); ?>"><?php echo e($product['name']); ?></a>
                                                </div>
                                                <div class="content">
                                                    <span class="rating">
                                                        <?php echo e(round($product->ratting->avg('rate'))); ?>

                                                    </span>
                                                    <div class="inner-content">
                                                        <div class="left-inner-content">
                                                            <a href="<?php echo e(route('product-detail',$product['id'])); ?>">
                                                                <h4>
                                                                    <?php echo e($product['title']); ?>

                                                                    <?php echo e($product['user_id']); ?>

                                                                </h4>
                                                            </a>
                                                            <span class="location">
                                                                    <?php echo e($product->location->name); ?>

                                                            </span>
                                                        </div>
                                                        <div class="icon">
                                                            <a href="#"><i class="far fa-heart"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php else: ?>
                    <div class="alert alert-danger text-center">
                            <h1>No Record Found...</h1>
                    </div>
                    <?php endif; ?>   
               <?php else: ?>
                    <?php if($products->all()): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-4 col-sm-6">
                            <div class="single-listings-item">
                                <div class="thumb">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="listing images">
                                    <div class="tags">
                                        <a href="<?php echo e(route('product-detail',$item->id)); ?>"><?php echo e($item->name); ?></a>
                                    </div>
                                    <div class="content">
                                        <span class="rating">
                                            <?php echo e(round($item->ratting->avg('rate'))); ?>

                                        </span>
                                        <div class="inner-content">
                                            <div class="left-inner-content">
                                                <a href="<?php echo e(route('product-detail',$item->id)); ?>"><h4><?php echo e($item->title); ?></h4></a>
                                                <span class="location">
                                                        <?php echo e($item->location->name); ?>

                                                </span>
                                            </div>
                                            <div class="icon">
                                                <a href="#"><i class="far fa-heart"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php else: ?>
                        <div class="alert alert-danger text-center">
                                <h1>No Record Found...</h1>
                        </div>
                    <?php endif; ?>  
             <?php endif; ?>  
                    
               
            
        <div class="row text-center">
            <div class="col-md-12">
                   
             
            </div>
        </div>
        </div>
    </div>
</section>
<!-- footer area start -->
<!-- subscription area start -->
<section class="subscription-area">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-12">
                <div class="subscription-left">
                    <span>get update from our panel</span>
                    <h2>Subscribe For Updates</h2>
                </div>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="subscription-form">
                    <div class="form-wrappe">
                        <input type="text" placeholder="Enter Your Email Address ....">
                        <input type="submit" value="Subscribe">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- subscription area end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master-two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>