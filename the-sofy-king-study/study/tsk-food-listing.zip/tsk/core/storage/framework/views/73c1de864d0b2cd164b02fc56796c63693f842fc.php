 <?php $__env->startSection('title'); ?> Menu Form <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> Menu Maneger
            <a href="<?php echo e(route('admin.menu.create')); ?>" class="btn btn-primary btn-md pull-right">
                <i class="fa fa-plus"></i> ADD NEW
            </a>
        </h3>
        <hr>
        <div class="row">


            <div class="col-md-12">
                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i> Menu List
                    </div>
                    <div class="panel-body ">
                            <?php if($menus->all()): ?>
                        <table class="table table-responsive table-striped table-bordered table-hover" >
                            <thead>
                                <tr>
                                    <th class="all">ID#</th>
                                    <th class="min-phone-l"> Name</th>
                                    <th class="min-tablet">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.menu.edit',$item->id)); ?>" class="btn purple btn-sm">
                                    
                                                <i class="fa fa-edit"></i> EDIT
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        <?php else: ?>
                       <div class="alert alert-danger text-center">
                        <h1>
                            <strong>No Record Found...</strong>
                        </h1>
                       </div>
                        <?php endif; ?>
                    </div>
                   <div class="text-center">
                       <?php echo e($menus->links()); ?>

                   </div>
                    
                </div>
                
                <!-- END EXAMPLE TABLE PORTLET-->
            </div>





        </div>

    </div>
</div>



<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>