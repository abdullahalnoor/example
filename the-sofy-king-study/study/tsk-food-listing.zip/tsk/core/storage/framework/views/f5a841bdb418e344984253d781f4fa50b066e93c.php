 <?php $__env->startSection('title'); ?> Category Header <?php $__env->stopSection(); ?> <?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> Update CATEGORY Header

        </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-plus"></i> Update Category Header
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('admin.update.news-header')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                          
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="news_watermark">
                                        <strong style="text-transform:uppercase">Watermark Text  </strong>
                                    </label>
                                    <input type="text" class="form-control" id="news_watermark" name="news_watermark" value="<?php echo e($newsHeader->news_watermark); ?>">
                                </div>
                            </div>
                            <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="news_title">
                                            <strong style="text-transform:uppercase">Header Title </strong>
                                        </label>
                                        <input type="text" class="form-control" id="news_title" name="news_title" value="<?php echo e($newsHeader->news_title); ?>">
                                    </div>
                                </div>
                            <div class="col-md-12">
                                <div class="form-group table-responsive">
                                    <label>
                                        <strong style="text-transform:uppercase">Header Short Text</strong>
                                    </label>
                                    <textarea name="news_text" class="form-control " rows="10" id="area2" style="width: 100%;"><?php echo e($newsHeader->news_text); ?></textarea>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block">UPDATAE</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?> <?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/nicEdit.js')); ?>"></script>
<script>
   

    bkLib.onDomLoaded(function () {
        new nicEditor({
            iconsPath: '<?php echo e(asset("assets/admin/img/nicEditorIcons.gif")); ?>'
        }).panelInstance('area2');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>