<footer class="footer-area">
  <div class="container">
      <div class="row">
          <div class="col-md-3 col-sm-6">
              <div class="widget-area">
                  <div class="widget-header">
                      <a href="index.html" class="logo">
                          <img src="<?php echo e(asset('assets/frontend/img/logo.png')); ?>" alt="logo image">
                      </a>
                  </div>
                  <div class="widget-body">
                      <p>All the content generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator
                          on the Internet. It uses a dictionary of over 200 Latin words.</p>
                      <p>Making this the first true generator on the Internet. It uses a dictionary.</p>
                      <a href="#" class="boxed-btn">
                          contact us now
                      </a>
                  </div>
              </div>
          </div>
          <div class="col-md-6 col-sm-12">
              <div class="row">
                  <div class="col-md-4 col-sm-6">
                      <div class="widget-area">
                          <div class="widget-header">
                              <span class="sub-title">quick access</span>
                              <h4>For Explore</h4>
                          </div>
                          <div class="widget-body">
                              <ul>
                                  <li>
                                      <a href="#">Home</a>
                                  </li>
                                  <li>
                                      <a href="#">WordPress Themes</a>
                                  </li>
                                  <li>
                                      <a href="#">ThemeForest Themes</a>
                                  </li>
                                  <li>
                                      <a href="#">Pricing</a>
                                  </li>
                                  <li>
                                      <a href="#">Support</a>
                                  </li>
                                  <li>
                                      <a href="#">Copyright</a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4 col-sm-6">
                      <div class="widget-area">
                          <div class="widget-header">
                              <span class="sub-title">learn about</span>
                              <h4>Our Company</h4>
                          </div>
                          <div class="widget-body">
                              <ul>
                                  <li>
                                      <a href="#">About us</a>
                                  </li>
                                  <li>
                                      <a href="#">Blog</a>
                                  </li>
                                  <li>
                                      <a href="#">Services</a>
                                  </li>
                                  <li>
                                      <a href="#">Affiliate Program</a>
                                  </li>
                                  <li>
                                      <a href="#">Legal &amp; Policy</a>
                                  </li>
                                  <li>
                                      <a href="#">Contact Us</a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4 col-sm-6">
                      <div class="widget-area">
                          <div class="widget-header empty-title"></div>
                          <div class="widget-body">
                              <ul>
                                  <li>
                                      <a href="#">Listing</a>
                                  </li>
                                  <li>
                                      <a href="#">Directory</a>
                                  </li>
                                  <li>
                                      <a href="#">Our Partners</a>
                                  </li>
                                  <li>
                                      <a href="#">How It Works</a>
                                  </li>
                                  <li>
                                      <a href="#">My Account</a>
                                  </li>
                                  <li>
                                      <a href="#">Signup</a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-md-3 col-sm-6">
              <div class="widget-area">
                  <div class="widget-header">
                      <span class="sub-title">on the</span>
                      <h4>Blog Feeds</h4>
                  </div>
                  <div class="widget-body">
                      <ul>
                          <li>
                              <a href="#">Speed Up WordPress</a>
                          </li>
                          <li>
                              <a href="#">Optimize images in WordPress</a>
                          </li>
                          <li>
                              <a href="#">WordPress child themes guide</a>
                          </li>
                          <li>
                              <a href="#">Improve your slider </a>
                          </li>
                          <li>
                              <a href="#">Update your homepage</a>
                          </li>
                          <li>
                              <a href="#">Create new details pages</a>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
  </div>
</footer>