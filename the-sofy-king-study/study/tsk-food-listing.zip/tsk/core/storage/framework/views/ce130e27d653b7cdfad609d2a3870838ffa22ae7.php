<div class="container">
    <div class="row">
        <div class="col-md-7">
            <div class="header-left-content">
                <span>Explore top-rated attractions, activities and more things</span>
                <h1>Explore, Choose <span>&amp;</span> Enjoy</h1>
                <a href="#" class="boxed-btn">get started now</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="header-right-content">
                <div class="search-form">
                    <form action="index.html" method="post">
                        <div class="form-group">
                            
                            <input type="text" class="form-control" placeholder="What are you looking for?" id="name">
                        </div>
                        <div class="form-element">
                            <div class="location"><svg  width="16px" height="20px">
                                <path fill-rule="evenodd" fill="rgb(102, 102, 102)" d="M14.739,11.623 L9.188,19.993 L2.749,12.171 C0.359,9.486 0.434,4.867 2.919,2.297 C4.261,0.909 6.102,0.093 8.102,-0.001 C10.102,-0.094 12.022,0.547 13.508,1.803 C16.258,4.128 16.834,8.717 14.739,11.623 ZM12.984,2.345 C11.653,1.220 9.933,0.646 8.142,0.730 C6.350,0.813 4.702,1.545 3.499,2.788 C1.257,5.107 1.192,9.279 3.359,11.715 L9.118,18.710 L14.082,11.225 C15.983,8.588 15.466,4.444 12.984,2.345 ZM8.687,9.489 C7.180,9.560 5.891,8.470 5.815,7.061 C5.738,5.652 6.902,4.448 8.409,4.378 C9.916,4.307 11.205,5.397 11.281,6.806 C11.358,8.215 10.194,9.419 8.687,9.489 ZM8.449,5.108 C7.372,5.158 6.541,6.018 6.596,7.025 C6.650,8.031 7.571,8.809 8.647,8.759 C9.724,8.709 10.555,7.849 10.500,6.842 C10.446,5.836 9.525,5.057 8.449,5.108 Z"
                                />
                            </svg></div>
                                <select name="location" class="form-control" id="location">
                                    <option value="0">Select Location</option>
                                    <option value="1">Chittagonj</option>
                                    <option value="2">Noakhali</option>
                                    <option value="3">Khulna</option>
                                    <option value="4">Pabna</option>
                                    <option value="4">Dhaka</option>
                                </select>
                            
                        </div>
                        <div class="form-element">
                            <div class="category"><i class="fas fa-angle-down"></i></div>
                                <select name="category" class="form-control" id="category">
                                    <option value="0">All Categories </option>
                                    <option value="1">Resturant</option>
                                    <option value="2">Doctor</option>
                                    <option value="3">Book</option>
                                    <option value="4">Food </option>
                                    <option value="5">Hospital</option>
                                </select>
                            </div>
                        <input type="submit" value="enjoy your hobby">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>