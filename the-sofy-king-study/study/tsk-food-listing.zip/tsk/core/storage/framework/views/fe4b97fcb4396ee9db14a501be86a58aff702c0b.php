<div id="commentModal" class="modal fade" style="display: none;">
    <div class="modal-dialog modal-md">
            <div class="modal-dialog">
        <div class="panel panel-primary">
            <div class="panel-heading">Please.. Give Us Some Feedback </div>
            <form action="<?php echo e(route('product-review')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="panel-body">
                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                    <textarea class="form-control" name="comment"><?php if(!empty(Session::has('comment'))): ?><?php echo e(Session::get('comment')); ?><?php endif; ?></textarea>
                </div>
                <div class="panel panel-footer">
                    <button type="submit" href="" class="btn btn-info pull-right" >
                        Give Feedback
                    </button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('#myModal').modal('show');
    });
</script>