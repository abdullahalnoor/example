<div class="page-header navbar navbar-fixed-top">
    <div class="page-header-inner ">
        <div class="page-logo">
            <a href="<?php echo e(route('admin.dashboard')); ?>">
                <img src="<?php echo e(asset('assets/frontend/img/logo.png')); ?>" style="width: 100px;height: 50px" alt="Logo">
            </a>
            <div class="menu-toggler sidebar-toggler"> </div>
        </div>
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>        
        <div class="top-menu">
            <ul class="nav navbar-nav pull-right">
                <li class="dropdown dropdown-user">
                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                        <span class="username username-hide-on-mobile"> <?php echo e(Auth::user()->user_name); ?> </span>
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-default">
                        <li>
                            <a href="<?php echo e(route('admin.change-password')); ?>">
                                <i class="fa fa-cog"></i> Change Password </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.logout')); ?>"
                            onclick="event.preventDefault();
                                          document.getElementById('logout-form').submit();">
                            
                                <i class="fa fa-sign-out"></i>  <?php echo e(__('Logout')); ?>

                            </a>
                        </li>

                    </ul>
                </li>
            </ul>
            <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        <?php endif; ?>
        
    </div>
</div>