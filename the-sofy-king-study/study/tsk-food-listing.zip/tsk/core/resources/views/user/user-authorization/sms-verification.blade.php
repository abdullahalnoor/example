<!DOCTYPE html>

<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>User | Sms verification</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <meta content="" name="description" />
  <meta content="" name="author" />
  <link href="{{asset('assets/admin/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css" />
  <link href="{{asset('assets/admin/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
  

</head>

<body>
  <div class="container-fluid btn-primary">
    <div class="row" style="padding: 10px;">
      <div class="col-md-6 col-ms-6 col-xs-6">
          <img src="{{asset('assets/user/img/logo.png')}}" alt="logo" /> 
      </div>
      <div class="col-md-6 col-sm-6 col-xs-6 text-right">
        @guest
          <a href="" class="rgistration">Rgistration</a>
          <a href="" class="loginFrm">Login</a>
        @else
           <a class="btn btn-success">
            {{ Auth::user()->name}}
          </a>
          <a class="btn btn-success" href="{{ route('user.logout') }}" onclick="event.preventDefault();
                                                                      document.getElementById('logout-form').submit();">
            {{ __('Logout') }}
          </a>
          <form id="logout-form" action="{{ route('user.logout') }}" method="POST" style="display: none;">
            @csrf
          </form>
        @endguest
      </div>
    </div>
  </div>

  <br>
  <br>
  <br>
  <br>


  <div class="container">
    @if(Session::has('alert'))
    <div class="alert alert-danger">
      <h1>
        {{Session::get('alert')}}
      </h1>
    </div>
    @endif @if(Session::has('success'))
    <div class="alert alert-success">
      <h1>
        {{Session::get('success')}}
      </h1>
    </div>
    @endif
    <div class="row">
      <div class="col-md-12">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fa fa-phone"></i> send verification code
            </div>
            <div class="panel-body">
              <a href="{{route('user.sms-verification')}}" class="btn btn-primary btn-block">
                Sent SMS
              </a>

            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <i class="fa fa-code"></i> Insert verification code
            </div>
            <div class="panel-body">


              <form action="{{route('user.sms-verification')}}" method="POST">
                {{ csrf_field()}}
                <div class="form-group">
                  <label for="">verification code</label>
                  <input type="text" name="code" class="form-control"> @if($errors->has('code'))
                  <span style="color:red;">
                    {{ $errors->first('code') }}
                  </span>
                  @endif
                </div>

                <div class="form-group">
                  <input class="btn btn-primary btn-block" type="submit" value="Verify SMS">

                </div>
              </form>


            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <div class="navbar-fixed-bottom btn-primary">
    <div class="col-md-12 text-center" style="padding: 10px;"> 
        <span>
            &copy; {{$data->website_title}}
        </span>
    </div>
  </div>

</body>

</html>