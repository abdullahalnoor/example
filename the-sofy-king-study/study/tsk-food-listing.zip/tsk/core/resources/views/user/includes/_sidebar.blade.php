<div class="page-sidebar-wrapper">
    <div class="page-sidebar navbar-collapse collapse">
        <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200"
            style="padding-top: 20px">
            <li class="sidebar-toggler-wrapper hide">
                <div class="sidebar-toggler"> </div>
            </li>
            <li class="nav-item  @if( request()->path() == '/home'  ) active open @endif ">
                <a href="{{route('home')}}" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Dashboard</span>
                </a>
            </li>
           
            <li class="nav-item  ">
                <a href="#" class="nav-link nav-toggle">
                    <i class="fa fa-shopping-cart"></i>
                    <span class="title"> Product Management</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if(request()->path() == 'user/products') active open @endif ">
                        <a href="{{route('user.products')}}" class="nav-link ">
                            <i class="fa fa-shopping-cart"></i>
                            <span class="title">All Product</span>
                        </a>
                    </li>
                    <li class="nav-item @if(request()->path() == 'user/pending-products') active open @endif ">
                        <a href="{{route('user.pending-products')}}" class="nav-link ">
                            <i class="fa fa-question"></i>
                            <span class="title">Pending Product</span>
                        </a>
                    </li>
                    <li class="nav-item  @if(request()->path() == 'user/active-products') active open @endif  ">
                        <a href="{{route('user.active-products')}}" class="nav-link ">
                            <i class="fa fa-check"></i>
                            <span class="title">Active Product</span>
                        </a>
                    </li>
                    <li class="nav-item  @if(request()->path() == 'user/deactive-products') active open @endif  ">
                        <a href="{{route('user.deactive-products')}}" class="nav-link ">
                            <i class="fa fa-ban"></i>
                            <span class="title">Deactive Product</span>
                        </a>
                    </li>
                </ul>
            </li>
            
        </ul>
    </div>
</div>