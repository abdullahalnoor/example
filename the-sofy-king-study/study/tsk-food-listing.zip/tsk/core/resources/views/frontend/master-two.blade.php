<!DOCTYPE html>
<html lang="en">

<head>
        @include('frontend.includes._css') 
   
   
    @yield('css') 
    @stack('style')

</head>

<body>

    @include('frontend.includes._support') 
    @include('frontend.includes._header-two')
    
        @yield('content')

    @include('frontend.includes._footer')

    <div id="index">
        <!-- modal content will be display here.. -->
    </div>
    
    @include('frontend.includes._js')

  

    @yield('js')

</body>

</html>