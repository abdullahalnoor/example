@extends('frontend.master-two')
@section('title','| Search Result ')
@push('style')
<link rel="stylesheet" type="text/css" href="{{asset('assets/frontend/css/magnific-popup.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/frontend/css/owl.carousel.min.css')}}">
@endpush

@section('content')

<section class="listing-page-area">
    <div class="container">
      <br>
      <br>
        <div class="row">
               @if(is_array($products))
                     @if($product->all())
                        @foreach($products as $product)
                                @if(array_key_exists($product->category_id,$cats))
                               
                                    <div class="col-md-4 col-sm-6">
                                        <div class="single-listings-item">
                                            <div class="thumb">
                                                <img src="{{asset($product['image'])}}" alt="listing images">
                                                <div class="tags">
                                                    <a href="{{route('product-detail',$product['id'])}}">{{$product['name']}}</a>
                                                </div>
                                                <div class="content">
                                                    <span class="rating">
                                                        {{ round($product->ratting->avg('rate')) }}
                                                    </span>
                                                    <div class="inner-content">
                                                        <div class="left-inner-content">
                                                            <a href="{{route('product-detail',$product['id'])}}">
                                                                <h4>
                                                                    {{$product['title']}}
                                                                    {{$product['user_id']}}
                                                                </h4>
                                                            </a>
                                                            <span class="location">
                                                                    {{$product->location->name}}
                                                            </span>
                                                        </div>
                                                        <div class="icon">
                                                            <a href="#"><i class="far fa-heart"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif 
                        @endforeach 
                    @else
                    <div class="alert alert-danger text-center">
                            <h1>No Record Found...</h1>
                    </div>
                    @endif   
               @else
                    @if($products->all())
                        @foreach($products as $item)

                        <div class="col-md-4 col-sm-6">
                            <div class="single-listings-item">
                                <div class="thumb">
                                    <img src="{{asset($item->image)}}" alt="listing images">
                                    <div class="tags">
                                        <a href="{{route('product-detail',$item->id)}}">{{$item->name}}</a>
                                    </div>
                                    <div class="content">
                                        <span class="rating">
                                            {{ round($item->ratting->avg('rate')) }}
                                        </span>
                                        <div class="inner-content">
                                            <div class="left-inner-content">
                                                <a href="{{route('product-detail',$item->id)}}"><h4>{{$item->title}}</h4></a>
                                                <span class="location">
                                                        {{$item->location->name}}
                                                </span>
                                            </div>
                                            <div class="icon">
                                                <a href="#"><i class="far fa-heart"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        @endforeach 
                    @else
                        <div class="alert alert-danger text-center">
                                <h1>No Record Found...</h1>
                        </div>
                    @endif  
             @endif  
                    
               
            
        <div class="row text-center">
            <div class="col-md-12">
                   
             
            </div>
        </div>
        </div>
    </div>
</section>
<!-- footer area start -->
<!-- subscription area start -->
<section class="subscription-area">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-12">
                <div class="subscription-left">
                    <span>get update from our panel</span>
                    <h2>Subscribe For Updates</h2>
                </div>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="subscription-form">
                    <div class="form-wrappe">
                        <input type="text" placeholder="Enter Your Email Address ....">
                        <input type="submit" value="Subscribe">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- subscription area end -->

@endsection