<div id="suspendUser" class="modal fade" style="display: none;">
    <div class="modal-dialog modal-md">
            <div class="modal-dialog">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Sorry.. 
             </div>
             <div class="panel-body">
                <h4 class="text-danger" style="text-transform: capitalize">
                    you Do Not Have Permission To Access ...  request to fixed this problem
                </h4>
             </div>
             <div class="panel panel-footer">
                    <input type="submit" class="btn btn-info pull-right" value="Request to Fixed.." >
                       
                    
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
        </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('#myModal').modal('show');
    });
</script>