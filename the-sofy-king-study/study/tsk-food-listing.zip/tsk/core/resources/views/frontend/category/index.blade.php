@extends('frontend.master-two')
@section('title','| '.$category->name)
@push('style')
<link href="{{asset('assets/frontend/css/magnific-popup.css')}}">
<link href="{{asset('assets/frontend/css/owl.carousel.min.css')}}">
@endpush

@section('content')

<section class="listing-page-area">
    <div class="container">
      <br>
      <br>
      <h1>
      </h1>
        <div class="row">
            @foreach($products as $item)
            <div class="col-md-4 col-sm-6">
                <div class="single-listings-item">
                    <div class="thumb">
                        <img src="{{asset($item->image)}}" alt="listing images">
                        <div class="tags">
                            <a href="#">{{$item->name}}</a>
                        </div>
                        <div class="content">
                            <span class="rating">
                                {{ round($item->ratting->avg('rate')) }}
                            </span>
                            <div class="inner-content">
                                <div class="left-inner-content">
                                    <a href="{{route('product-detail',$item->id)}}"><h4>{{$item->title}}</h4></a>
                                    <span class="location">20/b, Parker island, united kingdom</span>
                                </div>
                                <div class="icon">
                                    <a href="#"><i class="far fa-heart"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           @endforeach 
        <div class="row text-center">
            <div class="col-md-12">
                    {{ $products->links() }}
             
            </div>
        </div>
    </div>
</section>
<!-- footer area start -->
<!-- subscription area start -->
<section class="subscription-area">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-12">
                <div class="subscription-left">
                    <span>get update from our panel</span>
                    <h2>Subscribe For Updates</h2>
                </div>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="subscription-form">
                    <div class="form-wrappe">
                        <input type="text" placeholder="Enter Your Email Address ....">
                        <input type="submit" value="Subscribe">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- subscription area end -->

@endsection