<header class="header-area header-area-bg">
    <!-- navbar area start -->
    <nav class="navbar-area">
        <div class="container">
            <div class="row navbar-bg">
                <div class="col-md-10 col-sm-6 col-xs-6">
                    <div class="responsive-menu"></div>
                    <ul id="main-menu">
                        <li class="{{ Request::is('home') ? 'class=active' : '' }}">
                            <a href="{{route('website')}}">Home</a>
                        </li>
                        <li>
                            <a href="#">Category</a>
                            <ul class="sub-menu">
                                @if($categories->all())
                                @foreach($categories as $item)
                                <li>
                                    <a href="{{route('view-product-category',$item->id)}}">{{$item->name}}</a>
                                </li>
                                @endforeach
                                @endif
                            </ul>
                        </li>
                        @if($menus->all())
                        @foreach($menu as $item)
                        <li>
                            <a href="index.html">{{$item->name}}</a>
                        </li>
                        @endforeach
                        @endif
                    </ul>
                </div>
                <div class="col-md-2 col-sm-6 col-xs-6">
                    <div class="navbar-right-area">
                        <ul>
                            <li>
                                <a href="#">
                                    <i class="far fa-user-circle"></i>
                                    @guest Account @else {{ Auth::user()->name }} @endguest
                                </a>
                                <ul class="sub-menu">
                                    @guest
                                    <li data-toggle="modal" data-target="#myModal">
                                        <a href="" class="rgistration">Rgistration</a>
                                    </li>
                                    <li>
                                        <a href="" class="loginFrm">Login</a>
                                    </li>
                                    @else
                                    <li>
                                        <a class="dropdown-item" href="{{ route('user.logout') }}" onclick="event.preventDefault();
                                                                 document.getElementById('logout-form').submit();">
                                            {{ __('Logout') }}
                                        </a>
                                        <form id="logout-form" action="{{ route('user.logout') }}" method="POST" style="display: none;">
                                            @csrf
                                        </form>
                                    </li>
                                    @endguest
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!--end nav bar-->

    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="header-left-content">
                    <span>{{$data->banner_text}}</span>
                    <h1>{{$data->banner_title}}</h1>
                    <a href="#" class="boxed-btn">get started now</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="header-right-content">
                    <div class="search-form">
                        @if($message = Session::has('message'))
                        @php($message = 'Please.. fill up at least one field to search..')
                        <p style="color: red;">
                            {{$message}}
                        </p>
                        @endif
                        <form action="{{route('search-product')}}" method="post">
                            {{csrf_field()}}
                            <div class="form-group">

                                <input type="text" class="form-control" placeholder="search your favourite food  item !! " name="name" >
                            </div>
                            <div class="form-element">
                                <div class="location">
                                    <svg width="16px" height="20px">
                                        <i class="fas fa-map-marker-alt"></i>

                                </div>
                                <select name="location_id" class="form-control">
                                    <option  value="">--Select Location--</option>
                                    @if($locations->all())
                                    @foreach($locations as $item)
                                    <option value="{{$item->id}}">{{$item->name}}</option>
                                    @endforeach
                                    @endif
                                </select>

                            </div>
                            <div class="form-element">
                                <div class="category">
                                    <i class="fas fa-angle-down"></i>
                                </div>
                                <select name="category_id" class="form-control">
                                    <option value="">--Select Category--</option>
                                    @if($categories->all())
                                    @foreach($categories  as $item)
                                    <option value="{{$item->id}}">{{$item->name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                            <input type="submit" value="Search Your Favourite Food">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- end header-area -->