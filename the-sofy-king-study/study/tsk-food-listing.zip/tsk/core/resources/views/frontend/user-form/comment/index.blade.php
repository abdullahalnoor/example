<div id="commentModal" class="modal fade" style="display: none;">
    <div class="modal-dialog modal-md">
            <div class="modal-dialog">
        <div class="panel panel-primary">
            <div class="panel-heading">Please.. Give Us Some Feedback </div>
            <form action="{{route('product-review')}}" method="POST">
                {{csrf_field()}}
                <div class="panel-body">
                    <input type="hidden" name="id" value="{{$product->id}}">
                    <textarea class="form-control" name="comment">@if(!empty(Session::has('comment'))){{Session::get('comment')}}@endif</textarea>
                </div>
                <div class="panel panel-footer">
                    <button type="submit" href="" class="btn btn-info pull-right" >
                        Give Feedback
                    </button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('#myModal').modal('show');
    });
</script>