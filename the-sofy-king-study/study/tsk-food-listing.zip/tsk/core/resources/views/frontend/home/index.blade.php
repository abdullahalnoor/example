@extends('frontend.master') @section('title','| Home') @section('content')

<!-- popular-category start -->
<section class="popular-category">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="section-title">
                    <h2>
                        <strong>{{$data->category_title}}</strong>
                    </h2>
                    <p>{{$data->category_text}}</p>
                </div>
            </div>
        </div>

        <div class="row">
            @php
            $i = 0;
            @endphp
            @foreach($categories as $cat)
            @php
            $category= $categories->where('id',$maxRow[$i]['id'])->first();
            @endphp
                <div class="col-md-3 col-sm-4">
                    <div class="single-category-box">
                        <img src="{{$category['image']}}" alt="category images" style="height:300px;">
                        <div class="hover">
                            <span>{{$maxRow[$i]['amount']}} </span>
                            <a href="{{route('view-product-category',$category['id'])}}">
                                <h3>{{$category['name']}}</h3>
                            </a>
                         
                        </div>
                    </div>
                </div>
                @php
                $i++;
                @endphp
                @if($i >= 8)
                @break
                @endif
        @endforeach
        </div>
    </div>
</section>
<!-- popular-category end -->



<!-- news updates start -->
<section class="news-update-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
                <div class="section-title">
                    <span class="bg-text">{{$data->news_watermark}}</span>
                    <h2>
                        <strong>{{$data->news_title}}</strong>
                    </h2>
                    <p>{{$data->news_text}}</p>
                </div>
            </div>
        </div>
        <div class="row">
            @foreach($news as $item)
            <div class="col-md-4 col-sm-6">
                <div class="single-news-item">
                    <div class="thumb thumb-1-bg" style="background-image:url({{asset($item->image)}});"></div>
                    <div class="content">
                        <span class="meta-time">
                            {{date('jS \ F Y',strtotime($item->created_at))}}
                        </span>
                        <br>
                        <a href="#">
                            <h4>{{$item->title}}</h4>
                        </a>
                        <p>{{$item->description}}</p>
                    </div>
                </div>
            </div>
            @endforeach


        </div>
    </div>
</section>
<!-- news updates end -->

@endsection