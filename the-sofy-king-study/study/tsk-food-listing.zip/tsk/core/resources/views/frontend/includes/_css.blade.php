<meta charset="UTF-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<script>window.Laravel = { csrfToken: '{{ csrf_token() }}' }</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="shortcut icon" href="{{asset('assets/frontend/img/icon.png')}}" type="image/x-icon">
<title> {{$data->website_title}}  @yield('title') </title>
<link rel="stylesheet" href="{{asset('assets/frontend/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/frontend/css/fontawesome-all.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/frontend/css/slicknav.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/frontend/css/jquery-ui.css')}}">
<link rel="stylesheet" href="{{asset('assets/frontend/css/style.css')}}">
<link rel="stylesheet" href="{{asset('assets/frontend/css/responsive.css')}}">