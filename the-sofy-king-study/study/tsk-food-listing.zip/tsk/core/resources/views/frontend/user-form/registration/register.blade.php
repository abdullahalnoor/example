<!-- Modal -->
@if($data->registration_status == 1)
<div class="container">
    <div class="row justify-content-center">
        <div class="modal fade rgistrationFrm" id="rgistrationFrm" role="dialog" @if (Session::has( 'pop-msg')) style="display: block;"
            @endif>
            <div class="modal-dialog">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        User Registration Form
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="panel-body">
                        <div class="card-content">
                            <div class="card-body">
                                <form method="POST" id="regFrmData" action="">
                                    @csrf

                                    <div class="form-group">
                                        <label for="name">{{ __('Name') }}</label>

                                        <div class="">
                                            <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}"
                                                autofocus>
                                            <span style="color:red;">
                                                <strong id="errName">

                                                </strong>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="email" class="col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                                        <div class="">
                                            <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}"
                                                required>
                                            <span style="color:red;">
                                                <strong id="errEmail">
                                                </strong>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="password" class=" col-form-label text-md-right">{{ __('Password') }}</label>

                                        <div class="">
                                            <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password"
                                                required min="6">
                                            <span style="color:red;">
                                                <strong id="errPass">
                                                </strong>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="password-confirm">{{ __('Confirm Password') }}</label>

                                        <div class="">
                                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" min="6" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div>
                                            <button type="submit" class="btn btn-primary btn-block">
                                                {{ __('Register') }}
                                            </button>
                                            <br>
                                            <button type="button" class=" btn-block btn btn-danger" data-dismiss="modal">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</div>
@else
<div class="container">
    <div class="row justify-content-center">
        <div class="modal fade rgistrationFrm" id="rgistrationFrm" role="dialog" @if (Session::has( 'pop-msg')) style="display: block;"
            @endif>
            <div class="modal-dialog">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        User Registration Form
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="panel-body">
                        <div class="card-content">
                            <div class="card-body">
                                <h1 style="text-decoration: line-through" class="text-center text-danger">
                                        User Registration Off
                                </h1>
                                    <div class="form-group">
                                        <div>
                                            <button  type="submit" class="btn btn-primary btn-block disabled">
                                                {{ __('Register') }}
                                            </button>
                                            <br>
                                            <button type="button" class=" btn-block btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</div>
@endif