@extends('admin.master') @section('title') Dashboard @endsection @section('content')
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> admin Dashboard </h3>
        <hr>


        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i>
                        <span style="text-transform: capitalize">
                            Users Statistics

                        </span>
                    </div>
                    <div class="panel-body ">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.users') }}">
                                <div class="dashboard-stat blue">
                                    <div class="visual">
                                        <i class="fa fa-globe"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-globe"></i>
                                            <span data-counter="counterup" data-value="1349">
                                                {{ $userStatistics['totalUsers'] }}
                                            </span>
                                        </div>
                                        <div class="desc"> Total Users</div>
                                    </div>
                                    <a class="more" href="{{ route('admin.users') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{route('admin.new-users')}}">
                                <div class="dashboard-stat purple">
                                    <div class="visual">
                                        <i class="fa fa-registered"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-registered"></i>
                                            <span data-counter="counterup" data-value="89">
                                                {{ $userStatistics['recentRegister'] }}
                                            </span>
                                        </div>
                                        <div class="desc">
                                            Last 7 Days 
                                        </div>
                                    </div>
                                    <a class="more" href="{{route('admin.new-users')}}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.active-users') }}">
                                <div class="dashboard-stat green">
                                    <div class="visual">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-check"></i>
                                            <span data-counter="counterup" data-value="549">
                                                {{ $userStatistics['activeUsers'] }}
                                            </span>
                                        </div>
                                        <div class="desc"> Active Users </div>
                                    </div>
                                    <a class="more" href="{{ route('admin.active-users') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.deactive-users') }}">
                                <div class="dashboard-stat red">
                                    <div class="visual">
                                        <i class="fa fa-times"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-times"></i>
                                            <span data-counter="counterup" data-value="12,5">
                                                {{ $userStatistics['deactiveUsers'] }}
                                            </span>
                                        </div>
                                        <div class="desc"> Deactive Users </div>
                                    </div>
                                    <a class="more" href="{{ route('admin.deactive-users') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i>
                        <span style="text-transform: capitalize">
                            Users Products Statistics

                        </span>
                    </div>
                    <div class="panel-body ">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.all-products') }}">
                                <div class="dashboard-stat blue">
                                    <div class="visual">
                                        <i class="fa fa-list"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-list"></i>
                                            <span data-counter="counterup" data-value="1349">
                                                {{ $userStatistics['totalPro'] }}
                                            </span>
                                        </div>
                                        <div class="desc"> Total Products</div>
                                    </div>
                                    <a class="more" href="{{ route('admin.all-products') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.pending-products') }}">
                                <div class="dashboard-stat purple">
                                    <div class="visual">
                                        <i class="fa fa-question"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-question"></i>
                                            <span data-counter="counterup" data-value="89">
                                                {{ $userStatistics['pendingrPro'] }}
                                            </span>
                                        </div>
                                        <div class="desc">
                                            Pending Products
                                        </div>
                                    </div>
                                    <a class="more" href="{{ route('admin.pending-products') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.active-products') }}">
                                <div class="dashboard-stat green">
                                    <div class="visual">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-check"></i>
                                            <span data-counter="counterup" data-value="549">
                                                {{ $userStatistics['activePro'] }}
                                            </span>
                                        </div>
                                        <div class="desc"> Active Products </div>
                                    </div>
                                    <a class="more" href="{{ route('admin.active-products') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <a href="{{ route('admin.deactive-products') }}">
                                <div class="dashboard-stat red">
                                    <div class="visual">
                                        <i class="fa fa-times"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <i class="fa fa-times"></i>
                                            <span data-counter="counterup" data-value="12,5">
                                                {{ $userStatistics['deactivePro'] }}
                                            </span>
                                        </div>
                                        <div class="desc"> Deactive Products </div>
                                    </div>
                                    <a class="more" href="{{ route('admin.deactive-products') }}"> View Details
                                        <i class="m-icon-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

@endsection