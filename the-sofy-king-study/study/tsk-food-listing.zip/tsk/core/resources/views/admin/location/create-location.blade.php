@extends('admin.master') @section('title') Add Location @endsection

@section('css')
<link href="{{asset('assets/admin/css/bootstrap-toggle.min.css')}}" rel="stylesheet" type="text/css" /> 

@endsection
@section('content')
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> Location FORM
        </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-plus"></i> Create New Location
                    </div>
                    <div class="panel-body">
                        <form action="{{route('admin.location.submit')}}" method="post" enctype="multipart/form-data">
                            {{ csrf_field()}}
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="name">
                                        <strong style="text-transform:uppercase">Location Name </strong>
                                    </label>
                                    <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>
                                        <strong style="text-transform: uppercase">activation status </strong>
                                    </label>
                                    <input type="checkbox" name="status" data-toggle="toggle" data-onstyle="success" data-on="Active" data-off="Deactive" data-offstyle="danger"
                                        data-width="100%">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block">CREATE</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

 @section('js')
<script src="{{asset('assets/admin/js/bootstrap-toggle.min.js')}}"></script>

@endsection