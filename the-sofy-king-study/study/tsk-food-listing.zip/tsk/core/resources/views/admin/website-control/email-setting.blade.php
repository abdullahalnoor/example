@extends('admin.master')
@section('title') 
Email-Setting 
@endsection
@section('css') @endsection @section('content')
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> SET EMAIL TEMPLATE </h3>
        <hr>

        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                            <i class="fa fa-bookmark"></i> Short Code 
                    </div>
                    <div class="panel-body">
                        <div class="table-scrollable">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th> CODE </th>
                                        <th> DESCRIPTION </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> 1 </td>
                                        <td>
                                            <pre>@{{message}}</pre> </td>
                                        <td> Details Text From Script</td>
                                    </tr>
                                    <tr>
                                        <td> 1 </td>
                                        <td>
                                            <pre>@{{name}}</pre> </td>
                                        <td> Users Name. Will Pull From Database and Use in EMAIL text
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-envelope"></i> Sent Email 
                    </div>
                    <div class="panel-body">
                        <form  action="{{route('admin.upadet.email-setting')}}" method="post">
                            {{ csrf_field()}}
                                <div class="col-md-12 col-md-12">
                                        <div class="form-group">
                                                <label>
                                                    <strong style="text-transform:uppercase">EMAIL SENT FROM</strong>
                                                </label>
                                                <input type="text" class="form-control" name="email" value="{{$generalSetting->email}}">
                                        </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                            <label>
                                                <strong style="text-transform:uppercase">EMAIL TEMPLATE</strong>
                                            </label>
                                            <div class="table-responsive">
                                                        <textarea name="message" class="form-control" rows="30"  id="area2">{!!$generalSetting->message!!}</textarea>
                                            </div>
                                            
                                        </div>
                                </div>
                                    <div class="col-md-12">
                                        <button type="submit" class="btn blue btn-block">SEND</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection @section('js')
<script src="{{asset('assets/admin/js/nicEdit.js')}}" ></script>
<script>
    bkLib.onDomLoaded(function () {
        new nicEditor({
            iconsPath: '{{asset("assets/admin/img/nicEditorIcons.gif")}}'
        }).panelInstance('area2');
    });
</script>
@endsection