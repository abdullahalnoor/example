@extends('admin.master')

@section('title')
General-Setting 
@endsection

@section('css')
<link href="{{asset('assets/admin/css/bootstrap-toggle.min.css')}}" rel="stylesheet" type="text/css" /> 
@endsection

@section('content')

<div class="page-content-wrapper">
  <div class="page-content">
    <h3 class="page-title uppercase bold"> GENERAL SETTING </h3>
    <hr>

    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <i class="fa fa-plus"></i> General Setting
          </div>
          <div class="panel-body">
            <form  action="{{route('admin.update.general-setting')}}" method="POST">
              {{ csrf_field() }}
                    <div class="col-md-12">
                        <div class="form-group">
                            <strong style="text-transform: uppercase">website title</strong>
                          
                            <input type="text" class="form-control" name="website_title" value="{{$generalSetting->website_title}}">
                        </div>
                      </div>
                  <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label style="width: 100%;">
                                  <strong style="text-transform: uppercase">SITE BASE COLOR CODE </strong>
                                  (without #)
                                </label>
                                <input type="text" class="form-control" name="color_code" value="{{ $generalSetting->color_code }}"  style="background: #{{ $generalSetting->color_code }};
                                ">
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">BASE CURRENCY TEXT </strong>
                                </label>
                                <input type="text" class="form-control" name="base_currency" value="{{ $generalSetting->base_currency}}">
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">BASE CURRENCY SYMBOL </strong>
                                </label>
                                <input type="text" class="form-control" name="currency_symbol" value="{{ $generalSetting->currency_symbol}}">
                            </div>
                          </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">registration</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="registration_status"
                                  {{ $generalSetting->registration_status == 1?'checked':'' }}>
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">EMAIL VERIFICATION </strong>
                                </label>
                                <input type="checkbox" name="email_verification" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%"
                                  {{ $generalSetting->email_verification == 0?'checked':'' }} >
                              </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">SMS VERIFICATION</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="sms_verification"
                                  {{ $generalSetting->sms_verification == 0?'checked':'' }} >
                            </div>
                          </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4 col-sm-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">DECIMAL AFTER POINT</strong>
                                </label>
                                <input type="text" class="form-control" name="number" maxlength="2" value="{{ $generalSetting->number}}">
                            </div>
                          </div>
                          <div class="col-md-4 col-sm-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">EMAIL NOTIFICATION</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="email_notification"
                                  {{ $generalSetting->email_notification == 1?'checked':''}}>
                              </div>
                                  
                          </div>
                          <div class="col-md-4 col-sm-4">
                            <div class="form-group">
                                <label>
                                  <strong style="text-transform: uppercase">SMS NOTIFICATION</strong>
                                </label>
                                <input type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" name="sms_notification"
                                  {{ $generalSetting->sms_notification == 1?'checked':'' }}>
                              </div>
                          </div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <button type="submit" class="btn blue btn-block ">UPDATE</button>
                  </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection @section('js')
<script src="{{asset('assets/admin/js/bootstrap-toggle.min.js')}}"></script>

@endsection