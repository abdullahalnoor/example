@extends('admin.master') @section('title') Update Food Info  @endsection @section('css')
<link href="{{asset('assets/admin/css/bootstrap-toggle.min.css')}}" rel="stylesheet" type="text/css" /> 
<style>
        .file {
            visibility: hidden;
            position: absolute;
        }
    </style>
@endsection @section('content')
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> Update Food Info 
           
        </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-plus"></i> Update Food Info 
                    </div>
                    <div class="panel-body">
                        <form action="{{route('admin.product.update')}}" enctype="multipart/form-data" method="post">
                            {{ csrf_field()}}
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Food Name </strong>
                                        </label>
                                        <input type="text" class="form-control" name="name" value="{{$product->name}}"> 
                                        <input type="hidden" name="id" value="{{$product->id}}"> 
                                    </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform:uppercase"> Price </strong>
                                            </label>
                                            <div class="input-group">
                                                    <input type="number" class="form-control" name="price" value="{{$product->price}}" >
                                                    <span class="input-group-addon">
                                                        {{$data->currency_symbol}}
                                                    </span>
                                                </div>
                                        </div>
                                    </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Select Food Category </strong>
                                        </label>
                                        <select name="category_id" class="form-control">
                                            @foreach($category as $item)
                                            <option value="{{$item->id}}" {{$item->id == $product->category_id ?'selected':''}}>
                                                {{$item ->name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform:uppercase">Select Location </strong>
                                            </label>
                                            <select name="location_id" class="form-control">
                                                @foreach($location as $item)
                                                <option value="{{$item->id}}" {{$item->id == $product->location_id ?'selected':''}}>
                                                    {{$item ->name}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase"> Title </strong>
                                        </label>
                                        <input type="text" class="form-control" name="title" value="{{$product->title}}" >
                                    </div>
                                </div>
                               
                                    <div class="col-md-12">
                                            <div class="form-group">
                                                <label>
                                                    <strong style="text-transform:uppercase">Restaurant Name  </strong><span class="text-success">(optional)</span>
                                                </label>
                                                <input type="text" class="form-control" name="restaurant_name"  value="{{$product->restaurant_name}}"> 
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>
                                                        <strong style="text-transform:uppercase">Restaurant Address  </strong><span class="text-success">(optional)</span>
                                                    </label>
                                                   <textarea name="restaurant_address" class="form-control">{{$product->restaurant_address}}</textarea>
                                                </div>
                                            </div>
                                
                                <div class="col-md-6">
                                        <div class="form-group">
                                                <label>
                                                        <strong style="text-transform:uppercase"> current image </strong>
                                                    </label>
                                                    <br>
                                                <img src="{{asset($product->image)}}" style="width: 300px; height: 200px;padding: 5px">
                                        </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label>
                                                <strong style="text-transform:uppercase">Product Image </strong>
                                            </label>
                                            <input type="file" name="image"  accept="image/*" class="file">
                                            <div class="input-group col-xs-12">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-image"></i>
                                                </span>
                                                <input type="text" name="image" class="form-control " disabled placeholder="Upload Image" >
                                                <span class="input-group-btn">
                                                    <button class="browse btn btn-primary " type="button">
                                                        <i class="fa fa-image"></i> Browse</button>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Food description</strong>
                                        </label>
                                        <div class="table-responsive">
                                            <textarea name="description" class="form-control" style="width: 100%;" rows="10" id="area2">{{$product->description}}</textarea> 
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform: uppercase">activation status </strong>
                                        </label>
                                        <input type="checkbox" name="status" data-toggle="toggle" data-on="Active" data-off="Deactive" data-onstyle="success" data-offstyle="danger"
                                            data-width="100%" {{$product->status == 1?'checked':''}}>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn blue btn-block ">UPDATE </button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection @section('js')
<script src="{{asset('assets/admin/js/bootstrap-toggle.min.js')}}"></script>
<script src="{{asset('assets/admin/js/nicEdit.js')}}" type="text/javascript"></script>
<script>
    $(document).on('click', '.browse', function () {
        var file = $(this).parent().parent().parent().find('.file');
        file.trigger('click');
    });
    $(document).on('change', '.file', function () {
        $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, "{{old('image')}}"));
    });
    bkLib.onDomLoaded(function () {
        new nicEditor({
            iconsPath: '{{asset("assets/admin/img/nicEditorIcons.gif")}}'
        }).panelInstance('area2');
    });
</script>
@endsection