@extends('admin.master') @section('title') Newly User List @endsection @section('css') @endsection @section('content')

<div class="page-content-wrapper">
    <div class="page-content">
            <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <h3 class="page-title uppercase bold"> Newly User List </h3>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 pull-right">
                        <div class="form-group">
                            <form class="navbar-form" method="POST" action="{{ route('admin.search-deactive-users')}}" >
                                {{csrf_field()}}
                                <div class="input-group add-on">
                                    <input class="form-control" placeholder="Email, Name" name="find_user" id="find_user" type="text">
                                    <div class="input-group-btn">
                                        <button class="btn btn-default" type="submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        <hr>
        <div class="row">
               
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-list"></i> Newly User List
                    </div>
                    <div class="panel-body ">
                            @if(count($newUsers)) 
                        <table class="table table-responsive table-striped table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID#</th>
                                    <th> Name</th>
                                    <th> Email</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                    @foreach($newUsers as $item)
                                <tr>
                                    <td>{{$item->id}}</td>
                                    <td>{{$item->name}}</td>
                                    <td>{{$item->email}}</td>
                                    <td>
                                            @if($item->status == 0)
                                            <a class="label label-danger">Blocked</a>
                                            @else
                                            <a class="label label-success">Active</a>
                                            @endif
                                    </td>
                                    <td>
                                        <a class="btn btn-primary" href="{{route('admin.user.detail',$item->id)}}">
                                            <i class="fa fa-user"></i> view Details
                                        </a>
                                    </td>
                                </tr>
                                @endforeach 
                            </tbody>
                        </table>
                        @else
                              <div class="alert alert-danger text-center">
                                <h1>
                                        <strong>
                                                No Record Found...
                                        </strong>
                                </h1>
                              </div>
                        @endif
                    </div>
                    <div class="text-center">
                        @if(!is_array($newUsers))
                        {{ $newUsers->links() }}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection 

@section('js')


 @endsection