<div class="page-sidebar-wrapper">
    <div class="page-sidebar navbar-collapse collapse">
        <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200"
            style="padding-top: 20px">
            <li class="nav-item  @if( request()->path() == 'admin/dashboard'  ) active open @endif ">
                <a href="{{route('admin.dashboard')}}" class="nav-link ">
                    <i class="fa fa-home"></i>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-signal"></i>
                    <span class="title">Website Control</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/general-setting'  ) active open @endif ">
                        <a href="{{ route('admin.general-setting') }}" class="nav-link ">
                            <i class="fa fa-cogs"></i>
                            <span class="title">General Setting </span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/email-setting'  ) active open @endif ">
                        <a href="{{ route('admin.email-setting') }}" class="nav-link ">
                            <i class="fa fa-envelope"></i>
                            <span class="title">Email Setting </span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/sms-setting'  ) active open @endif ">
                        <a href="{{ route('admin.sms-setting') }}" class="nav-link ">
                            <i class="fa fa-mobile"></i>
                            <span class="title">SMS Setting</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-desktop"></i>
                    <span class="title">Interface Control</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/contact'  ) active open @endif ">
                        <a href="{{ route('admin.contact') }}" class="nav-link ">
                            <i class="fa fa-envelope"></i>
                            <span class="title">Contact </span>
                        </a>
                    </li>
                    <li class="nav-item  @if( request()->path() == 'admin/logo'  ) active open @endif ">
                        <a href="{{ route('admin.logo') }}" class="nav-link ">
                            <i class="fa fa-image"></i>
                            <span class="title">Logo & Icon </span>
                        </a>
                    </li>
                    <li class="nav-item   @if( request()->path() == 'admin/menu'  ) active open @endif ">
                        <a href="{{ route('admin.menu') }}" class="nav-link ">
                            <i class="fa fa-info"></i>
                            <span class="title"> Menu Manager</span>
                        </a>
                    </li>
                    <li class="nav-item  @if( request()->path() == 'admin/banner'  ) active open @endif ">
                        <a href="{{ route('admin.banner') }}" class="nav-link ">
                            <i class="fa fa-image"></i>
                            <span class="title"> Home Page Banner </span>
                        </a>
                    </li>
                    <li class="nav-item  @if( request()->path() == 'admin/sub-banner'  ) active open @endif ">
                        <a href="{{ route('admin.sub-banner') }}" class="nav-link ">
                            <i class="fa fa-image"></i>
                            <span class="title"> Others Page Banner </span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-newspaper-o"></i>
                    <span class="title">News Management</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/news-header'  ) active open @endif ">
                        <a href="{{ route('admin.news-header') }}" class="nav-link ">
                            <i class="fa fa-header"></i>
                            <span class="title"> Update  News Header</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/create-news'  ) active open @endif ">
                        <a href="{{ route('admin.news.create') }}" class="nav-link ">
                            <i class="fa fa-plus"></i>
                            <span class="title"> Add News</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/news'  ) active open @endif ">
                        <a href="{{ route('admin.news') }}" class="nav-link ">
                            <i class="fa fa-eye"></i>
                            <span class="title">View News </span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-th-list"></i>
                    <span class="title">Category Management</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/categoy-header'  ) active open @endif ">
                        <a href="{{ route('admin.categoy-header') }}" class="nav-link ">
                            <i class="fa fa-header"></i>
                            <span class="title"> Upate Category Header</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/create-category'  ) active open @endif ">
                        <a href="{{ route('admin.category.create') }}" class="nav-link ">
                            <i class="fa fa-plus"></i>
                            <span class="title"> Add Category</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/category'  ) active open @endif ">
                        <a href="{{ route('admin.category') }}" class="nav-link ">
                            <i class="fa fa-eye"></i>
                            <span class="title">View Category </span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-location-arrow"></i>
                    <span class="title">Location Management</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/create-location'  ) active open @endif ">
                        <a href="{{ route('admin.location.create') }}" class="nav-link ">
                            <i class="fa fa-plus"></i>
                            <span class="title"> Add Location</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/location'  ) active open @endif ">
                        <a href="{{ route('admin.location') }}" class="nav-link ">
                            <i class="fa fa-eye"></i>
                            <span class="title">View Location </span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <span class="title">Product Management</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/create-product'  ) active open @endif ">
                        <a href="{{ route('admin.product.create') }}" class="nav-link ">
                            <i class="fa fa-plus"></i>
                            <span class="title">Add Product</span>
                        </a>
                    </li>

                    <li class="nav-item @if( request()->path() == 'admin/pending-products'  ) active open @endif ">
                        <a href="{{ route('admin.pending-products') }}" class="nav-link ">
                            <i class="fa fa-question"></i>
                            <span class="title">Pending Products</span>
                        </a>
                    </li>

                    <li class="nav-item @if( request()->path() == 'admin/active-products'  ) active open @endif ">
                        <a href="{{ route('admin.active-products') }}" class="nav-link ">
                            <i class="fa fa-check"></i>
                            <span class="title">Active Products</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/deactive-products'  ) active open @endif ">
                        <a href="{{ route('admin.deactive-products') }}" class="nav-link ">
                            <i class="fa fa-times"></i>
                            <span class="title">Deactive Products</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fa fa-users"></i>
                    <span class="title">User Management</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item @if( request()->path() == 'admin/users'  ) active open @endif ">
                        <a href="{{ route('admin.users') }}" class="nav-link ">
                            <i class="fa fa-user"></i>
                            <span class="title">All Users</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/new-users'  ) active open @endif ">
                        <a href="{{ route('admin.new-users') }}" class="nav-link ">
                            <i class="fa fa-user-md"></i>
                            <span class="title">New Users</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/active-users'  ) active open @endif ">
                        <a href="{{ route('admin.active-users') }}" class="nav-link ">
                            <i class="fa fa-check"></i>
                            <span class="title">Active Users</span>
                        </a>
                    </li>
                    <li class="nav-item @if( request()->path() == 'admin/deactive-users'  ) active open @endif ">
                        <a href="{{ route('admin.deactive-users') }}" class="nav-link ">
                            <i class="fa fa-ban"></i>
                            <span class="title">Deactive Users</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>