@extends('admin.master') @section('title') Contact Email @endsection @section('content')
<div class="page-content-wrapper">
    <div class="page-content">
        <h3 class="page-title uppercase bold"> CONTACT FORM </h3>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <i class="fa fa-envelope"></i> Upadte Contact Info
                    </div>
                    <div class="panel-body">
                        <form action="{{route('admin.contact.upadte')}}" method="post">
                            {{ csrf_field()}}
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>
                                        <strong style="text-transform:uppercase">EMAIL </strong>
                                    </label>
                                    <input type="email" class="form-control" name="email" value="{{$contact->email}}">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>
                                        <strong style="text-transform:uppercase">PHONE </strong>
                                    </label>
                                    <input type="text" class="form-control" name="phone" value="{{$contact->phone}}">
                                </div>
                            </div>
                            <div class="col-md-12">
                                    <div class="form-group">
                                        <label>
                                            <strong style="text-transform:uppercase">Address </strong>
                                        </label>
                                        <input type="text" class="form-control" name="address" value="{{$contact->address}}">
                                    </div>
                                </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn blue btn-block ">UPDATE</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection