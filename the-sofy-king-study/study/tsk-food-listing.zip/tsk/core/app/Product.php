<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillabel = ['category_id','user_id','name','title','price','image','description','status'];

    public function category(){
        return $this->belongsTo('App\Category');
    }
    public function location(){
        return $this->belongsto('App\Location');
    }
    public function ratting(){
        return $this->hasMany('App\Ratting','product_id','id');
    }
}
