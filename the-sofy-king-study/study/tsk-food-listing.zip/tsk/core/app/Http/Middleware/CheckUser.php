<?php

namespace App\Http\Middleware;
use App\User;
use Auth;
use Session;

use Closure;

class CheckUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // $userId =  Auth::user()->id;
        if($request->get('name')){
            $user = User::where('name',$request->get('name'))->first();
            if($user->status == 0)
            {
                Auth::guard('web')->logout();
                Session::flash('suspendUser', 'true');
                return redirect('/');
            }
        }
       
      
        return $next($request);
    }
   
}
