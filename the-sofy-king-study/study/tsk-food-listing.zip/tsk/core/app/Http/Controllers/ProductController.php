<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\Location;
use App\Ratting;
use Image;
use Toastr;
use Session;

class ProductController extends Controller
{
    
    public function create(){
        $category = Category::where('status',1)->get();
        $location = Location::where('status',1)->get();
        return view('admin.product.create-product',compact('category','location'));
    }

    public function store(Request $request){
        $this->validate($request,$this->rules());

            $image = $request->file('image');
            $imageName = time().'_'.rand(0, 20).'_'.$image->getClientOriginalName();
            $directoty = 'assets/frontend/img/product-image/';
            $imageUrl = $directoty.$imageName;
            Image::make($image)->save($imageUrl);

        $product = new Product();
        $product->category_id = $request->category_id;
        $product->location_id = $request->location_id;
        $product->name = $request->name;
        $product->title = $request->title;
        $product->price = $request->price;
        $product->restaurant_name = $request->restaurant_name;
        $product->restaurant_address = $request->restaurant_address;
        $product->description = $request->description;
        $product->image = $imageUrl;
        $product->status = $request->status == '' ?0:1;
        $product->save();
        Toastr::success('Information Save Successfully...');
        return redirect()->back();
    }
   
    public function edit($id){
        $category = Category::where('status',1)->get();
        $location = Location::where('status',1)->get();
        $product = Product::find($id);
        return view('admin.product.edit-product',[
            'category'=>$category,
            'location'=>$location,
            'product'=>$product,
        ]);
    }
    public function update(Request $request){
        $this->validate($request,[
            'image'=>'nullable|mimes:png,jpg,jpeg',
        ]);

        $product = Product::find($request->id);

        if($request->hasFile('image')){
            @unlink($product->image);
            $image = $request->file('image');
            $imageName = time().'_'.rand(0, 20).'_'.$image->getClientOriginalName();
            $directoty = 'assets/frontend/img/product-image/';
            $imageUrl = $directoty.$imageName;
            Image::make($image)->save($imageUrl);
            $product->image = $imageUrl;
        }
        $product->category_id = $request->category_id;
        $product->location_id = $request->location_id;
        $product->name = $request->name;
        $product->title = $request->title;
        $product->price = $request->price;
        $product->description = $request->description;
        $product->restaurant_name = $request->restaurant_name;
        $product->restaurant_address = $request->restaurant_address;
        $product->status = $request->status == '' ?0:1;
        $product->save();
        Toastr::success('Information Updated Successfully...');
        $userId = $product->user_id;
        return redirect()->back();
    }
    public function delete($id){
        $product = Product::find($id);
        @unlink($product->image);
        $productId =  $product->id;
        $product->ratting()->where('product_id',$productId)->delete();
        $product->delete();
        Toastr::success('Information Deleted Successfully...');
        return redirect()->back();
    }

    protected function rules(){
        return [
            'category_id' =>'required|integer',
            'location_id' =>'required|integer',
            'name' =>'required',
            'title' =>'required',
            'price' =>'required',
            'description' =>'required|string',
            'image'=>'required|mimes:png,jpg,jpeg'
        ];
    }
}
