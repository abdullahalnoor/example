<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\GeneralSetting;
use App\News;
use App\Menu;
use App\Category;
use App\Location;
use App\Product;
use Session;
use Auth;
use App\Ratting;
use App\User;

class WelcomeController extends Controller
{
    

    public function index(){
        // share with every page data
        $data  = GeneralSetting::first();
        $menus = Menu::get();
        $news = News::where('status',1)->latest()->take(3)->get();
        $categories = Category::where('status',1)->get();
        $locations = Location::where('status',1)->get();
        // end of share with every page data

        $allProducts = Product::where('status',1)->get();
      
        $maxRow = [];

        foreach($categories as $item){
            $maxRow[$item->id]['amount'] = $allProducts->where('category_id',$item->id)->count();
            $maxRow[$item->id]['id'] = $item->id;
        }
        
         rsort($maxRow);
        
        return view('frontend.home.index',[
            'menus'=>$menus,
            'news'=>$news,
            'categories'=>$categories,
            'locations'=>$locations,
            'maxRow'=>$maxRow,
            'data'=>$data,
        ]);
    }

    public function viewProductCategory($id){
        $data  = GeneralSetting::first();
        $menus = Menu::get();
        $categories = Category::where('status',1)->get();
        $category = Category::find($id);
        $products = Product::where('category_id',$category->id)->where('status',1)->paginate(15);
        return view('frontend.category.index',[
            'menus'=>$menus,
            'category'=>$category,
            'categories'=>$categories,
            'products'=>$products,
            'data'=>$data,
        ]);
    }
    public function viewProductDetail($id){
        $data  = GeneralSetting::first();
        $menus = Menu::get();
        $categories = Category::where('status',1)->get();
        $product = Product::find($id);
        $ratting = new Ratting();

        $users = User::get();
        
        $productReview = $ratting->where('product_id',$id)->get();
        // dd($productReview);
        // rate avg
        $avgRate = $ratting->where('product_id',$id)->avg('rate');
        $avgRate = round($avgRate);
        // total voter 
        $totalVoter = $ratting->where('product_id',$id)->get()->count();
        // total rate in sum
        $total = $ratting->where('product_id',$id)->sum('rate');
        
        return view('frontend.detail.index',[
            'data'=>$data,
            'menus'=>$menus,
            'categories'=>$categories,
            'product'=>$product,
            'avgRate'=>$avgRate,
            'totalVoter'=>$totalVoter,
            'productReview'=>$productReview,
            'users'=>$users,
        ]
    );
    }

    public function rateProduct($id,$rate){
        if(Auth::guard('web')->check()){ 
             $user_id = Auth::user()->id;
             $ratting = new Ratting();
             $value = Ratting::where('user_id',$user_id)->where('product_id',$id)->first();
                 if(!$value){
                 $ratting->user_id = $user_id;
                 $ratting->product_id = $id;
                 $ratting->rate = $rate;
                 $ratting->save();
                 }else{
                    $value->rate = $rate;
                    $value->save();
                 }
        }
        $comment = empty($value->comment) ?'Write Your Comment in short':$value->comment;
        Session::flash('commentModal', 'true');
        return redirect()->back()->with('comment',$comment);
     }
     public function reviewProduct(Request $request){
        //  return $request->all();
       if(Auth::guard('web')->check()){
            $user_id = Auth::user()->id;
            $id      = $request->id;
            $ratting = new  Ratting();
            $ratting = $ratting->where('user_id',$user_id)->where('product_id',$id)->first();
            // dd($ratting);
            $ratting->comment = $request->comment;
            $ratting->save();
       }
       return redirect()->back();
     }

     public function searchProduct(Request $request){

        $data  = GeneralSetting::first();
        $menus = Menu::get();
        $categories = Category::where('status',1)->get();

        $name = $request->name;
        $locationId = $request->location_id;
        $categoryId = $request->category_id;

        $nameCat = empty($name) && empty($categoryId);
        $nameLoc = empty($name) && empty($locationId);
        $catLoc =  empty($categoryId) && empty($locationId);

        $notNameCat = !empty($name) && !empty($categoryId);
        $notNameLoc = !empty($name) && !empty($locationId);
        $notCatLoc =  !empty($categoryId) && !empty($locationId);

        if(empty($name) && $catLoc){
            return back()->with('message','Please.. fill up at least one field to search..');
        }
        elseif($notNameCat && !empty($locationId)){
           // search  by all
             $products = Product::where('status', 1)->where('location_id',$request->location_id)->where('category_id',$request->category_id)->where('name','LIKE','%'.$request->name.'%')->get();
        }
        elseif($notNameCat && empty($locationId)){
            // search  by name and category_id
            $products = Product::where('status', 1)->where('category_id',$request->category_id)->where('name','LIKE','%'.$request->name.'%')->get();
        }
        elseif($notNameLoc && empty($categoryId)){
            // search only by name and location_id
            $products = Product::where('status', 1)->where('location_id',$request->location_id)->where('name','LIKE','%'.$request->name.'%')->get();
        
        }
        elseif($notCatLoc && empty($name)){
             // search only by location_id and category_id
            $products = Product::where('status', 1)->where('location_id',$request->location_id)->where('category_id',$request->category_id)->get();
        }
        elseif(!empty($name) && $catLoc){
              // search only by name
              $products = Product::where('status', 1)->where('name','LIKE','%'.$request->name.'%')->get();
        }
        elseif(!empty($categoryId) && $nameLoc){
            // search only by category_id
             $products = Product::where('status', 1)->where('category_id',$request->category_id)->get();
        }
        elseif($nameCat && !empty($locationId)){
             // search only by location_id
            $products = Product::where('status', 1)->where('location_id',$request->location_id)->get();
        }
        
        
        
        
        $cat = $categories->toArray();
        $cats = [];
        // dd($cat[0]['id']);

        foreach($cat as $var){
            $cats[$var['id']] = $var;
        }
        // dd($cats);
        // $productByName = [];
        // foreach($products as $product){
        //     if(array_key_exists($product->category_id,$cats)){
        //         $productsName[$product->id] = $product;
        //     }
        // }
        // if($productByName){
        //     return 'true';
        // }else{
        //     return 'false';
        // }
       

        return view('frontend.product-search.index',[
            'menus'=>$menus,
            'categories'=>$categories,
            'cats'=>$cats,
            'products'=>$products,
            'data'=>$data,
        ]);


     }
     
   



}
