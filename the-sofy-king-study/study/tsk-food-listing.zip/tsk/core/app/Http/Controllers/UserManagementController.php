<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Product;
use Toastr;
use App\Category;
use Session;
use Carbon\Carbon;

class UserManagementController extends Controller
{
    public function index(){
        $users = User::orderBy('id','desc')->paginate(10);
        return view('admin.user-management.index',compact('users'));
    }

    public function searchUsers(Request $request){
        $users = User::where('name','LIKE','%'.$request->find_user.'%')->orWhere('email','LIKE','%'.$request->find_user.'%')->paginate(10);
        // dd($users);
        return view('admin.user-management.index',compact('users'));
    }

   

    public function userDetail($id){
        $user = User::find($id);
        $userPro = Product::where('user_id',$user->id)->get()->count();
        $userLastPro = Product::where('user_id',$user->id)->orderBy('id','desc')->first();
        $userPendingPro = Product::where('user_id',$user->id)->where('status',2)->get()->count();
        $userActivePro = Product::where('user_id',$user->id)->where('status',1)->get()->count();
        $userDeactivePro = Product::where('user_id',$user->id)->where('status',0)->get()->count();
        $product = Product::get()->count();
       
        $totalAvg =0;
        $activeProAvg =0;
        $deactiveProAvg =0;
        if($userPro != 0){
            $totalAvg = $userPro/$product;
            $totalAvg *=100;
            $activeProAvg = $userActivePro/$userPro;
            $activeProAvg *=100;
            $deactiveProAvg = $userDeactivePro/$userPro;
            $deactiveProAvg *=100;
        }
        return view('admin.user-management.user-detail.index',[
            'totalAvg'=>$totalAvg,
            'activeProAvg'=>$activeProAvg,
            'deactiveProAvg'=>$deactiveProAvg,
            'userLastPro'=>$userLastPro,
            'user'=>$user,
            'userPro'=>$userPro,
            'userPendingPro'=>$userPendingPro,
            'userActivePro'=>$userActivePro,
            'userDeactivePro'=>$userDeactivePro,
        ]);
    }

    public function newUsers(){
        $newUsers = User::whereBetween('created_at', [Carbon::now()->subDays(7), Carbon::now()])->paginate(10);
        return view('admin.user-management.new-users.index',compact('newUsers'));
    }

    public function activeUserList(){
        $activeUsers = User::where('status',1)->paginate(10);
        return view('admin.user-management.active-users.index',compact('activeUsers'));
    }
    public function searchActiveUsers(Request $request){
        $activeUser = User::where('name','LIKE','%'.$request->find_user.'%')->orWhere('email','LIKE','%'.$request->find_user.'%')->get();
        $activeUsers = [];
        foreach($activeUser as $item){
            if($item->status == 1){
                $activeUsers[$item->id] = $item;
            }
        }
        return view('admin.user-management.active-users.index',compact('activeUsers'));
    }


    public function deactiveUserList(){
        $deactiveUsers = User::where('status',0)->paginate(10);
        return view('admin.user-management.deactive-users.index',compact('deactiveUsers'));
    }

    public function searchDeactiveUsers(Request $request){
        $deactiveUser = User::where('name','LIKE','%'.$request->find_user.'%')->orWhere('email','LIKE','%'.$request->find_user.'%')->where('status',0)->get();

        $deactiveUsers = [];

        foreach($deactiveUser as $item){
            if($item->status == 0){
                $deactiveUsers[$item->id] = $item;
            }
        }

        return view('admin.user-management.deactive-users.index',compact('deactiveUsers'));
    }

    public function userPosts(Request $request,$id,$type=null){
       
        switch($type){
            case 'pending':
            $usrePro = Product::where('user_id',$id)->where('status',2)->paginate(10);
            break;
            case 'active':
                $usrePro = Product::where('user_id',$id)->where('status',1)->paginate(10);
            break;
            case 'deactive':
            $usrePro = Product::where('user_id',$id)->where('status',0)->paginate(10);
            break;
            default: 
             $usrePro = Product::where('user_id',$id)->paginate(10);
            break; 
        }
        $user = User::where('id',$id)->first();
        $category = Category::where('status',1)->get();
    return view('admin.user-management.user-posts.index',[
        'user'=>$user,
        'category'=>$category,
        'usrePro'=>$usrePro,
    ]);
    }
   
}
