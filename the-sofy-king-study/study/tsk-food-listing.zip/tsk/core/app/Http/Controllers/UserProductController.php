<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Product;
use Auth;
use Image;
use Toastr;

class UserProductController extends Controller
{   
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth','user-authorization']);
    }
    
    public function create(){
        $category = Category::where('status',1)->get();
        return view('user.product.create-product',compact('category'));
    }
    public function store(Request $request){
        $this->validate($request,$this->rules());

        $image = $request->file('image');
        $imageName = time().'_'.rand(0, 20).'_'.$image->getClientOriginalName();
        $directoty = 'assets/frontend/img/product-image/';
        $imageUrl = $directoty.$imageName;
        Image::make($image)->save($imageUrl);
        $product = new Product();
        $product->category_id = $request->category_id;
        $product->user_id = Auth::user()->id;
        $product->name = $request->name;
        $product->title = $request->title;
        $product->price = $request->price;
        $product->description = $request->description;
        $product->image = $imageUrl;
        $product->save();
        Toastr::success('Information Save Successfully...');
        return redirect()->back();
    }
    public function edit($id){
        $user_id = Auth::user()->id;
        $category = Category::where('status',1)->get();
        $product = Product::where('user_id',$user_id)->where('id',$id)->first();
        return view('user.product.edit-product',compact('product','category'));
    }
    public function update(Request $request){
        
        $this->validate($request,[
            'image'=>'nullable|mimes:png,jpg,jpeg',
            'category_id' =>'required|integer',
            'name' =>'required',
            'title' =>'required',
            'price' =>'required',
            'description' =>'required',
        ]);
        $product = Product::find($request->id);
        if($request->hasFile('image')){
            @unlink($product->image);
            $image = $request->file('image');
            $imageName = time().'_'.rand(0, 20).'_'.$image->getClientOriginalName();
            $directoty = 'assets/frontend/img/product-image/';
            $imageUrl = $directoty.$imageName;
            Image::make($image)->save($imageUrl);
            $product->image = $imageUrl;
        }
        $product->category_id = $request->category_id;
        $product->name = $request->name;
        $product->title = $request->title;
        $product->price = $request->price;
        $product->description = $request->description;
        $product->status = 2;
        $product->save();
        Toastr::success('Information  Updated Successfully...');
        return redirect()->back();
    }

    protected function rules(){
        return [
            'category_id' =>'required|integer',
            'name' =>'required',
            'title' =>'required',
            'price' =>'required',
            'description' =>'required',
            'image'=>'required|mimes:png,jpg,jpeg'
        ];
    }
}
