<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Product;
use App\Admin;
use App\User;
use Hash;
use Carbon\Carbon;

class AdminHomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $totalUsers = User::get()->count();
        $activeUsers = User::where('status',1)->get()->count();
        $deactiveUsers = User::where('status',0)->get()->count();
        
        $recentRegister = User::whereBetween('created_at', [Carbon::now()->subDays(7), Carbon::now()])->get()->count();


       $totalPro =  Product::get()->count();
       $pendingrPro =  Product::where('status',2)->get()->count();
       $activePro =  Product::where('status',1)->get()->count();
       $deactivePro =  Product::where('status',0)->get()->count();
        
        $userStatistics = [
            'totalUsers'=>$totalUsers,
            'activeUsers'=>$activeUsers,
            'deactiveUsers'=>$deactiveUsers,
            'recentRegister'=>$recentRegister,

            'totalPro'=>$totalPro,
            'pendingrPro'=>$pendingrPro,
            'activePro'=>$activePro,
            'deactivePro'=>$deactivePro,
        ];
        return view('admin.home.index',[
            'userStatistics'=>$userStatistics,
        ]);
    }

    public function showChangePasswordForm(){
        return view('admin.auth.change-password');
    }
    public function updatePassword(Request $request){
        $adminId = Auth::guard('admin')->user()->id;
        $admin = Admin::find($adminId);
        if (!(Hash::check($request->get('current-password'), $admin->password))) {
            // The passwords matches
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again.");
        }
 
        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            //Current password and new password are same
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password.");
        }
 
        $validatedData = $request->validate([
            'current-password' => 'required',
            'new-password' => 'required|string|min:6|confirmed',
        ]);
 
        //Change Password
        // $user = Auth::user();
        $admin->password = bcrypt($request->get('new-password'));
        $admin->save();
 
        return redirect()->back()->with("success","Password changed successfully !");
    }

}
