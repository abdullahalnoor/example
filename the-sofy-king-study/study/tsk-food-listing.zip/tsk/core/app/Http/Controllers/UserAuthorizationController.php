<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use Carbon\Carbon;

class UserAuthorizationController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function verifyUser(){
        $user = User::find(Auth::id());
        if($user->email_status != 1){
        return view('user.user-authorization.email-verification');
        }elseif($user->sms_status != 1){
            return view('user.user-authorization.sms-verification');
        }
        return redirect()->route('home');
    }

    
    public function userMailVerification(){
        $user = User::find(Auth::id());
        if($user->email_status != 1){
            if (Carbon::parse($user->e_sent_time) > Carbon::now())
            {
               // $delay = Carbon::parse($user->e_sent_time) - Carbon::now();
               return back()->with('alert', 'Recently a Message is Sent to Your Email..  Please Check Your Email or Try after some moment');
            }
           else
           {
               $code = str_random(10);
               $msg = 'Your Verification code is: '.$code;
               $user->ver_code = $code ;
               $user->e_sent_time   = Carbon::now()->addMinutes(10);
               $user->save();
               send_email($user->email, $user->name, 'Verification Code', $msg);
               return back()->with('success', 'Email verification code sent succesfully');
               
              
           }
        }else{
            return back()->with('success', 'Your Email is Verified');
        }
        

    }
   

    public function verifyEmail(Request $request){
        $this->validate($request,[
            'code' => 'required'
        ]);
        $user = User::find(Auth::id());
            if($user->email_status != 1){
                if($user->ver_code == $request->code){
                $user->email_status= 1;
                $user->ver_code = str_random(12);
                $user->save();
                return back()->with('success', 'Your Email is Verified succesfully...');
            }else{
                return back()->with('alert', 'Your Verification code is does not match');
            }
        }
        return back()->with('success', 'Your Email is already Verified succesfully...');
    }


    public function userSmsVerification()
    {
        $user = User::find(Auth::id());

        if($user->sms_status != 1)
        {
            // dd(Carbon::parse($user->s_sent_time));
            if (Carbon::parse($user->s_sent_time) > Carbon::now())
            {
               // $delay = Carbon::parse($user->e_sent_time) - Carbon::now();
               return back()->with('alert', 'Recently a Message is Sent to Your Mobile..  Please Check Your Mobile or Try after some moment');
            }
           else
           {
            $code = str_random(8);
            $sms =  'Your Verification code is: '.$code;
            $user->ver_code = $code;
            $user->s_sent_time = Carbon::now();
            $user->save();
 
            send_sms($user->mobile, $sms);
            return back()->with('success', 'SMS verification code sent succesfully');
           }
        }else
        {
            return back()->with('success', 'Your SMS is Verified');
        }
 
    }

    public function verifySMS(Request $request){
            $this->validate($request,[
                'code' => 'required'
            ]);
            $user = User::find(Auth::id());
            if($user->sms_status != 1){
                if($user->ver_code == $request->code){
                    $user->sms_status= 1;
                    $user->ver_code = str_random(12);
                    $user->save();
                    return back()->with('success', 'Your SMS is Verified succesfully...');
                }else{
                    return back()->with('alert', 'Your Verification code is does not match');
                }
            }
            return back()->with('success', 'Your SMS is already Verified succesfully...');
        }

}
