<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\GeneralSetting;
use Image;
use Toastr;


class GeneralSettingController extends Controller
{
    
    public function generalSetting(){
        $generalSetting = GeneralSetting::first();
        return view('admin.website-control.general-setting',[
            'generalSetting'=>$generalSetting
        ]);
    }

    public function updateGeneralInfo(Request $request){  
        // return $request->all();
        $generalSetting =  GeneralSetting::first();
        $generalSetting->website_title = $request->website_title;
        $generalSetting->color_code = $request->color_code;
        $generalSetting->base_currency = $request->base_currency;
        $generalSetting->currency_symbol = $request->currency_symbol;
        $generalSetting->registration_status = $request->registration_status == '' ?0:1;
        $generalSetting->email_verification = $request->email_verification == '' ?1:0;
        $generalSetting->sms_verification = $request->sms_verification == '' ?1:0;
        $generalSetting->number = $request->number;
        $generalSetting->email_notification = $request->email_notification == '' ?0:1;
        $generalSetting->sms_notification = $request->sms_notification == '' ?0:1;
        $generalSetting->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->route('admin.general-setting');
    }

    public function emailSetting(){
        $generalSetting = GeneralSetting::first();
        return view('admin.website-control.email-setting',[
            'generalSetting'=>$generalSetting
        ]);
    }
    public function updateEmailInfo(Request $request){
        $generalSetting =  GeneralSetting::first();
        $generalSetting->email = $request->email;
        $generalSetting->message = $request->message;
        $generalSetting->save();
        Toastr::success('Information Updated Successfully...');        
        return redirect()->route('admin.email-setting');
    }
    public function smsSetting(){
        $generalSetting = GeneralSetting::first();
        return view('admin.website-control.sms-setting',[
            'generalSetting'=>$generalSetting
        ]);
    }
    public function updateSmsInfo(Request $request){
        $generalSetting =  GeneralSetting::first();
        $generalSetting->sms_api = $request->sms_api;
        $generalSetting->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->route('admin.sms-setting');
    }
    public function editContact(){
        $contact = GeneralSetting::first();
        return view('admin.contact.index',compact('contact'));
}
    public function upadteContact(Request $request){
        // return $request->all();
        $this->validate($request,[
            'email' => 'required|email'
        ]);
        $contact = GeneralSetting::first();
        $contact->email = $request->email;
        $contact->phone = $request->phone;
        $contact->address = $request->address;
        $contact->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->back();
    }
    public function viewLogo(){
        return view('admin.logo.index');
    }

    public function updateLogo(Request $request){
   
        $this->validate($request,array(
            'logo' => 'nullable|mimes:png,jpg,jpeg' ,
            'icon' => 'nullable|mimes:png,jpg,jpeg' ,
        ));
  
        if ($request->hasFile('logo')) {
            // return $request->all();
            unlink('assets/frontend/img/logo.png');
            $image = $request->file('logo');
            $filename = 'logo' . '.' . 'png';
            $location = 'assets/frontend/img/'. $filename;
            Image::make($image)->save($location);
        };
        if ($request->hasFile('icon')) {
            unlink('assets/frontend/img/icon.png');
            $image = $request->file('icon');
            $filename = 'icon' . '.' . 'png';
            $location = 'assets/frontend/img/'. $filename;
            $img = Image::make($image)->save($location);
        };
        Toastr::success('Information Updated Successfully...');
        return redirect()->route('admin.logo');
    }

    public function editBanner(){
        $banner = GeneralSetting::first();
        return view('admin.banner.index',compact('banner'));
    }
    public function updateBanner(Request $request){
        if ($request->hasFile('banner_image')) {
            // return $request->all();
            unlink('assets/frontend/img/banner-image.png');
            $image = $request->file('banner_image');
            $filename = 'banner-image' . '.' . 'png';
            $location = 'assets/frontend/img/'. $filename;
            Image::make($image)->save($location);
        };

        $banner = GeneralSetting::first();
        $banner->banner_text = $request->banner_text;
        $banner->banner_title = $request->banner_title;
        $banner->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->route('admin.banner');
    }

    public function editSubBanner(){
        return view('admin.sub-banner.index');
    }
    public function updateSubBanner(Request $request){
        if ($request->hasFile('sub_banner_image')) {
            unlink('assets/frontend/img/sub-banner-image.png');
            $image = $request->file('sub_banner_image');
            $filename = 'sub-banner-image' . '.' . 'png';
            $location = 'assets/frontend/img/'. $filename;
            Image::make($image)->save($location);
        };

        Toastr::success('Information Updated Successfully...');
        return redirect()->route('admin.sub-banner');
    }

    public function categoyHeader(){
        $categoryHeader =  GeneralSetting::first();
        return view('admin.category.category-header',compact('categoryHeader'));
    }
    public function updateCategoyHeader(Request $request){
        $categoryHeader =  GeneralSetting::first();
        $categoryHeader->category_title = $request->category_title;
        $categoryHeader->category_text = $request->category_text;
        $categoryHeader->save();
        Toastr::success('Information Updated Successfully...');
        return view('admin.category.category-header',compact('categoryHeader'));
    }

    public function newsHeader(){
        $newsHeader =  GeneralSetting::first();
        return view('admin.news.news-header',compact('newsHeader'));
    }
    public function updateNewsHeader(Request $request){
        $newsHeader =  GeneralSetting::first();
        $newsHeader->news_title = $request->news_title;
        $newsHeader->news_text   =  $request->news_text ;
        $newsHeader->news_watermark = $request->news_watermark;
        $newsHeader->save();
        Toastr::success('Information Updated Successfully...');
        return view('admin.news.news-header',compact('newsHeader'));
    }

}
