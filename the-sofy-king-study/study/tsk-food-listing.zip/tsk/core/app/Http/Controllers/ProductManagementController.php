<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;

class ProductManagementController extends Controller
{
    public function allProducts(){
        $products = Product::orderBy('id','desc')->with('category')->paginate(10);
        return view('admin.product-management.all-products',compact('products'));
    }
    public function pendingProducts(){
        $products = Product::orderBy('id','desc')->where('status',2)->with('category')->paginate(10);
        return view('admin.product-management.pending-products',compact('products'));
    }
    public function activeProducts(){
        $products = Product::orderBy('id','desc')->where('status',1)->with('category')->paginate(10);
        return view('admin.product-management.active-products',compact('products'));
    }
    public function deactiveProducts(){
        $products = Product::orderBy('id','desc')->where('status',0)->with('category')->paginate(10);
        return view('admin.product-management.deactive-products',compact('products'));
    }
}
