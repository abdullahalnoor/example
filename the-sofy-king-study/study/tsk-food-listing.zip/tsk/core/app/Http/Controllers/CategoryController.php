<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use Image;
use Toastr;


class CategoryController extends Controller
{
    public function index(){
        $category = Category::orderBy('created_at')->paginate(10);
        return view('admin.category.index',compact('category'));
    }

    public function create(){
        return view('admin.category.create-category');
    }

    public function store(Request $request){
        $category = new Category();

        $image =  $request->file('image');
        $imageName = time().'.'.$image->getClientOriginalName();
        $directory =  'assets/frontend/img/category-image/';
        $imgUrl =  $directory.$imageName;
        Image::make($image)->save($imgUrl);

        $category->name = $request->name;
        $category->description = $request->description;
        $category->image = $imgUrl;
        $category->status = $request->status == '' ?0:1;
        $category->save();
        Toastr::success('Information Save Successfully...');
        return redirect()->back();
    }
    public function edit($id){
        $category = Category::find($id);
        return view('admin.category.edit-category',compact('category'));
    }
    public function update(Request $request){
        $category = Category::find($request->id);

        if($request->hasFile('image')){
            @unlink($category->image);
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $directory = 'assets/frontend/img/category-image/';
            $imgUrl = $directory.$imageName;
            Image::make($image)->save($imgUrl);
            $category->image = $imgUrl;
        }

        $category->name = $request->name;
        $category->description = $request->description;
        $category->status = $request->status == '' ?0:1;
        $category->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->back();
    }

}
