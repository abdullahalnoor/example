<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use App\Product;
use Hash;
use Carbon\Carbon;
use Toastr;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth','user-authorization']);
    }

    protected function userId(){
        $user_id = Auth::user()->id;
        return $user_id;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::find($this->userId());

        $userPro = Product::where('user_id',$this->userId())->get()->count();

        $userLastPro = Product::where('user_id',$this->userId())->orderBy('id','desc')->first();

        $userPendingPro = Product::where('user_id',$this->userId())->where('status',2)->get()->count();
        $userActivePro = Product::where('user_id',$this->userId())->where('status',1)->get()->count();
        $userDeactivePro = Product::where('user_id',$this->userId())->where('status',0)->get()->count();
        $product = Product::get()->count();
       
        $totalAvg =0;
        $activeProAvg =0;
        $deactiveProAvg =0;
        if($userPro != 0){
            $totalAvg = $userPro/$product;
            $totalAvg *=100;
            $activeProAvg = $userActivePro/$userPro;
            $activeProAvg *=100;
            $deactiveProAvg = $userDeactivePro/$userPro;
            $deactiveProAvg *=100;
        }
        $userStatistics = [
            'totalAvg'=>$totalAvg,
            'activeProAvg'=>$activeProAvg,
            'deactiveProAvg'=>$deactiveProAvg,
            'userLastPro'=>$userLastPro,

            'user'=>$user,
            'userPro'=>$userPro,
            'userPendingPro'=>$userPendingPro,
            'userActivePro'=>$userActivePro,
            'userDeactivePro'=>$userDeactivePro,
        ]; 

        return view('user.home.home',compact('userStatistics'));
    }

    public function showChangePasswordForm(){
        return view('user.auth.change-password');
    }
    public function updatePassword(Request $request){
        $user = User::find($this->userId());
        if (!(Hash::check($request->get('current-password'),$user->password))) {
            // The passwords matches
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again.");
        }
 
        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            //Current password and new password are same
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password.");
        }
 
        $validatedData = $request->validate([
            'current-password' => 'required',
            'new-password' => 'required|string|min:6|confirmed',
        ]);
 
        //Change Password
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
 
        return redirect()->back()->with("success","Password changed successfully !");
    }

    
   


}
