<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Product;

class UserProductManagementController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    protected function userId(){
        $user_id = Auth::user()->id;
        return $user_id;
    }

    public function index(){
        $products = Product::where('user_id',$this->userId())->paginate(10);
        return view('user.product-management.all-products',compact('products'));
    }

    public function userPendingProducts(){
        $products = Product::where('user_id',$this->userId())->where('status',2)->paginate(10);
        return view('user.product-management.pending-products',compact('products'));
    }

    public function userActiveProducts(){
        $products = Product::where('user_id',$this->userId())->where('status',1)->paginate(10);
        return view('user.product-management.active-products',compact('products'));
    }

    public function userDeactiveProducts(){
        $products = Product::where('user_id',$this->userId())->where('status',0)->paginate(10);
        return view('user.product-management.deactive-products',compact('products'));
    }


}
