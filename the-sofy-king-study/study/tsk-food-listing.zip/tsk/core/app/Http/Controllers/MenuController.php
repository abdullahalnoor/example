<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Menu;
use Toastr;

class MenuController extends Controller
{
    public function index(){
        $menus = Menu::orderBy('id','desc')->paginate(10);
        return view('admin.menu.index',compact('menus'));
    }

    public function create(){
        return view('admin.menu.create-menu');
    }

    public function store(Request $request){
        $menu = new Menu();
        $menu->name = $request->name;
        $menu->description = $request->description;
        $menu->save();
        Toastr::success('Information Save Successfully...');
        return redirect()->back();
    }
    public function edit($id){
        $menus = Menu::find($id);
        return view('admin.menu.edit-menu',compact('menus'));
    }
    public function update(Request $request){
        $menu = Menu::find($request->id);
        $menu->name = $request->name;
        $menu->description = $request->description;
        $menu->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->back();
    }
}
