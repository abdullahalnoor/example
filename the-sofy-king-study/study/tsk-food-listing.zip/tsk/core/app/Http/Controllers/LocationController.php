<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Location;
use Toastr;

class LocationController extends Controller
{
    public function index(){
        $location = Location::orderBy('created_at')->paginate(10);
        return view('admin.location.index',compact('location'));
    }
    public function create(){
        return view('admin.location.create-location');
    }
    public function store(Request $request){
        $location = new Location();

        $location->name = $request->name;
        $location->status = $request->status == '' ?0:1;
        $location->save();
        Toastr::success('Information Save Successfully...');
        return redirect()->back();
    }
    public function edit($id){
        $location = Location::find($id);
        return view('admin.location.edit-location',compact('location'));
    }
    public function update(Request $request){
        $location = Location::find($request->id);

        $location->name = $request->name;
        $location->status = $request->status == '' ?0:1;
        $location->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->back();
    }
}
