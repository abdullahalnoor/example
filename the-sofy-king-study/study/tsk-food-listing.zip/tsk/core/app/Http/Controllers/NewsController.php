<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\News;
use Image;
use Toastr;

class NewsController extends Controller
{
    public function index(){
        $news = News::orderBy('created_at')->paginate(10);
        return view('admin.news.index',compact('news'));
    }

    public function create(){
        return view('admin.news.create-news');
    }

    public function store(Request $request){
        $news = new News();
        
        
        $image =  $request->file('image');
        $imageName = time().'.'.$image->getClientOriginalName();
        $directory =  'assets/frontend/img/news-image/';
        $imgUrl =  $directory.$imageName;
        Image::make($image)->save($imgUrl);
        // return $request->all();
        $news->title = $request->title;
        $news->description = $request->description;
        $news->image = $imgUrl;
        $news->status = $request->status == '' ?0:1;
        $news->save();
        Toastr::success('Information Save Successfully...');
        return redirect()->back();
    }
    public function edit($id){
        $news = News::find($id);
        return view('admin.news.edit-news',compact('news'));
    }
    public function update(Request $request){
        $news = News::find($request->id);

        if($request->hasFile('image')){
            @unlink($news->image);
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $directory = 'assets/frontend/img/news-image/';
            $imgUrl = $directory.$imageName;
            Image::make($image)->save($imgUrl);
            $news->image = $imgUrl;
        }

        $news->title = $request->title;
        $news->description = $request->description;
        $news->status = $request->status == '' ?0:1;
        $news->save();
        Toastr::success('Information Updated Successfully...');
        return redirect()->back();
    }
}
