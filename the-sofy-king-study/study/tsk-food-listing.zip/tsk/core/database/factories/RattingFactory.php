<?php

use Faker\Generator as Faker;

$factory->define(App\Ratting::class, function (Faker $faker) {
    return [
       'user_id' => App\User::all()->random()->id,
       'product_id' => App\Product::all()->random()->id,
       'rate'       => $faker->numberBetween(0,5),
       'comment'    => $faker->sentence,
    ];
});
