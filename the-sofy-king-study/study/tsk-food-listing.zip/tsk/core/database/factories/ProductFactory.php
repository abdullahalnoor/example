<?php

use Faker\Generator as Faker;

$factory->define(App\Product::class, function (Faker $faker) {
    return [
        'category_id' =>  App\Category::all()->random()->id,
        'location_id'     =>   App\Location::all()->random()->id,
        'user_id'     =>   App\User::all()->random()->id,
        'name'        => $faker->word,
        'title'       => $faker->sentence,
        'price'       => $faker->numberBetween(80,150),
        'description' =>$faker->text,
        'image' => $faker->imageUrl(),  
        'status'     => $faker->numberBetween(0,2),
    ];
});
