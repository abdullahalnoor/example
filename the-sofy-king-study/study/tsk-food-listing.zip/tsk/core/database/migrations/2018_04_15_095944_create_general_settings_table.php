<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGeneralSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('general_settings', function (Blueprint $table) {
            $table->increments('id');
            $table->string('website_title')->nullable();
            $table->string('color_code')->nullable();
            $table->string('base_currency')->nullable();
            $table->string('currency_symbol')->nullable();
            $table->tinyInteger('registration_status')->nullable()->default(0);
            $table->tinyInteger('email_verification')->nullable()->default(0);
            $table->tinyInteger('sms_verification')->nullable()->default(0);
            $table->tinyInteger('number')->nullable()->default(0);
            $table->tinyInteger('email_notification')->nullable()->default(0);
            $table->tinyInteger('sms_notification')->nullable()->default(0);
            $table->string('email')->unique()->nullable();
            $table->text('message')->nullable();
            $table->string('sms_api')->nullable();
            $table->string('phone')->nullable();
            $table->string('address')->nullable();
            $table->string('banner_title')->nullable();
            $table->text('banner_text')->nullable();
            $table->string('category_title')->nullable();
            $table->string('category_text')->nullable();
            $table->string('news_title')->nullable();
            $table->text('news_text')->nullable();
            $table->string('news_watermark')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('general_settings');
    }
}
