<div id="headerBar">
  <div class="support-bar">
    <div class=" blue-grey darken-4">
      <div class="row">
        <div class="col m4 offset-m1 left hide-on-small-only">

          <a href="#" title="bd_umbrella@gmail.com">
              <i class="fa fa-envelope" style="text-transform: lowercase;"></i>
              <span class="hide-on-med-and-down">bd_umbrella@gmail.com</span>
            </a>
          <a href="#" title="+8801524524">
              <i class="fa fa-phone"></i>
              <span class="hide-on-med-and-down">+8801524524</span>
            </a>
        </div>
        <div class="col m3  right-align hide-on-small-only">
          <a href="#">
              <i class="fa fa-facebook "></i>
            </a>
          <a href="#">
              <i class="fa fa-twitter "></i>
            </a>
          <a href="#">
              <i class="fa fa-google "></i>
            </a>
          <a href="#">
              <i class="fa fa-instagram "></i>
            </a>
        </div>
        <div class="col m4  right">
          @guest
          <a href="{{ route('register') }}">
              <i class="fa fa-registered"></i> Register
            </a>
          <a href="{{ route('login') }}">
              <i class="fa fa-sign-in"></i>
              Login
            </a> @else
          <a href="#">
                          <i class="fa fa-home"></i> Home
                        </a>
          <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                          <i class="fa fa-sign-out" ></i>
                          {{ __('Logout') }}
                        </a>

          <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
          </form>
          @endguest
        </div>
      </div>

    </div>

  </div>
  <nav class=" blue-grey darken-2">
    <div class="container">
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">
            <i class="fa fa-umbrella hide-on-small-only"></i> BD Umbrella
          </a>
        <a href="" data-target="mobile-nav" class="sidenav-trigger">
            <i class="fa fa-list" style="font-size: 30px"></i>
          </a>
        <ul class="right hide-on-med-and-down">
          <li>
            <a href="{{route('book')}}">Education</a>
          </li>
          <li>
            <a href="badges.html">Electronics</a>
          </li>
          <li>
            @guest
            <a href="{{route('sell-product')}}">Sell Book</a> @else
            <a href="{{route('user.sell-product')}}">Sell Book</a> @endguest
          </li>
          <li>

            <a href="{{route('user.buy-product')}}">Buy Book</a>
          </li>
          <li>
            <a href="badges.html">Forum</a>
          </li>
          <li>
            <a href="badges.html">Contact</a>
          </li>

          <li>
            <a class='dropdown-trigger-one btn' href='#' data-target='dropdown1'>Drop Me!</a>
            <ul id='dropdown1' class='dropdown-content'>
              <li><a href="#!">one</a></li>
              <li><a href="#!">two</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</div>

<!-- <div class="navbar-fixed">
    
  </div> -->


<ul class="sidenav" id="mobile-nav">
  <li>
    <a href="sass.html">Education</a>
  </li>
  <li>
    <a href="badges.html">Electronics</a>
  </li>
  <li>
    <a href="badges.html">Sell</a>
  </li>
  <li>
    <a href="badges.html">Buy</a>
  </li>
  <li>
    <a href="badges.html">Forum</a>
  </li>

  <li>
    <a class='dropdown-trigger-two' href='#' data-target='dropdown2'>Drop Me!</a>
    <ul id='dropdown2' class='dropdown-content'>
      <li><a href="#!">one</a></li>
      <li><a href="#!">two</a></li>
    </ul>
  </li>
</ul>

<!-- end navbar -->