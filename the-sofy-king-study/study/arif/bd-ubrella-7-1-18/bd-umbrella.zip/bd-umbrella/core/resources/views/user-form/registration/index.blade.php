@extends('frontend.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <form class="col m12  l12  s12 " action="{{route('register')}}" method="POST">
          @csrf
          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-graduation-cap prefix"></i>
              <input type="text" name="name" value="{{old('name')}}" class="validate">
              <label>Student Name</label> @if($errors->has('name'))
              <span class="helper-text red-text text-accent-4 ">
                <b>{{$errors->first('name')}}</b>
              </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-transgender-alt prefix"></i>
              <select name="gender">
                 <option value="" disabled selected>Select Your Gnder</option>
                <option value="1" {{old('gender') == 1?'selected':'' }}  >Male</option>
                <option value="2" {{old('gender') == 2?'selected':'' }}>Female </option>
                <option value="3" {{old('gender') == 3?'selected':'' }}>Others</option>
              </select>
              <label>Select Your Gnder</label> @if($errors->has('gender'))
              <span class="helper-text red-text text-accent-4 ">
                                          <b>{{$errors->first('gender')}}</b>
                                        </span> @endif
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-male prefix"></i>
              <input type="text" name="father_name" value="{{old('father_name')}}" class="validate">
              <label>Father Name</label> @if($errors->has('father_name'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('father_name')}}</b>
                            </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-female prefix"></i>
              <input type="text" name="mother_name" value="{{old('mother_name')}}" class="validate">
              <label>Mother Name</label> @if($errors->has('mother_name'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('mother_name')}}</b>
                            </span> @endif
            </div>
          </div>


          <div class="row">
            <div class="col s12">
              <div class="input-field ">
                <i class="fa fa-calendar prefix"></i>
                <input type="text" value="{{old('birth_date')}}" name="birth_date" class="datepicker">
                <label>Date of Birth</label> @if($errors->has('birth_date'))
                <span class="helper-text red-text text-accent-4 ">
                                <b>{{$errors->first('birth_date')}}</b>
                              </span> @endif
              </div>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-university prefix"></i>
              <input type="text" name="institue_name" value="{{old('institue_name')}}" class="validate">
              <label>Institute Name</label> @if($errors->has('institue_name'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('institue_name')}}</b>
                            </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-book prefix"></i>
              <input type="text" name="department_name" value="{{old('department_name')}}" class="validate">
              <label>Department Name</label> @if($errors->has('department_name'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('department_name')}}</b>
                            </span> @endif
            </div>
          </div>


          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-phone prefix"></i>
              <input type="number" name="contact_number" value="{{old('contact_number')}}" class="validate">
              <label>Contact Number </label> @if($errors->has('contact_number'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('contact_number')}}</b>
                            </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-phone prefix"></i>
              <input type="number" name="reference_contact_number" value="{{old('reference_contact_number')}}" class="validate">
              <label>References Contact Number</label> @if($errors->has('reference_contact_number'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('reference_contact_number')}}</b>
                            </span> @endif
            </div>
          </div>

          <div class="row">
            <div class="input-field col s12">
              <i class="fa fa-home prefix"></i>
              <textarea id="textarea1" name="permanent_address" class="materialize-textarea">{{old('reference_contact_number')}}</textarea>
              <label for="textarea1">permanent address </label> @if($errors->has('permanent_address'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('permanent_address')}}</b>
                            </span> @endif
            </div>
          </div>

          <div class="row">
            <div class="input-field col s12">
              <i class="fa fa-hotel prefix"></i>
              <textarea id="textarea2" name="present_address" class="materialize-textarea">{{old('present_address')}}</textarea>
              <label for="textarea1">present address</label> @if($errors->has('present_address'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('present_address')}}</b>
                            </span> @endif
            </div>
          </div>

          <div class="row">

            <div class="input-field col m6  l6 s12">
              <i class="fa fa-check prefix"></i>
              <select name="select_id">
                            <option value="" disabled selected>Select ID</option>
                            <option value="1" {{old('select_id') == 1?'selected':''}} >National ID</option>
                            <option value="2" {{old('select_id') == 2?'selected':''}}>Birth Certificate  </option>
                            <option value="3" {{old('select_id') == 3?'selected':''}}>Student ID</option>
                          </select>
              <label>Select ID</label> @if($errors->has('select_id'))
              <span class="helper-text red-text text-accent-4 ">
                                            <b>{{$errors->first('select_id')}}</b>
                                          </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-id-badge prefix"></i>
              <input type="number" name="id_number" value="{{old('id_number')}}" class="validate">
              <label>ID Number </label> @if($errors->has('id_number'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('id_number')}}</b>
                            </span> @endif
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-envelope prefix"></i>
              <input type="text" name="email" value="{{old('email')}}" class="validate">
              <label>Email</label> @if($errors->has('email'))
              <span class="helper-text red-text text-accent-4 ">
                              <b>{{$errors->first('email')}}</b>
                            </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-pencil prefix"></i>
              <input name="username" type="text" class="validate">
              <label>Username </label> @if($errors->has('username'))
              <span class="helper-text red-text text-accent-4 ">
                                            <b>{{$errors->first('username')}}</b>
                                          </span> @endif
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-key prefix"></i>
              <input type="password" class="validate">
              <label> Password</label> @if($errors->has('password'))
              <span class="helper-text red-text text-accent-4 ">
                                            <b>{{$errors->first('password')}}</b>
                                          </span> @endif
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-key prefix"></i>
              <input type="password" name="password_confirmation" class="validate">
              <label>Confirm Password </label>
            </div>
          </div>







          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit" name="action">
              <i class="fa fa-check center"></i>

              <b>
                REGISTER
              </b>
            </button>
          </div>

        </form>
      </div>


    </article>



  </div>


</div>
@endsection
 @push('script')
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems, {});

    var elems = document.querySelectorAll('.datepicker'); M.Datepicker.init(elems, {});
  });

</script>












































































































@endpush