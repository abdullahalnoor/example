@extends('user.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <div class="col m4 hide-on-small-only">
          <ul class="collection">
            <li class="collection-item  @if(request()->path() == 'user/home') red @else teal  @endif "> <a class="white-text" href="{{route('home')}}"><i class="fa fa-home"></i> Profile</a></li>
            <li class="collection-item 
                        @if(request()->path() == 'user/sell-request/all-orders') red            
                        @elseif(request()->path() == 'user/sell-request/pending-orders') red            
                        @elseif(request()->path() == 'user/sell-request/confirm-orders') red            
                        @elseif(request()->path() == 'user/sell-request/cancel-orders') red 
                        @else 
                        teal
                         @endif"> <a class="white-text" href="{{route('user.sell-request',['type'=>'all-orders'])}}"><i class="fa fa-spinner"></i> Sell Request</a></li>
            <li class="collection-item
                        @if(request()->path() == 'user/buy-request/all-orders') red 
                        @elseif(request()->path() == 'user/buy-request/pending-orders') red 
                        @elseif(request()->path() == 'user/buy-request/confirm-orders') red 
                        @elseif(request()->path() == 'user/buy-request/cancel-orders')
                        red @else teal @endif
                        
                        "> <a class="white-text" href="{{route('user.buy-request',['type'=>'all-orders'])}}"> <i class="fa fa-spinner"></i> Buy Request </a></li>
            <li class="collection-item"> <i class="fa fa-cog"></i> Change Password</li>
          </ul>
        </div>

        <div class="col m8 s12">
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px">{{$pageTitle}} </div>
          <br>

          <a class="waves-effect waves-light btn" href="{{route('user.buy-request',['type'=>'pending-orders'])}}">Pending</a>/
          <a class="waves-effect waves-light btn" href="{{route('user.buy-request',['type'=>'confirm-orders'])}}">Confirm</a>/
          <a class="waves-effect waves-light btn" href="{{route('user.buy-request',['type'=>'cancel-orders'])}}">Cancel</a>


          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              @if($buyBook->all()) @foreach($buyBook as $item)
              <tr>
                <td>{{date('Y-m-d'),strtotime($item->created_at)}}</td>
                <td>
                  @if($item->order_status == 0) Pending @elseif($item->order_status == 1) Confirm @elseif($item->order_status == 2) Cancel
                  @endif

                </td>
                <td>
                  <a href="{{route('user.buy-request.detail',$item->id)}}"> <i class="fa fa-eye"></i> view</a>
                </td>
              </tr>
              @endforeach @else
              <tr>
                <td colspan="3">
                  <h4 class="center-align red-text">No Record Found......</h4>
                </td>
              </tr>
            </tbody>
            @endif


          </table>
        </div>

      </div>


    </article>



  </div>


</div>
@endsection