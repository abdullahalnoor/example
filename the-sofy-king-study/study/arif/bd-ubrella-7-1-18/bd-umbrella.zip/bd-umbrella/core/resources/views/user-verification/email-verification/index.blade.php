@extends('user.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        @if(Session::has('alert'))
        <div class="row">
          <div class="card-panel red accent-3">
            <h5 class="white-text  center-align">
              <b>{{Session::get('alert')}}</b>
            </h5>
          </div>
        </div>
        @elseif(Session::has('success'))
        <div class="row">
          <div class="card-panel teal lighten-2">
            <h5 class="white-text  center-align">
              <b>{{Session::get('success')}}</b>
            </h5>
          </div>
        </div>
        @else
        <div class="row">
          <div class="card-panel teal lighten-2">
            <h5 class="white-text  center-align">
              <b>Please.. Verify Your Email Address !</b>
            </h5>
          </div>
        </div>
        @endif

        <form class="col m12  l12  s12 " action="{{route('user.email-verifiatcion-code')}}" method="POST">
          @csrf
          <div class="row">

            <div class="input-field co m12  l12 s12">
              <i class="fa fa-code prefix"></i>
              <input type="text" name="code" value="" class="validate">
              <label>code </label>
            </div>
          </div>

          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit">
              <i class="fa fa-check center"></i>

              <b>
                submit code
              </b>
            </button>
          </div>
        </form>


        <div class="row">
          <a href="{{route('user.email-verifiatcion-code')}}" class="btn-large waves-effect waves-light" style="width: 100%">
            <i class="fa fa-forward center"></i>
            <b>
              SEND CODE
            </b>
          </a>
        </div>


      </div>


    </article>



  </div>


</div>
@endsection