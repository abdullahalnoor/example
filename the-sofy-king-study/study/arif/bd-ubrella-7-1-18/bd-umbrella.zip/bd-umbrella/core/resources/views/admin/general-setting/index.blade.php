@extends('admin.master') 
@section('title','General Setting') 
@section('content')

<div class="app-title">
  <div>
    <h1 class="text-primary">
      <i class="fa fa-edit"></i> General Setting</h1>
    <p class="text-danger">
      Update General Setting Information
    </p>
  </div>

</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <form action="{{route('admin.general-setting.update')}}" method="POST">
        {{csrf_field()}}
        <div class="tile-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">
                  <strong style="text-transform: capitalize;">website name</strong>
                </label>
                <input class="form-control" type="text" name="site_name" value="{{$generalSetting->site_name}}">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">
                  <strong style="text-transform: capitalize;"> Website Title</strong>
                </label>
                <input class="form-control" type="text" name="site_title" value="{{$generalSetting->site_title}}">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">
                  <strong style="text-transform: capitalize;">Currency Name</strong>
                </label>
                <input class="form-control" type="text" name="currency" value="{{$generalSetting->currency}}">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">
                  <strong style="text-transform: capitalize;">Currency Symbol </strong>
                </label>
                <input class="form-control" type="text" name="currency_symbol" value="{{$generalSetting->currency_symbol}}">
              </div>
            </div>
          </div>
        </div>
        <div class="tile-footer">
          <button class="btn btn-primary btn-block" type="submit">
            <i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
        </div>
      </form>
    </div>
  </div>

  <div class="clearix"></div>

</div>
@endsection