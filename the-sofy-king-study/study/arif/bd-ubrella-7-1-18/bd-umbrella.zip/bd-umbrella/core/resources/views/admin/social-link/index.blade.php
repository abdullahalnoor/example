@extends('admin.master') 
@section('title', 'Social Links') @push('css')
<link rel="stylesheet" href="{{asset('assets/admin/css/fontawesome-iconpicker.min.css')}}"> 
@endpush 
@section('content')
<div class="app-title">
  <div>
    <h1 class="text-primary"><i class="fa fa-eye"></i>Social Links</h1>
    <p class="text-danger">Social Links Information </p>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <div class="col-md-12">
          <div class="tile">
            <p class="tile-title">Social Links List <a id="addSclLnk" class="btn btn-primary float-right text-white"><i class="fa fa-plus"></i>Add New </a></p>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Icon</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td><a class="btn btn-info text-white"><i class="fa fa-edit"></i>Edit </a><a class="btn btn-danger text-white"><i class="fa fa-trash"></i>Delete </a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="clearix"></div>

</div>
<div id="modals"></div>
@endsection
 @push('js')
<script src="{{asset('assets/admin/js/fontawesome-iconpicker.min.js')}}"></script>
<script>
  $(document).on('focus', '.socioicon', function () {
  $('.socioicon').iconpicker();
}

);
$(document).ready(function () {
  $.ajaxSetup( {
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  }
  );
  $("#addSclLnk").on("click", function (e) {
    e.preventDefault();
    $.get("{{route('admin.social-link.create')}}", function (data) {
      $("#modals").empty().append(data);
      $("#socialModal").modal("show");
    }
    );
  }
  );
}

);

</script>


@endpush