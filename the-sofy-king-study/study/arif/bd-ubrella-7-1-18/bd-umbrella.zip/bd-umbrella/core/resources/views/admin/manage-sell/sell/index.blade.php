@extends('admin.master') 
@section('title',$pageTitle) 
@section('content')

<div class="app-title">
  <div>
    <h1><i class="fa fa-users"></i> {{$pageTitle}}</h1>
    <p>Manage {{$pageTitle}}</p>
  </div>

</div>

<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @if($sellProducts->all()) @foreach($sellProducts as $item)
            <tr>
              <td>
                @if(empty($item->user_id)) {{$item->name}} @else {{$item->user->name}} @endif
              </td>
              <td>
                @if(empty($item->user_id)) {{$item->email}} @else {{$item->user->email}} @endif
              </td>
              <td>
                @if($item->order_status == 0)
                <span class="bg-info p-1 text-white">Pending</span> @elseif($item->order_status == 1)
                <span class="bg-success p-1 text-white">Confirmed</span> @elseif($item->order_status == 2)
                <span class="bg-danger p-1 text-white">Cancel</span> @endif
              </td>
              <td>
                <a href="{{route('admin.sell.order-detail',$item->id)}}" class="btn btn-primary"> <i class="fa fa-eye"></i> View</a>
              </td>
            </tr>
            @endforeach @else
            <tr>
              <td colspan="4">
                <h3 class="text-center text-danger">No Record Found...</h3>
              </td>
            </tr>
            @endif
          </tbody>
        </table>
      </div>
      <div class="row justify-content-center">
        {{$sellProducts->links()}}
      </div>
    </div>
  </div>
</div>
@endsection