<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>BD-Umbrella</title>
  <link rel="stylesheet" href="{{asset('assets/frontend/css/materialize.min.css')}}">
  <link rel="stylesheet" href="{{asset('assets/frontend/css/font-awesome.min.css')}}">
  <link rel="stylesheet" href="{{asset('assets/frontend/css/style.css')}}">



</head>

<body>
  @include('frontend.includes.header') @yield('content')
  @include('frontend.includes.footer')






  <script src="{{asset('assets/frontend/js/materialize.min.js')}}"></script>
  <script src="{{asset('assets/frontend/js/jquery.min.js')}}"></script>
  <script>
    var sideNav = document.querySelector('.sidenav');
    M.Sidenav.init(sideNav, {});
    document.addEventListener('DOMContentLoaded', function() { var elems = document.querySelectorAll('.dropdown-trigger-one'); var
    instances = M.Dropdown.init(elems, {}); });
    document.addEventListener('DOMContentLoaded', function() { var elems = document.querySelectorAll('.dropdown-trigger-two');
    var instances = M.Dropdown.init(elems, {}); });
  </script>

  @stack('script')

</body>

</html>