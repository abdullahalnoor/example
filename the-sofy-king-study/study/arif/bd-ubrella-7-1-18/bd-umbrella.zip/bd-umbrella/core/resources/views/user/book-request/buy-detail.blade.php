@extends('user.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <div class="col m4 hide-on-small-only">
          <ul class="collection">
            <li class="collection-item  @if(request()->path() == 'user/home') red @else teal  @endif "> <a class="white-text" href="{{route('home')}}"><i class="fa fa-home"></i> Profile</a></li>
            <li class="collection-item 
                                  @if(request()->path() == 'user/sell-request/all-orders') red            
                                  @elseif(request()->path() == 'user/sell-request/pending-orders') red            
                                  @elseif(request()->path() == 'user/sell-request/confirm-orders') red            
                                  @elseif(request()->path() == 'user/sell-request/cancel-orders') red 
                                  @else 
                                  teal
                                   @endif"> <a class="white-text" href="{{route('user.sell-request',['type'=>'all-orders'])}}"><i class="fa fa-spinner"></i> Sell Request</a></li>
            <li class="collection-item
                                  @if(request()->path() == 'user/buy-request/all-orders') red 
                                  @elseif(request()->path() == 'user/buy-request/pending-orders') red 
                                  @elseif(request()->path() == 'user/buy-request/confirm-orders') red 
                                  @elseif(request()->path() == 'user/buy-request/cancel-orders')
                                  red @else teal @endif
                                  
                                  "> <a class="white-text" href="{{route('user.buy-request',['type'=>'all-orders'])}}"> <i class="fa fa-spinner"></i> Buy Request </a></li>
            <li class="collection-item"> <i class="fa fa-cog"></i> Change Password</li>
          </ul>
        </div>
        <a class="waves-effect waves-light btn" href="{{route('user.buy-request',['type'=>'pending-orders'])}}">Pending</a>        /
        <a class="waves-effect waves-light btn" href="{{route('user.buy-request',['type'=>'confirm-orders'])}}">Confirm</a>/
        <a class="waves-effect waves-light btn" href="{{route('user.buy-request',['type'=>'cancel-orders'])}}">Cancel</a>
        <br> <br>
        <div class="col m8 s12">
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px"> <i class="fa fa-info"></i> Order Info </div>
          <br>




          <table>
            <tr>
              <td>Order Status </td>
              <td>
                @if($orderDetail->order_status == 0)
                <span class="bg-info p-1 text-white">Pending</span> @elseif($orderDetail->order_status == 1)
                <span class="bg-primary p-1 text-white">Confirmed</span> @elseif($orderDetail->order_status == 2)
                <span class="bg-danger p-1 text-white">Cancel</span> @endif
              </td>
            </tr>
            <tr>
              <td>Payment Type</td>
              <td>
                @if($orderDetail->payment_type == 1)
                <span class="bg-info p-1 text-white">Hand Cash</span> @elseif($orderDetail->payment_type == 2)
                <span class="bg-info p-1 text-white">Bkash</span> @endif
              </td>
            </tr>
            <tr>
              <td>Order Status</td>
              <td>@if($orderDetail->order_status == 0)
                <span class="blue  white-text">Pending</span> @elseif($orderDetail->order_status == 1)
                <span class="teal  white-text">Confirmed</span> @elseif($orderDetail->order_status == 2)
                <span class="red  white-text">Cancel</span> @endif</td>
            </tr>
            <tr>
              <td>Email</td>
              <td>
                @if(empty($orderDetail->user_id)) {{$orderDetail->email}} @else {{$orderDetail->user->email}} @endif
              </td>
            </tr>
            <tr>
              <td>Contact Number</td>
              <td>
                @if(empty($orderDetail->user_id)) {{$orderDetail->contact_number}} @else {{$orderDetail->user->contact_number}} @endif

              </td>
            </tr>
          </table>

          <br>
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px">
            <i class="fa fa-book"></i> Book List </div>
          <br>


          <table class="table table-hover">
            <thead>
              <tr>
                <th>Book</th>
                <th>Author</th>
                <th>Edition </th>
                <th>Year</th>
              </tr>
            </thead>
            <tbody>
              @foreach($orderDetail->bookList as $item)
              <tr>
                <td>{{$item->book}}</td>
                <td>{{$item->author}}</td>
                <td>{{$item->edition}}</td>
                <td>{{$item->year}}</td>
              </tr>
              @endforeach
            </tbody>
          </table>



        </div>

      </div>


    </article>



  </div>


</div>
@endsection