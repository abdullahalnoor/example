@extends('user.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">

        <div class="row centered">
          <div class="col l4 m6 s12">
            <div class="card-panel">
              <span class="blue-text text-darken-2">
                    Name : {{$user->name}}      
                   </span>
            </div>
          </div>
          <div class="col l4 m6 s12">
            <div class="card-panel">
              <span class="blue-text text-darken-2">
                                  Contact No : {{$user->contact_number}}      
                                 </span>
            </div>
          </div>
          <div class="col l4 m6 s12">
            <div class="card-panel">
              <span class="blue-text text-darken-2">
                                                Email : {{$user->email}}      
                                               </span>
            </div>
          </div>
        </div>


        <form class="col m12  l12  s12 " action="{{route('user.buy-product')}}" method="POST">
          @csrf


          <div class="row">

            <div class="input-field col m6  l6 s12">
              <i class="fa fa-check prefix"></i>
              <select name="payment_type">
                <option value="" disabled selected>Select One</option>
                <option value="1" {{old( 'payment_type')==1 ? 'selected': ''}}>Handcash </option>
                <option value="2" {{old( 'payment_type')==2 ? 'selected': ''}}>Bkash </option>

              </select>
              <label>Payment Type</label> @if($errors->has('payment_type'))
              <span class="helper-text red-text text-accent-4 ">
                <b>{{$errors->first('payment_type')}}</b>
              </span> @endif
            </div>

          </div>



          <div id="concateField">


          </div>
          <div class="col s12">

            <button type="button" class="btn btn-large" id="addField">Add Book List </button>

          </div>
          <br/>
          <br/>
          <br/>
          <br/>

          <div class="row">
            <div class="input-field col s12">
              <i class="fa fa-truck prefix"></i>
              <textarea id="textarea2" name="address" class="materialize-textarea">{{old('address')}}</textarea>
              <label for="textarea1"> Shipping Address... </label> @if($errors->has('address'))
              <span class="helper-text red-text text-accent-4 ">
                <b>{{$errors->first('address')}}</b>
              </span> @endif
            </div>
          </div>

          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit" name="action">
              <i class="fa fa-check center"></i>

              <b style="text-transfor:uppercase">
                submit your request
              </b>
            </button>
          </div>

        </form>
      </div>


    </article>



  </div>


</div>
@endsection
 @push('script')
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems, {});

    var elems = document.querySelectorAll('.datepicker');
    M.Datepicker.init(elems, {});
  });

  $(document).ready(function () { 
    var max = 1;
     $("#addField").on('click', function (e) {
        e.preventDefault(); 
        appendField($('#concateField'));
    });
     $(document).on('click','.itemInputs',function(){ 
       $(this).closest('.removeItem').remove(); 
       }); 
       function appendField(formGroup) { 
         max++;
          formGroup.append(
       '<div class="removeItem">'+ 
    '  <div class="row">'+ 
        '<div class="input-field col m6  l6 s12">'+ 
          '<i class="fa fa-book prefix"></i>'+ 
         ' <input type="text" name="book[]" value="{{old('book')}}" class="validate" required>'+ 
          '<label>Book Name </label>'+
           ' @if($errors->has('book'))'+ 
          '<span class="helper-text red-text text-accent-4 ">'+
                                                    '<b>{{$errors->first('book')}}</b>'+
                                                  '</span> @endif'+ 
       ' </div>'+ 
        '<div class="input-field col m6  l6 s12">'+ 
          '<i class="fa fa-pencil prefix"></i>'+ ' <input type="text" name="author[]" value="{{old('author')}}" class="validate"required>'+ 
          '<label>Writter Name</label>'+ 
          '@if($errors->has('author'))'+ 
          '<span class="helper-text red-text text-accent-4 ">'+
                                                                  '<b>{{$errors->first('author')}}</b>'+
                                                                '</span> @endif'+ 
        '</div>'+ 
        ' </div>'+ 
      '<div class="row">'+ 
        '<div class="input-field col m6  l6 s12">'+ 
          '<i class="fa fa-pencil prefix"></i>'+ 
          '<input type="text" name="edition[]" value="{{old('edition')}}" class="validate" required>'+  '<label>Edition </label>'+
           '@if($errors->has('edition'))'+
            ' <span class="helper-text red-text text-accent-4 ">'+
                                                              '<b>{{$errors->first('edition')}}</b>'+
                                                            '</span> @endif'+ 
                                                            ' </div>'+ 
        '<div class="input-field col m6  l6 s12">'+ 
          '<i class="fa fa-pencil prefix"></i>'+ 
         '<input type="text" name="year[]" value="{{old('year')}}" class="validate" required>'+ 
          '<label>Year </label> @if($errors->has('year'))'+ 
          '<span class="helper-text red-text text-accent-4 ">'+
                                                                            '<b>{{$errors->first('year')}}</b>'+
                                                                         ' </span> @endif'+
                                                                          ' </div>'+ 
     ' </div>'+ 
 ' <div class="row">'+ 
        '<div class="col m6 l6 s12">'+ 
          '<button type="button" class="btn red itemInputs">'+
          '<i class="fa fa-trash "></i>'+          
               'Remove</button>'+ 
        '</div>'+ 
      '</div>'+ 
   '</div>'+ 
 '<br>'+
    '</div>' 
    ); } });

</script>


























































@endpush