<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>BD-Umbrella</title>
  <link rel="stylesheet" href="{{asset('assets/user/css/materialize.min.css')}}">
  <link rel="stylesheet" href="{{asset('assets/user/css/font-awesome.min.css')}}">
  <link rel="stylesheet" href="{{asset('assets/user/css/style.css')}}">



</head>

<body>
  @include('user.includes.header') @yield('content')
  @include('user.includes.footer')






  <script src="{{asset('assets/user/js/materialize.min.js')}}"></script>
  <script src="{{asset('assets/user/js/jquery.min.js')}}"></script>
  <script>
    var sideNav = document.querySelector('.sidenav');
    M.Sidenav.init(sideNav, {});
  </script>

  @stack('script')

</body>

</html>