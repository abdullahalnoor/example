@extends('admin.master') 
@section('title',$pageTitle) 
@section('content')

<div class="app-title">
  <div>
    <h1><i class="fa fa-users"></i> {{$pageTitle}}</h1>
    <p>Manage {{$pageTitle}}</p>
  </div>

</div>

<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @if($users->all()) @foreach($users as $user)
            <tr>
              <td>{{$user->name}}</td>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            @endforeach @else
            <tr>
              <td colspan="4">
                <h3 class="text-center text-danger">No Record Found...</h3>
              </td>
            </tr>
            @endif
          </tbody>
        </table>
      </div>
      <div class="row justify-content-center">
        {{$users->links()}}
      </div>
    </div>
  </div>
</div>
@endsection