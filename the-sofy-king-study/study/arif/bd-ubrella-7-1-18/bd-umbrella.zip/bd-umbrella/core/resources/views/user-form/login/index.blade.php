@extends('frontend.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <form class="col m12  l12  s12 " action="{{route('login')}}" method="POST">
          @csrf

          <div class="row">
            @if(Session::has('success'))
            <div class="card-panel red accent-3">
              <h5 class="white-text  center-align">
                <b>{{Session::get('success')}}</b>
              </h5>
            </div> @endif
            <div class="input-field co m12  l12 s12">
              <i class="fa fa-pencil prefix"></i>
              <input type="text" name="username" value="{{old('username')}}" class="validate">
              <label>Username </label> @if($errors->has('username'))
              <span class="helper-text red-text text-accent-4 ">
                                            <b>{{$errors->first('username')}}</b>
                                          </span> @endif
            </div>
          </div>
          <div class="row">

            <div class="input-field co m12  l12 s12">
              <i class="fa fa-key prefix"></i>
              <input type="text" name="password" value="{{old('password')}}" class="validate">
              <label>Password </label> @if($errors->has('password'))
              <span class="helper-text red-text text-accent-4 ">
                                            <b>{{$errors->first('password')}}</b>
                                          </span> @endif
            </div>
          </div>

          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit" name="action">
              <i class="fa fa-check center"></i>

              <b>
                {{__('LOGIN')}}
              </b>
            </button>
          </div>

        </form>
      </div>


    </article>



  </div>


</div>
@endsection