@extends('user.master') 
@section('content')

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <div class="col m4 hide-on-small-only">
          <ul class="collection">
            <li class="collection-item  @if(request()->path() == 'user/home') red @else teal  @endif "> <a class="white-text" href="{{route('home')}}"><i class="fa fa-home"></i> Profile</a></li>
            <li class="collection-item 
                      @if(request()->path() == 'user/sell-request/all-orders') red            
                      @elseif(request()->path() == 'user/sell-request/pending-orders') red            
                      @elseif(request()->path() == 'user/sell-request/confirm-orders') red            
                      @elseif(request()->path() == 'user/sell-request/cancel-orders') red 
                      @else 
                      teal
                       @endif"> <a class="white-text" href="{{route('user.sell-request',['type'=>'all-orders'])}}"><i class="fa fa-spinner"></i> Sell Request</a></li>
            <li class="collection-item
                      @if(request()->path() == 'user/buy-request/all-orders') red 
                      @elseif(request()->path() == 'user/buy-request/pending-orders') red 
                      @elseif(request()->path() == 'user/buy-request/confirm-orders') red 
                      @elseif(request()->path() == 'user/buy-request/cancel-orders')
                      red @else teal @endif
                      
                      "> <a class="white-text" href="{{route('user.buy-request',['type'=>'all-orders'])}}"> <i class="fa fa-spinner"></i> Buy Request </a></li>
            <li class="collection-item teal"> <a class="white-text" href=""><i class="fa fa-cog"></i> Change Password</a> </li>
          </ul>
        </div>

        <div class="col m8 s12">
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px">Personal Information </div>
          <table>
            <tr>
              <td>Name</td>
              <td>{{Auth::user()->name}}</td>
            </tr>
            <tr>
              <td>Father Name</td>
              <td>{{Auth::user()->father_name}}</td>
            </tr>
            <tr>
              <td>Mother Name</td>
              <td>{{Auth::user()->mother_name}}</td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>
                @if(Auth::user()->gender == 1) Male @elseif(Auth::user()->gender == 2) Female @elseif(Auth::user()->gender == 3) Others @endif
              </td>
            </tr>
            <tr>
              <td>Permanent Address</td>
              <td>{{Auth::user()->permanent_address}}</td>
            </tr>
            <tr>
              <td>Present Address</td>
              <td>{{Auth::user()->present_address}}</td>
            </tr>
            <tr>
              <td>Contact Number</td>
              <td>{{Auth::user()->contact_number}}</td>
            </tr>
            <tr>
              <td>Reference Contact Number</td>
              <td>{{Auth::user()->reference_contact_number}}</td>
            </tr>
            <tr>
              <td>Birth Date</td>
              <td>{{Auth::user()->birth_date}}</td>
            </tr>
            <tr>
              <td>Institue Name</td>
              <td>{{Auth::user()->institue_name}}</td>
            </tr>
            <tr>
              <td>Department Name</td>
              <td>{{Auth::user()->department_name}}</td>
            </tr>
            <tr>
              <td>Email</td>
              <td>{{Auth::user()->email}}</td>
            </tr>
            <tr>
              <td>Username</td>
              <td>{{Auth::user()->username}}</td>
            </tr>
          </table>
        </div>

      </div>


    </article>



  </div>


</div>
@endsection