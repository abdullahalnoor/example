<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBookListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('book_lists', function (Blueprint $table) {
            $table->increments('id');
             $table->integer('sell_book_id')->unsigned()->nullable();
            $table->foreign('sell_book_id')->references('id')->on('sell_books');
            $table->integer('buy_book_id')->unsigned()->nullable();
            $table->foreign('buy_book_id')->references('id')->on('buy_books');
            $table->string('book');
            $table->string('author');
            $table->string('edition');
            $table->string('year');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('book_lists');
    }
}
