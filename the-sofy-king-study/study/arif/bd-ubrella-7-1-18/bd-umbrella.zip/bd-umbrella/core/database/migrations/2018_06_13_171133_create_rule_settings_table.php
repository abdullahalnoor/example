<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRuleSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rule_settings', function (Blueprint $table) {
            $table->increments('id');
            $table->tinyInteger('registration_status')->default(0);
            $table->tinyInteger('request_status')->default(0);
            $table->tinyInteger('email_verification')->default(0);
            $table->tinyInteger('sms_verification')->default(0);
            $table->tinyInteger('email_notification')->default(0);
            $table->tinyInteger('sms_notification')->default(0);
            $table->tinyInteger('nid_verification')->default(0);
            $table->tinyInteger('birth_certificate_verification')->default(0);
            $table->integer('student_id_verification')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rule_settings');
    }
}
