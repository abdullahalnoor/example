<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name',30);
            $table->tinyInteger('gender');
            $table->string('father_name',30);
            $table->string('mother_name',30);
            $table->string('permanent_address',150)->nullable();
            $table->string('present_address',150)->nullable();
            $table->bigInteger('contact_number')->length(20);
            $table->bigInteger('reference_contact_number')->nullable();
            $table->string('birth_date',20);
            $table->string('institue_name',50);
            $table->string('department_name',20);
            $table->bigInteger('student_id')->nullable();
            $table->bigInteger('nid_number')->nullable();
            $table->bigInteger('birth_certificate_number')->nullable();
            $table->string('username',30)->unique();
            $table->string('email',30)->unique();
            $table->string('password');
            $table->tinyInteger('status');
            $table->tinyInteger('email_verify')->nullable();
            $table->tinyInteger('sms_verify')->nullable();
            $table->tinyInteger('nid_verify')->nullable();
            $table->tinyInteger('birth_certificate_verify')->nullable();
            $table->tinyInteger('student_id_verify')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
