<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SellBook;
use App\BuyBook;
use Toastr;

class ManageBookController extends Controller
{
     public function viewAllSellOrders($type){
          
        switch($type){
            case 'pending-orders':
                $sellProducts  = SellBook::where('order_status',0)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Pending Orders';
                break;
            case 'confirm-orders':
                $sellProducts  = SellBook::where('order_status',1)->orderBy('created_at','desc')->paginate(15); 
                $pageTitle = 'Confirm Orders';
                break;
             case 'cancel-orders':
                $sellProducts  = SellBook::where('order_status',2)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Cancel Orders';
                break; 
            default:       
                $sellProducts  = SellBook::orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'All Orders';
                break;  
        }
        return view('admin.manage-sell.sell.index',[
            'sellProducts'     => $sellProducts,
            'pageTitle' => $pageTitle,
        ]);
    }

    public function viewSellOrderDetail($id){
        $orderDetail = SellBook::findOrFail($id);
         return view('admin.manage-sell.single.index',[
            'orderDetail'     => $orderDetail,
        ]);
    }


    public function changeSellOrderStatus(Request $request){
        $status = SellBook::findOrFail($request->id);
        $status->order_status = $request->status;
        $status->save();
        Toastr::success('Order Status Change Successfully...');
        return back();
    }








    
      public function viewAllBuyOrders($type){
        
        switch($type){
            case 'pending-orders':
                $buyProducts  = BuyBook::where('order_status',0)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Pending Orders';
                break;
            case 'confirm-orders':
                $buyProducts  = BuyBook::where('order_status',1)->orderBy('created_at','desc')->paginate(15); 
                $pageTitle = 'Confirm Orders';
                break;
             case 'cancel-orders':
                $buyProducts  = BuyBook::where('order_status',2)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Cancel Orders';
                break; 
            default:       
                $buyProducts  = BuyBook::orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'All Orders';
                break;  
        }
        // dd($buyProducts);
        return view('admin.manage-buy.buy.index',[
            'buyProducts'     => $buyProducts,
            'pageTitle' => $pageTitle,
        ]);
    }

    public function viewBuyOrderDetail($id){
        $orderDetail = BuyBook::findOrFail($id);
         return view('admin.manage-buy.single.index',[
            'orderDetail'     => $orderDetail,
        ]);
    }


     public function changeBuyOrderStatus(Request $request){
        $status = BuyBook::findOrFail($request->id);
        $status->order_status = $request->status;
        $status->save();
        Toastr::success('Order Status Change Successfully...');
        return back();
    }


}
