<?php


use App\GeneralSetting;


  if (! function_exists('send_email')) {
      
        function send_email($to, $name, $subject, $message)
        {
            $gnl = GeneralSetting::first();

            $template = $gnl->message;
            $from = $gnl->email;
          if($gnl->email_verification == 0)
            {

              $headers = "From: $gnl->website_title <$from> \r\n";
              $headers .= "Reply-To: $gnl->website_title <$from> \r\n";
              $headers .= "MIME-Version: 1.0\r\n";
              $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

              $mm = str_replace("{{name}}",$name,$template);     
              $message = str_replace("{{message}}",$message,$mm); 

                if (@mail($to, $subject, $message, $headers)) {
                  // echo 'Your message has been sent.';
                } else {
                //echo 'There was a problem sending the email.';
                }

            }

        }
  }

if (! function_exists('send_sms')) 
{
    
    function send_sms( $to, $sms)
    {
        $gnl = GeneralSetting::first();
		if($gnl->sms_verification == 0)
		{

			$sendtext = urlencode($sms);
		    $appi = $gnl->sms_api;
			$appi = str_replace("{{number}}",$to,$appi);     
			$appi = str_replace("{{message}}",$sendtext,$appi); 
			$result = file_get_contents($appi);
		}

    }
}

