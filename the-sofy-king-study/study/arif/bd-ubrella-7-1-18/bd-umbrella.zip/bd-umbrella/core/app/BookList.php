<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookList extends Model
{
    public function sellBook(){
        return $this->belongtsTo('App\SellBook');
    }
     public function buyBook(){
        return $this->belongtsTo('App\SellBook');
    }
}
