<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\RuleSetting;
use Illuminate\Support\Facades\Input;
use Toastr;

class RuleSettingController extends Controller
{
    public function viewRuleSetting(){
        $ruleSetting = RuleSetting::first(); 
        return view('admin.rule-setting.index',compact('ruleSetting'));
    }

    public function changeRule(Request $request){
        $ruleSetting =  RuleSetting::first();
        if (Input::has('registration_status')){
            $ruleSetting->registration_status = $request->registration_status == 1 ? 1 : 0;
            $ruleSetting->save();
        }elseif(Input::has('request_status')){
             $ruleSetting->request_status = $request->request_status == 1 ? 1 : 0;
            $ruleSetting->save();
        }elseif(Input::has('email_verification')){
             $ruleSetting->email_verification = $request->email_verification == 1 ? 1 : 0;
            $ruleSetting->save();
        }elseif(Input::has('sms_verification')){
             $ruleSetting->sms_verification = $request->sms_verification == 1 ? 1 : 0;
            $ruleSetting->save();
        }elseif(Input::has('email_notification')){
             $ruleSetting->email_notification = $request->email_notification == 1 ? 1 : 0;
            $ruleSetting->save();
        }elseif(Input::has('sms_notification')){
             $ruleSetting->sms_notification = $request->sms_notification == 1 ? 1 : 0;
            $ruleSetting->save();
        }
       Toastr::success('Information Updated Successfully...');
        return redirect()->route('admin.rules-setting');
    }
}
