<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Auth;
use App\SellBook;
use App\BuyBook;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth','verify.user']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        // if(Session::has('link')){
        //     $previousPage  = Session::get('link');
        //     Session::forget('link');
        //     return redirect($previousPage);
        //  }else{
        //     return view('user.home.index');
        // }
        return view('user.home.index');
    }

    public function viewSellRequest($type){

          switch($type){
            case 'pending-orders':
                $sellBook  = SellBook::where('user_id',Auth::id())->where('order_status',0)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Pending Orders';
                break;
            case 'confirm-orders':
                $sellBook  = SellBook::where('user_id',Auth::id())->where('order_status',1)->orderBy('created_at','desc')->paginate(15); 
                $pageTitle = 'Confirm Orders';
                break;
             case 'cancel-orders':
                $sellBook  = SellBook::where('user_id',Auth::id())->where('order_status',2)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Cancel Orders';
                break; 
            default:       
                $sellBook  = SellBook::where('user_id',Auth::id())->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'All Orders';
                break;  
        }
      


        return view('user.book-request.sell',[
            'sellBook'     => $sellBook,
            'pageTitle' => $pageTitle,
        ]);
    }


    public function viewSellRequestDetail($id){
         $orderDetail = SellBook::findOrFail($id);
         Session::flash('actve','red');
        return view('user.book-request.sell-detail',[
            'orderDetail'=>$orderDetail
        ]);
    }


      public function viewBuyRequest($type){

          switch($type){
            case 'pending-orders':
                $buyBook  = BuyBook::where('user_id',Auth::id())->where('order_status',0)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Pending Orders';
                break;
            case 'confirm-orders':
                $buyBook  = BuyBook::where('user_id',Auth::id())->where('order_status',1)->orderBy('created_at','desc')->paginate(15); 
                $pageTitle = 'Confirm Orders';
                break;
             case 'cancel-orders':
                $buyBook  = BuyBook::where('user_id',Auth::id())->where('order_status',2)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Cancel Orders';
                break; 
            default:       
                $buyBook  = BuyBook::where('user_id',Auth::id())->orderBy('created_at','desc')->paginate(1);
                $pageTitle = 'All Orders';
                break;  
        }
      


        return view('user.book-request.buy',[
            'buyBook'     => $buyBook,
            'pageTitle' => $pageTitle,
        ]);
    }


    public function viewBuyRequestDetail($id){
         $orderDetail = BuyBook::findOrFail($id);
        return view('user.book-request.buy-detail',[
            'orderDetail'=>$orderDetail
        ]);
    }


}
