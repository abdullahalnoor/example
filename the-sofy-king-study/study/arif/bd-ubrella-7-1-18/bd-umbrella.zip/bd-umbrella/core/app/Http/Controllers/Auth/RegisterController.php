<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\RuleSetting;
use Illuminate\Http\Request;
use Carbon\Carbon;



class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|string|max:30',
            'gender' => 'required|integer',
            'select_id' => 'required|integer',
            'father_name' => 'required|string|max:30',
            'mother_name' => 'required|string|max:30',
            'permanent_address' => 'required|string|max:150',
            'present_address' => 'required|string|max:150',
            'contact_number' => 'required|digits_between:1,20|numeric',
            'reference_contact_number' => 'required|digits_between:1,20|numeric',
            'birth_date' => 'required|string|max:20',
            'institue_name' => 'required|string|max:50',
            'department_name' => 'required|string|max:20',
            'id_number' => 'required|digits_between:1,20|numeric',
            'username' => 'required|string|max:30|unique:users',
            'email' => 'required|string|email|max:30|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $ruleSetting = RuleSetting::first();

         $nid_number =0;
         $birth_certificate_number =0;
         $student_id =0;

        if($data['select_id'] == 1 ){
             $nid_number = $data['id_number'];
        }elseif($data['select_id'] == 2 ){
            $birth_certificate_number = $data['id_number'];
        }elseif($data['select_id'] == 3 ){
            $student_id = $data['id_number'];
        }

        return User::create([
            'name' => $data['name'],
            'gender' => $data['gender'],
            'father_name' => $data['father_name'],
            'mother_name' => $data['mother_name'],
            'permanent_address' => $data['permanent_address'],
            'present_address' => $data['present_address'],
            'contact_number' => $data['contact_number'],
            'reference_contact_number' => $data['reference_contact_number'],
            'birth_date' => $data['birth_date'],
            'institue_name' => $data['institue_name'],
            'department_name' => $data['department_name'],
            'student_id' =>  $student_id != 0?$student_id:0,
            'nid_number' => $nid_number != 0?$nid_number:0,
            'birth_certificate_number' => $birth_certificate_number != 0?$birth_certificate_number:0,
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'ststus' => $ruleSetting->registration_status,
            'email_verify' => $ruleSetting->email_verification,
            'sms_verify' => $ruleSetting->sms_verification,
            'nid_verify' => $ruleSetting->nid_verification,
            'birth_certificate_verify' => $ruleSetting->birth_certificate_verification,
            'student_id_verify' => $ruleSetting->student_id_verification,
            'sent_time' => Carbon::now(),

        ]);
       
    }
}
