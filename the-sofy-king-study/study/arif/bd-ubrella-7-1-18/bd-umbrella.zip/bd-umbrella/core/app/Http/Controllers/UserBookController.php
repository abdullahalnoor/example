<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\BuyBook;
use App\SellBook;
use Session;
use Illuminate\Support\Facades\Input;
use App\BookList;

class UserBookController extends Controller
{
    
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth','verify.user']);
    }


    public function showBuyProductForm(){
        if(Auth::check()){
             $user = Auth::user();
            return view('user.buy.index',compact('user'));
        }
        Session::put(['link' => url()->current()]);
        Session::flash('success','If you want to buy you must be log in...');
        return view('user-form.login.index');
    }

    public function saveBuyProductInfo(Request $request){

        $this->validate($request,$this->rules());


         $inputs  = Input::except(['_token','payment_type','address']);

          

        if(!empty($inputs['book'])){
        $buyBook = new BuyBook();
        $buyBook->user_id =  Auth::user()->id;
        $buyBook->payment_type =  $request->payment_type;
        $buyBook->address =  $request->address;
        $buyBook->save();
                for($i = 0; $i < count($inputs['book']); $i++){
                    $bookList = new BookList();
                    $bookList->buy_book_id = $buyBook->id;
                    $bookList->book = $request->book[$i];
                    $bookList->author = $request->author[$i];
                    $bookList->edition = $request->edition[$i];
                    $bookList->year = $request->year[$i];
                    $bookList->save();
                }
        }else{
            return 0;
        }  

        
        return back();
    }

   


    public function showsSellProductForm(){
        $user = Auth::user();
        // dd($user);
        return view('user.sell.index',compact('user'));
    }


    public function saveSellProductInfo(Request $request){
        $this->validate($request,$this->rules());

         $inputs  = Input::except(['_token','payment_type','address']);

          

        if(!empty($inputs['book'])){
       $sellBook = new SellBook();
        $sellBook->user_id =  Auth::user()->id;
        $sellBook->payment_type =  $request->payment_type;
        $sellBook->address =  $request->address;
        $sellBook->save();
                for($i = 0; $i < count($inputs['book']); $i++){
                    $bookList = new BookList();
                    $bookList->sell_book_id = $sellBook->id;
                    $bookList->book = $request->book[$i];
                    $bookList->author = $request->author[$i];
                    $bookList->edition = $request->edition[$i];
                    $bookList->year = $request->year[$i];
                    $bookList->save();
                }
        }else{
            return 0;
        }  
      
       
        return back();
    }


     private function rules(){
        return [
            'payment_type' => 'required',
            'address' => 'required|max:190',
        ];
    }

}
