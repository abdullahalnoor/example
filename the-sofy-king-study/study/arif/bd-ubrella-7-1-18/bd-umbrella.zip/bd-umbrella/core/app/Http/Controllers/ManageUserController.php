<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class ManageUserController extends Controller
{
    public function viewAllUsers($type){

        switch($type){
            case 'verified-users':
                $users  = User::where('status',1)->orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'Verified Users';
                break;
            case 'unverified-users':
                $users  = User::where('status',0)->orderBy('created_at','desc')->paginate(15); 
                $pageTitle = 'Unverified Users';
                break;
             case 'banned-users':
                $users  = User::where('status',2)->orderBy('created_at','desc')->paginate(15); 
                $pageTitle = 'Banned Users';
                break; 
            default:       
                $users  = User::orderBy('created_at','desc')->paginate(15);
                $pageTitle = 'All Users';
                break;  
        }
        return view('admin.manage-users.users.index',[
            'users'     => $users,
            'pageTitle' => $pageTitle,
        ]);
    }
}
