<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SellBook;
use App\BookList;
use Illuminate\Support\Facades\Input;

class BookController extends Controller
{
     public function showSellProductForm(){
        return view('user-form.sell.index');
    }
    public function saveSellProductInfo(Request $request){
        // return $request->all();
       

        $this->validate($request,$this->rules());

          $inputs  = Input::except(['_token','name','contact_number','gender','email','payment_type','address']);

          

        if(!empty($inputs['book'])){
        $sellBook = new SellBook();
        $sellBook->name = $request->name;
        $sellBook->contact_number = $request->contact_number;
        $sellBook->gender = $request->gender;
        $sellBook->email = $request->email;
        $sellBook->payment_type = $request->payment_type;
        $sellBook->address = $request->address;
        $sellBook->save();
                for($i = 0; $i < count($inputs['book']); $i++){
                    $bookList = new BookList();
                    $bookList->sell_book_id = $sellBook->id;
                    $bookList->book = $request->book[$i];
                    $bookList->author = $request->author[$i];
                    $bookList->edition = $request->edition[$i];
                    $bookList->year = $request->year[$i];
                    $bookList->save();
                }
        }else{
            return 0;
        }  
      

        
        return back();
    }

    private function rules(){
        return [
            'name' => 'required|max:30',
            'contact_number' => 'required|digits_between:1,20|numeric',
            'email' => 'required|email|max:30',
            'gender' => 'required|numeric|digits_between:0,1',
            'payment_type' => 'required|numeric|digits_between:0,1:',
            'address' => 'required|max:190',
        ];
    }
}
