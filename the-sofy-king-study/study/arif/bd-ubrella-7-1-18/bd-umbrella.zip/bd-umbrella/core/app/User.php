<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'gender',
        'father_name',
        'mother_name',
        'permanent_address',
        'present_address',
        'contact_number',
        'reference_contact_number',
        'birth_date',
        'institue_name',
        'department_name',
        'student_id',
        'nid_number',
        'birth_certificate_number',
        'username',
        'email',
        'password',
        'ststus',
        'email_verify',
        'sms_verify',
        'nid_verify',
        'birth_certificate_verify',
        'student_id_verify',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function sellBook(){
        return $this->hasOne('App\SellBook');
    }

    public function buyBook(){
        return $this->hasOne('App\BuyBook');
    }

}
