<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SocialLinkController extends Controller
{
    public function index(){
        return view('admin.social-link.index');
    }

    public function create(){
        return view('admin.social-link.form');
    }
}
