<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\GeneralSetting;
use Toastr;

class GeneralSettingController extends Controller
{
    public function viewGeneralSettingInfo(){
        $generalSetting = GeneralSetting::first();
        return view('admin.general-setting.index',compact('generalSetting'));
    }
    public function updateGeneralSettingInfo(Request $request){
        $generalSetting =  GeneralSetting::first();
        if($generalSetting){
            $generalSetting->site_name = $request->site_name;
            $generalSetting->site_title = $request->site_title;
            $generalSetting->color_code = $request->color_code;
            $generalSetting->currency = $request->currency;
            $generalSetting->currency_symbol = $request->currency_symbol;
            $generalSetting->save();
            Toastr::success('Information Saved Successfully...');
        }else{
            Toastr::error('Whoops Something Went Wrong...');
        }
       
        return redirect()->back();
    }
}
