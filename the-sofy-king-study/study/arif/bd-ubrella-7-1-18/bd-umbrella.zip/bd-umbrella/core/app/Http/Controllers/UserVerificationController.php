<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use Session;
use Carbon\Carbon;

class UserVerificationController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function showVerificationForm(){
        $user = User::find(Auth::id());
        if($user->email_verify == 0){
            return view('user-verification.email-verification.index')->with('alert','Please Verify Your Eamil...');
        }
        return redirect()->route('home');
    }

    public function sendEmailVerificationCode(){
      
        $user = User::find(Auth::id());
        if($user->email_verify != 1){
            if($user->sent_time > Carbon::now()){
                return back()->with('alert', 'Recently a Message is Sent to Your Email..  Please Check Your Email or Try after some moment');
                
            }else{
               $code = mt_rand( 10000000, 99999999);
               $msg = 'Your Verification code is: '.$code;
               $user->email_code  = $code ;
               $user->sent_time   = Carbon::now()->addMinutes(5);
               $user->save();
               send_email($user->email, $user->name, 'Verification Code', $msg);
               return back()->with('success', 'Email verification code sent succesfully');
            }
        }else{
            return redirect()->route('home');
        }
    }

    public function verifyEmailAddress(Request $request){
        $this->validate($request,[
            'code' => 'required',
        ]);
        $user  = User::find(Auth::id());
        if($user->email_verify != 1){
            if($user->email_code == $request->code){
                $user->email_verify = 1;
                $user->status = 1;
                $user->email_code = str_random(12);
                $user->save();
                return back()->with('success','Your Email Address  Verified...');
            }
        }else{
            return back()->with('success','Your Email Address is already Verified...');
        }
    }


}
