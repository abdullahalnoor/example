<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great !
|
*/

Auth::routes();


// Route::get('/', function () {
//     return view('frontend.home.index');
// });


 Route::get('/','WelcomeController@index')->name('website');
 Route::get('/book','WelcomeController@viewBookPage')->name('book');

 Route::get('sell-product','BookController@showSellProductForm')->name('sell-product');
Route::post('sell-product','BookController@saveSellProductInfo')->name('sell-product.submit');

// user verification
Route::group(['prefix'=>'user','middleware'=>'auth'],function(){
    Route::get('user-verification','UserVerificationController@showVerificationForm')->name('user-verifiatcion');

    Route::get('email-verification-code','UserVerificationController@sendEmailVerificationCode')->name('user.email-verifiatcion-code');

    Route::post('email-verification-code','UserVerificationController@verifyEmailAddress')->name('user.email-verifiatcion-code');

});



Route::group(['prefix'=>'user','middleware'=>['auth','verify.user']],function(){
    Route::get('/home', 'HomeController@index')->name('home');

    Route::get('/sell-request/{type}', 'HomeController@viewSellRequest')->name('user.sell-request');
    Route::get('/sell-request-detail/{id}', 'HomeController@viewSellRequestDetail')->name('user.sell-request.detail');

     Route::get('/buy-request/{type}', 'HomeController@viewBuyRequest')->name('user.buy-request');
    Route::get('/buy-request-detail/{id}', 'HomeController@viewBuyRequestDetail')->name('user.buy-request.detail');

    // user buy product
    Route::get('buy-product','UserBookController@showBuyProductForm')->name('user.buy-product');
    Route::post('buy-product','UserBookController@saveBuyProductInfo')->name('user.buy-product');
    // user sell product
    Route::get('sell-product','UserBookController@showsSellProductForm')->name('user.sell-product');
    Route::post('sell-product','UserBookController@saveSellProductInfo')->name('user.sell-product');

    

});


Route::group(['prefix'=>'admin','namespace'=>'AdminAuth'],function(){
    Route::get('/','LoginController@showLoginForm')->name('admin.login');
    Route::post('login','LoginController@login')->name('admin.login.submit');
});

Route::group(['prefix'=>'admin','namespace'=>'AdminAuth','middleware'=>'auth:admin'],function(){
    Route::get('logout','LoginController@logout');
});


Route::group(['prefix'=>'admin','middleware'=>'auth:admin'],function(){

    Route::get('/dashboard','AdminController@index')->name('admin.dashboard');


    Route::get('general-setting','GeneralSettingController@viewGeneralSettingInfo')->name('admin.general-setting');
    Route::post('general-setting','GeneralSettingController@updateGeneralSettingInfo')->name('admin.general-setting.update');

    // rules setting 
    Route::get('rules-setting','RuleSettingController@viewRuleSetting')->name('admin.rules-setting');
    Route::post('rules-setting','RuleSettingController@changeRule')->name('admin.rules-setting.update');

    // social link

    Route::get('social-link','SocialLinkController@index')->name('admin.social-link');
    Route::get('social-form','SocialLinkController@create')->name('admin.social-link.create');

    // manage user
    Route::get('users/{type}','ManageUserController@viewAllUsers')->name('admin.view.users');

    // manage sell orders
    Route::get('sell/{type}','ManageBookController@viewAllSellOrders')->name('admin.sell-orders');
    Route::get('sell/order-detail/{id}','ManageBookController@viewSellOrderDetail')->name('admin.sell.order-detail');
    Route::post('sell/order-status','ManageBookController@changeSellOrderStatus')->name('admin.sell.order-status');

    // manage buy orders
    Route::get('buy/{type}','ManageBookController@viewAllBuyOrders')->name('admin.view.buy-orders');
    Route::get('buy/order-detail/{id}','ManageBookController@viewBuyOrderDetail')->name('admin.buy.order-detail');
    Route::post('buy/order-status','ManageBookController@changeBuyOrderStatus')->name('admin.buy.order-status');


});


