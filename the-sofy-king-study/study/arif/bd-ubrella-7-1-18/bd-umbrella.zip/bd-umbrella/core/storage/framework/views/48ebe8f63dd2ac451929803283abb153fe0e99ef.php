 
<?php $__env->startSection('title','Order Detail'); ?> 
<?php $__env->startSection('content'); ?>

<div class="app-title">
  <div>
    <h1><i class="fa fa-users"></i> Order Detail</h1>
    <p>Manage Order </p>
  </div>
  <ul class="app-breadcrumb breadcrumb">


    <?php if($orderDetail->order_status == 1): ?>
    <li class="breadcrumb-item"><a href="#" data-id="<?php echo e($orderDetail->id); ?>" data-status="2" class="btn btn-danger orderStatus">
      <i class="fa fa-times"></i>
      Cancel
    </a></li>
    <?php elseif($orderDetail->order_status == 2): ?>
    <li class="breadcrumb-item"><a href="#" data-id="<?php echo e($orderDetail->id); ?>" data-status="1" class="btn btn-primary orderStatus"> <i class="fa fa-check"></i> Confirm</a></li>
    <?php else: ?>
    <li class="breadcrumb-item"><a href="#" data-id="<?php echo e($orderDetail->id); ?>" data-status="1" class="btn btn-primary orderStatus"> <i class="fa fa-check"></i>
      Confirm</a></li>
    <li class="breadcrumb-item "><a href="#" data-id="<?php echo e($orderDetail->id); ?>" data-status="2" class="btn btn-danger orderStatus">
      <i class="fa fa-times"></i> 
      Cancel</a></li>
    <?php endif; ?>

  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="tile">




      <div class="row">

        <div class="col-md-12 col-sm-12">

          <div class="card border-info">
            <div class="card-header bg-info text-white">
              <i class="fa fa-info"></i> Student Information
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <td>Order Status </td>
                      <td>
                        <?php if($orderDetail->order_status == 0): ?>
                        <span class="bg-info p-1 text-white">Pending</span> <?php elseif($orderDetail->order_status == 1): ?>
                        <span class="bg-primary p-1 text-white">Confirmed</span> <?php elseif($orderDetail->order_status == 2): ?>
                        <span class="bg-danger p-1 text-white">Cancel</span> <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td>Name</td>
                      <td>
                        <?php echo e($orderDetail->user->name); ?>

                      </td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td>
                        <?php echo e($orderDetail->user->email); ?>

                      </td>
                    </tr>
                    <tr>
                      <td>Contact Number</td>
                      <td>
                        <?php echo e($orderDetail->user->contact_number); ?>

                      </td>
                    </tr>
                    <tr>
                      <td>Address</td>
                      <td><?php echo e($orderDetail->address); ?></td>
                    </tr>
                    <tr>
                      <td>Gender</td>
                      <td>
                        <?php if($orderDetail->gender == 1): ?>
                        <span class="bg-info p-1 text-white">Male</span> <?php elseif($orderDetail->gender == 2): ?> <span class="bg-info p-1 text-white">Femaile</span>                        <?php else: ?> <span class="bg-info p-1 text-white">Others</span> <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td>Payment Type</td>
                      <td>
                        <?php if($orderDetail->payment_type == 1): ?>
                        <span class="bg-info p-1 text-white">Hand Cash</span> <?php elseif($orderDetail->payment_type == 2): ?>
                        <span class="bg-info p-1 text-white">Bkash</span> <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td>Order Status</td>
                      <td><?php if($orderDetail->order_status == 0): ?>
                        <span class="bg-info p-1 text-white">Pending</span> <?php elseif($orderDetail->order_status == 1): ?>
                        <span class="bg-success p-1 text-white">Confirmed</span> <?php elseif($orderDetail->order_status == 2): ?>
                        <span class="bg-danger p-1 text-white">Cancel</span> <?php endif; ?></td>
                    </tr>
                  </thead>
                  <tbody>

                  </tbody>
                </table>
              </div>
            </div>
          </div>



        </div>
      </div>

      <div class="row mt-5">
        <div class="col-md-12 col-sm-12">
          <div class="card border-info">
            <div class="card-header bg-info text-white">
              <i class="fa fa-book"></i> Book List
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Book</th>
                      <th>Author</th>
                      <th>Edition </th>
                      <th>Year</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $orderDetail->bookList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($item->book); ?></td>
                      <td><?php echo e($item->author); ?></td>
                      <td><?php echo e($item->edition); ?></td>
                      <td><?php echo e($item->year); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>


    </div>
  </div>
</div>

<div class="modal fade " id="orderStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title text-center" id="modalTitle">Order Status</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="statusForm" action="<?php echo e(route('admin.buy.order-status')); ?>" method="POST">
        <div class="modal-body">
          <h2 class="text-center text-success">Do You Want Change ??</h2>
          <?php echo e(csrf_field()); ?>

          <input type="hidden" id="id" name="id">
          <input type="hidden" id="status" name="status">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Discard</button>
          <button type="submit" class="btn btn-primary">Confirm</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('js'); ?>
<script>
  $(document).ready(function(){
    $.ajaxSetup({ 
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } 
      });
      
      $(".orderStatus").on("click",function(e){
        e.preventDefault();
        var id = $(this).data("id");
        var status = $(this).data("status");
        $("#id").val(id);
        $("#status").val(status);
        $("#orderStatus").modal("show");
      });

      $("#statusForm").on("submit",function(){
        // e.preventDefault();
        
        var frmData = $(this).serialize();
        $.ajax({
          url:"<?php echo e(route('admin.sell.order-status')); ?>",
          type:"POST",
          data:frmData,
        })
        .done(function(data){ 
          $("#orderStatus").modal("hide"); 
          toastr.success("Order Status Updated Successfully..");
            
        }) 
        .fail(function(){ 
          toastr.error("Whoops Something went Wrong.."); 
          });
      });

    });

</script>





































<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>