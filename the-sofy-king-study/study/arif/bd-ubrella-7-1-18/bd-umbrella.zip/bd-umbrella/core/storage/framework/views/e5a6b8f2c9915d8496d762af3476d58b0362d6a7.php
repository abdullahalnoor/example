 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <form class="col m12  l12  s12 " action="<?php echo e(route('register')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-graduation-cap prefix"></i>
              <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="validate">
              <label>Student Name</label> <?php if($errors->has('name')): ?>
              <span class="helper-text red-text text-accent-4 ">
                <b><?php echo e($errors->first('name')); ?></b>
              </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-transgender-alt prefix"></i>
              <select name="gender">
                 <option value="" disabled selected>Select Your Gnder</option>
                <option value="1" <?php echo e(old('gender') == 1?'selected':''); ?>  >Male</option>
                <option value="2" <?php echo e(old('gender') == 2?'selected':''); ?>>Female </option>
                <option value="3" <?php echo e(old('gender') == 3?'selected':''); ?>>Others</option>
              </select>
              <label>Select Your Gnder</label> <?php if($errors->has('gender')): ?>
              <span class="helper-text red-text text-accent-4 ">
                                          <b><?php echo e($errors->first('gender')); ?></b>
                                        </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-male prefix"></i>
              <input type="text" name="father_name" value="<?php echo e(old('father_name')); ?>" class="validate">
              <label>Father Name</label> <?php if($errors->has('father_name')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('father_name')); ?></b>
                            </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-female prefix"></i>
              <input type="text" name="mother_name" value="<?php echo e(old('mother_name')); ?>" class="validate">
              <label>Mother Name</label> <?php if($errors->has('mother_name')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('mother_name')); ?></b>
                            </span> <?php endif; ?>
            </div>
          </div>


          <div class="row">
            <div class="col s12">
              <div class="input-field ">
                <i class="fa fa-calendar prefix"></i>
                <input type="text" value="<?php echo e(old('birth_date')); ?>" name="birth_date" class="datepicker">
                <label>Date of Birth</label> <?php if($errors->has('birth_date')): ?>
                <span class="helper-text red-text text-accent-4 ">
                                <b><?php echo e($errors->first('birth_date')); ?></b>
                              </span> <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-university prefix"></i>
              <input type="text" name="institue_name" value="<?php echo e(old('institue_name')); ?>" class="validate">
              <label>Institute Name</label> <?php if($errors->has('institue_name')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('institue_name')); ?></b>
                            </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-book prefix"></i>
              <input type="text" name="department_name" value="<?php echo e(old('department_name')); ?>" class="validate">
              <label>Department Name</label> <?php if($errors->has('department_name')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('department_name')); ?></b>
                            </span> <?php endif; ?>
            </div>
          </div>


          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-phone prefix"></i>
              <input type="number" name="contact_number" value="<?php echo e(old('contact_number')); ?>" class="validate">
              <label>Contact Number </label> <?php if($errors->has('contact_number')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('contact_number')); ?></b>
                            </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-phone prefix"></i>
              <input type="number" name="reference_contact_number" value="<?php echo e(old('reference_contact_number')); ?>" class="validate">
              <label>References Contact Number</label> <?php if($errors->has('reference_contact_number')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('reference_contact_number')); ?></b>
                            </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <div class="input-field col s12">
              <i class="fa fa-home prefix"></i>
              <textarea id="textarea1" name="permanent_address" class="materialize-textarea"><?php echo e(old('reference_contact_number')); ?></textarea>
              <label for="textarea1">permanent address </label> <?php if($errors->has('permanent_address')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('permanent_address')); ?></b>
                            </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <div class="input-field col s12">
              <i class="fa fa-hotel prefix"></i>
              <textarea id="textarea2" name="present_address" class="materialize-textarea"><?php echo e(old('present_address')); ?></textarea>
              <label for="textarea1">present address</label> <?php if($errors->has('present_address')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('present_address')); ?></b>
                            </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">

            <div class="input-field col m6  l6 s12">
              <i class="fa fa-check prefix"></i>
              <select name="select_id">
                            <option value="" disabled selected>Select ID</option>
                            <option value="1" <?php echo e(old('select_id') == 1?'selected':''); ?> >National ID</option>
                            <option value="2" <?php echo e(old('select_id') == 2?'selected':''); ?>>Birth Certificate  </option>
                            <option value="3" <?php echo e(old('select_id') == 3?'selected':''); ?>>Student ID</option>
                          </select>
              <label>Select ID</label> <?php if($errors->has('select_id')): ?>
              <span class="helper-text red-text text-accent-4 ">
                                            <b><?php echo e($errors->first('select_id')); ?></b>
                                          </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-id-badge prefix"></i>
              <input type="number" name="id_number" value="<?php echo e(old('id_number')); ?>" class="validate">
              <label>ID Number </label> <?php if($errors->has('id_number')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('id_number')); ?></b>
                            </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-envelope prefix"></i>
              <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="validate">
              <label>Email</label> <?php if($errors->has('email')): ?>
              <span class="helper-text red-text text-accent-4 ">
                              <b><?php echo e($errors->first('email')); ?></b>
                            </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-pencil prefix"></i>
              <input name="username" type="text" class="validate">
              <label>Username </label> <?php if($errors->has('username')): ?>
              <span class="helper-text red-text text-accent-4 ">
                                            <b><?php echo e($errors->first('username')); ?></b>
                                          </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-key prefix"></i>
              <input type="password" class="validate">
              <label> Password</label> <?php if($errors->has('password')): ?>
              <span class="helper-text red-text text-accent-4 ">
                                            <b><?php echo e($errors->first('password')); ?></b>
                                          </span> <?php endif; ?>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-key prefix"></i>
              <input type="password" name="password_confirmation" class="validate">
              <label>Confirm Password </label>
            </div>
          </div>







          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit" name="action">
              <i class="fa fa-check center"></i>

              <b>
                REGISTER
              </b>
            </button>
          </div>

        </form>
      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('script'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems, {});

    var elems = document.querySelectorAll('.datepicker'); M.Datepicker.init(elems, {});
  });

</script>












































































































<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>