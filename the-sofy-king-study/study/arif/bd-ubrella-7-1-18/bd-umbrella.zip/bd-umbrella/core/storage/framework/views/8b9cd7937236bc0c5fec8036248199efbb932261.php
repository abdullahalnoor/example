 
<?php $__env->startSection('title', 'Social Links'); ?> <?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/fontawesome-iconpicker.min.css')); ?>"> 
<?php $__env->stopPush(); ?> 
<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1 class="text-primary"><i class="fa fa-eye"></i>Social Links</h1>
    <p class="text-danger">Social Links Information </p>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <div class="col-md-12">
          <div class="tile">
            <p class="tile-title">Social Links List <a id="addSclLnk" class="btn btn-primary float-right text-white"><i class="fa fa-plus"></i>Add New </a></p>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Icon</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td><a class="btn btn-info text-white"><i class="fa fa-edit"></i>Edit </a><a class="btn btn-danger text-white"><i class="fa fa-trash"></i>Delete </a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="clearix"></div>

</div>
<div id="modals"></div>
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/fontawesome-iconpicker.min.js')); ?>"></script>
<script>
  $(document).on('focus', '.socioicon', function () {
  $('.socioicon').iconpicker();
}

);
$(document).ready(function () {
  $.ajaxSetup( {
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  }
  );
  $("#addSclLnk").on("click", function (e) {
    e.preventDefault();
    $.get("<?php echo e(route('admin.social-link.create')); ?>", function (data) {
      $("#modals").empty().append(data);
      $("#socialModal").modal("show");
    }
    );
  }
  );
}

);

</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>