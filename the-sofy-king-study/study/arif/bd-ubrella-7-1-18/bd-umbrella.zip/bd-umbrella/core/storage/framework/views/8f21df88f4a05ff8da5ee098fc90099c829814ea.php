 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <form class="col m12  l12  s12 " action="<?php echo e(route('login')); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <div class="row">
            <?php if(Session::has('success')): ?>
            <div class="card-panel red accent-3">
              <h5 class="white-text  center-align">
                <b><?php echo e(Session::get('success')); ?></b>
              </h5>
            </div> <?php endif; ?>
            <div class="input-field co m12  l12 s12">
              <i class="fa fa-pencil prefix"></i>
              <input type="text" name="username" value="<?php echo e(old('username')); ?>" class="validate">
              <label>Username </label> <?php if($errors->has('username')): ?>
              <span class="helper-text red-text text-accent-4 ">
                                            <b><?php echo e($errors->first('username')); ?></b>
                                          </span> <?php endif; ?>
            </div>
          </div>
          <div class="row">

            <div class="input-field co m12  l12 s12">
              <i class="fa fa-key prefix"></i>
              <input type="text" name="password" value="<?php echo e(old('password')); ?>" class="validate">
              <label>Password </label> <?php if($errors->has('password')): ?>
              <span class="helper-text red-text text-accent-4 ">
                                            <b><?php echo e($errors->first('password')); ?></b>
                                          </span> <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit" name="action">
              <i class="fa fa-check center"></i>

              <b>
                <?php echo e(__('LOGIN')); ?>

              </b>
            </button>
          </div>

        </form>
      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>