 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <?php if(Session::has('alert')): ?>
        <div class="row">
          <div class="card-panel red accent-3">
            <h5 class="white-text  center-align">
              <b><?php echo e(Session::get('alert')); ?></b>
            </h5>
          </div>
        </div>
        <?php elseif(Session::has('success')): ?>
        <div class="row">
          <div class="card-panel teal lighten-2">
            <h5 class="white-text  center-align">
              <b><?php echo e(Session::get('success')); ?></b>
            </h5>
          </div>
        </div>
        <?php else: ?>
        <div class="row">
          <div class="card-panel teal lighten-2">
            <h5 class="white-text  center-align">
              <b>Please.. Verify Your Email Address !</b>
            </h5>
          </div>
        </div>
        <?php endif; ?>

        <form class="col m12  l12  s12 " action="<?php echo e(route('user.email-verifiatcion-code')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="row">

            <div class="input-field co m12  l12 s12">
              <i class="fa fa-code prefix"></i>
              <input type="text" name="code" value="" class="validate">
              <label>code </label>
            </div>
          </div>

          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit">
              <i class="fa fa-check center"></i>

              <b>
                submit code
              </b>
            </button>
          </div>
        </form>


        <div class="row">
          <a href="<?php echo e(route('user.email-verifiatcion-code')); ?>" class="btn-large waves-effect waves-light" style="width: 100%">
            <i class="fa fa-forward center"></i>
            <b>
              SEND CODE
            </b>
          </a>
        </div>


      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>