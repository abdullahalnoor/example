<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/main.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/font-awesome.min.css')); ?>">
  <title>Login - Vali Admin</title>
</head>

<body>
  <section class="material-half-bg">
    <div class="cover"></div>
  </section>
  <section class="login-content">
    <div class="logo">
      <h1>BD Umbrella <i class="fa fa-umbrella"></i> </h1>
    </div>
    <div class="login-box">
      <form class="login-form" action="<?php echo e(route('admin.login.submit')); ?>" method="POST">
        <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>SIGN IN</h3>
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label class="control-label">USERNAME</label>
          <input class="form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" type="text" placeholder="User Name" name="username"
            autocomplete="off" required autofocus value="<?php echo e(old('username')); ?>">
        </div>
        <div class="form-group">
          <label class="control-label">PASSWORD</label>
          <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" type="password" autocomplete="off" required
            autofocus name="password" placeholder="Password">
        </div>
        <?php ($error = 'Your given Information are Invalid'); ?> <?php if($errors->has('username') || $errors->has('password')): ?>
        <span style="color:red">
                              <strong><?php echo e($error); ?></strong>
                            </span> <?php endif; ?>

        <div class="form-group btn-container">
          <button class="btn btn-primary btn-block"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
        </div>
      </form>

    </div>
  </section>
  <!-- Essential javascripts for application to work-->


  <script src="<?php echo e(asset('assets/admin/js/jquery-3.2.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>
  <!-- The javascript plugin to display page loading on top-->
  <script src="<?php echo e(asset('assets/admin/js/plugins/pace.min.js')); ?>"></script>
  <!-- The javascript plugin to display page loading on top-->
  <script type="text/javascript">
    // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
  </script>
</body>

</html>