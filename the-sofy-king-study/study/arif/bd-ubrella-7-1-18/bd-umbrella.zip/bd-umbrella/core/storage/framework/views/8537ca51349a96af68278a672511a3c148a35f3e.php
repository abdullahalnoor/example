 
<?php $__env->startSection('title',$pageTitle); ?> 
<?php $__env->startSection('content'); ?>

<div class="app-title">
  <div>
    <h1><i class="fa fa-users"></i> <?php echo e($pageTitle); ?></h1>
    <p>Manage <?php echo e($pageTitle); ?></p>
  </div>

</div>

<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if($sellProducts->all()): ?> <?php $__currentLoopData = $sellProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php if(empty($item->user_id)): ?> <?php echo e($item->name); ?> <?php else: ?> <?php echo e($item->user->name); ?> <?php endif; ?>
              </td>
              <td>
                <?php if(empty($item->user_id)): ?> <?php echo e($item->email); ?> <?php else: ?> <?php echo e($item->user->email); ?> <?php endif; ?>
              </td>
              <td>
                <?php if($item->order_status == 0): ?>
                <span class="bg-info p-1 text-white">Pending</span> <?php elseif($item->order_status == 1): ?>
                <span class="bg-success p-1 text-white">Confirmed</span> <?php elseif($item->order_status == 2): ?>
                <span class="bg-danger p-1 text-white">Cancel</span> <?php endif; ?>
              </td>
              <td>
                <a href="<?php echo e(route('admin.sell.order-detail',$item->id)); ?>" class="btn btn-primary"> <i class="fa fa-eye"></i> View</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
            <tr>
              <td colspan="4">
                <h3 class="text-center text-danger">No Record Found...</h3>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="row justify-content-center">
        <?php echo e($sellProducts->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>