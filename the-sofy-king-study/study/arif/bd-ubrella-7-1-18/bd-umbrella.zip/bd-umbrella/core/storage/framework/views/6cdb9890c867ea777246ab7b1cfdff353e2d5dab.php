 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <div class="col m4 hide-on-small-only">
          <ul class="collection">
            <li class="collection-item  <?php if(request()->path() == 'user/home'): ?> red <?php else: ?> teal  <?php endif; ?> "> <a class="white-text" href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> Profile</a></li>
            <li class="collection-item 
                                  <?php if(request()->path() == 'user/sell-request/all-orders'): ?> red            
                                  <?php elseif(request()->path() == 'user/sell-request/pending-orders'): ?> red            
                                  <?php elseif(request()->path() == 'user/sell-request/confirm-orders'): ?> red            
                                  <?php elseif(request()->path() == 'user/sell-request/cancel-orders'): ?> red 
                                
                                  <?php else: ?> 
                                  teal
                                   <?php endif; ?>"> <a class="white-text" href="<?php echo e(route('user.sell-request',['type'=>'all-orders'])); ?>"><i class="fa fa-spinner"></i> Sell Request</a></li>
            <li class="collection-item
                                  <?php if(request()->path() == 'user/buy-request/all-orders'): ?> red 
                                  <?php elseif(request()->path() == 'user/buy-request/pending-orders'): ?> red 
                                  <?php elseif(request()->path() == 'user/buy-request/confirm-orders'): ?> red 
                                  <?php elseif(request()->path() == 'user/buy-request/cancel-orders'): ?>
                                  <?php elseif(request()->path() == 'user/buy-request/cancel-orders'): ?>
                                  red 
                                  
                                  <?php else: ?> teal <?php endif; ?>
                                  
                                  "> <a class="white-text" href="<?php echo e(route('user.buy-request',['type'=>'all-orders'])); ?>"> <i class="fa fa-spinner"></i> Buy Request </a></li>
            <li class="collection-item"> <i class="fa fa-cog"></i> Change Password</li>
          </ul>
        </div>
        <a class="waves-effect waves-light btn" href="<?php echo e(route('user.sell-request',['type'=>'pending-orders'])); ?>">Pending</a>        /
        <a class="waves-effect waves-light btn" href="<?php echo e(route('user.sell-request',['type'=>'confirm-orders'])); ?>">Confirm</a>/
        <a class="waves-effect waves-light btn" href="<?php echo e(route('user.sell-request',['type'=>'cancel-orders'])); ?>">Cancel</a>
        <br> <br>
        <div class="col m8 s12">
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px"> <i class="fa fa-info"></i> Order Info </div>
          <br>




          <table>
            <tr>
              <td>Order Status </td>
              <td>
                <?php if($orderDetail->order_status == 0): ?>
                <span class="bg-info p-1 text-white">Pending</span> <?php elseif($orderDetail->order_status == 1): ?>
                <span class="bg-primary p-1 text-white">Confirmed</span> <?php elseif($orderDetail->order_status == 2): ?>
                <span class="bg-danger p-1 text-white">Cancel</span> <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>Payment Type</td>
              <td>
                <?php if($orderDetail->payment_type == 1): ?>
                <span class="bg-info p-1 text-white">Hand Cash</span> <?php elseif($orderDetail->payment_type == 2): ?>
                <span class="bg-info p-1 text-white">Bkash</span> <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>Order Status</td>
              <td><?php if($orderDetail->order_status == 0): ?>
                <span class="blue  white-text">Pending</span> <?php elseif($orderDetail->order_status == 1): ?>
                <span class="teal  white-text">Confirmed</span> <?php elseif($orderDetail->order_status == 2): ?>
                <span class="red  white-text">Cancel</span> <?php endif; ?></td>
            </tr>
            <tr>
              <td>Email</td>
              <td>
                <?php if(empty($orderDetail->user_id)): ?> <?php echo e($orderDetail->email); ?> <?php else: ?> <?php echo e($orderDetail->user->email); ?> <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>Contact Number</td>
              <td>
                <?php if(empty($orderDetail->user_id)): ?> <?php echo e($orderDetail->contact_number); ?> <?php else: ?> <?php echo e($orderDetail->user->contact_number); ?> <?php endif; ?>

              </td>
            </tr>
          </table>

          <br>
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px">
            <i class="fa fa-book"></i> Book List </div>
          <br>


          <table class="table table-hover">
            <thead>
              <tr>
                <th>Book</th>
                <th>Author</th>
                <th>Edition </th>
                <th>Year</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $orderDetail->bookList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($item->book); ?></td>
                <td><?php echo e($item->author); ?></td>
                <td><?php echo e($item->edition); ?></td>
                <td><?php echo e($item->year); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>



        </div>

      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>