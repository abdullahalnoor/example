 
<?php $__env->startSection('title','Rules Setting'); ?> 
<?php $__env->startSection('content'); ?>

<div class="app-title">
  <div>
    <h1 class="text-primary">
      <i class="fa fa-edit"></i> Rules Setting</h1>
    <p class="text-danger">
      Update Rules Setting Information
    </p>
  </div>

</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label class="control-label">
                <strong style="text-transform: capitalize;">Registration Status</strong>
              </label>
              <a href="" data-name="registration_status" data-status="1" data-title="Registration Status" class="btn <?php echo e($ruleSetting->registration_status == 1 ?'btn-success btnOff':'btn-danger btnOn'); ?>  btn-block "><?php echo e($ruleSetting->registration_status == 1 ?'On':'Off'); ?></a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label class="control-label">
                <strong style="text-transform: capitalize;">Request Status</strong>
              </label>
              <a href="" data-name="request_status" data-status="1" data-title="Request Status" class="btn <?php echo e($ruleSetting->request_status == 1 ?'btn-success btnOff':'btn-danger btnOn'); ?>  btn-block "><?php echo e($ruleSetting->request_status == 1 ?'On':'Off'); ?></a>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label class="control-label">
                <strong style="text-transform: capitalize;">Email Verification</strong>
              </label>
              <a href="" data-name="email_verification" data-status="1" data-title="Email Verification" class="btn <?php echo e($ruleSetting->email_verification == 1 ?'btn-success btnOff':'btn-danger btnOn'); ?>  btn-block "><?php echo e($ruleSetting->email_verification == 1 ?'On':'Off'); ?></a>              </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label class="control-label">
                <strong style="text-transform: capitalize;">SMS Verification </strong>
              </label>
              <a href="" data-name="sms_verification" data-status="1" data-title="SMS Verification" class="btn <?php echo e($ruleSetting->sms_verification == 1 ?'btn-success btnOff':'btn-danger btnOn'); ?>  btn-block "><?php echo e($ruleSetting->sms_verification == 1 ?'On':'Off'); ?></a>              </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label class="control-label">
                <strong style="text-transform: capitalize;">Email Notification</strong>
              </label>
              <a href="" data-name="email_notification" data-status="1" data-title="Email Notification" class="btn <?php echo e($ruleSetting->email_notification == 1 ?'btn-success btnOff':'btn-danger btnOn'); ?>  btn-block "><?php echo e($ruleSetting->email_notification == 1 ?'On':'Off'); ?></a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label class="control-label">
                <strong style="text-transform: capitalize;">SMS Notification </strong>
              </label>
              <a href="" data-name="sms_notification" data-status="1" data-title="SMS Notification" class="btn <?php echo e($ruleSetting->sms_notification == 1 ?'btn-success btnOff':'btn-danger btnOn'); ?>  btn-block "><?php echo e($ruleSetting->sms_notification == 1 ?'On':'Off'); ?></a>
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>

  <div class="clearix"></div>

</div>


<div class="modal fade " id="successModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title text-center" id="modalTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="statusForm" action="" method="POST">
        <div class="modal-body">
          <h2 class="text-center text-success">Do You Want Change Rule ??</h2>
          <?php echo e(csrf_field()); ?>

          <input type="hidden" id="status">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Discard</button>
          <button type="submit" class="btn btn-primary">Confirm</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('js'); ?>

<script>
  $(document).ready(function () {

    $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });


    $(".btnOn").on("click", function (e) {
      e.preventDefault();
      var status = $(this).data('status');
      var title = $(this).data('title');
      var name = $(this).data('name');

      $("#status").val(status);
      $("#modalTitle").html(title);
      $("#status").attr("name", name);

      $("#successModal").modal("show");
      
    });

    $(".btnOff").on("click", function (e) {
      e.preventDefault();
      var title = $(this).data("title");
      var name = $(this).data('name');

      $title = $("#modalTitle").html(title);
      $("#status").attr("name", name);
      $("#successModal").modal("show");
    });

    $("#statusForm").on("submit",function(e){
      e.preventDefault();
      var frmData = $(this).serialize();
      $.ajax({
        url:"<?php echo e(route('admin.rules-setting.update')); ?>",
        type:"POST",
        data: frmData,
      })
      .done(function(data){
        $("#successModal").modal("hide");
        toastr.success("Information Updated Successfully..");
        setTimeout(function(){
          location.reload();
        },1000)
      })
      .fail(function(){
        toastr.error("Whoops Something went Wrong..");
      });
    })


  });

</script>

































<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>