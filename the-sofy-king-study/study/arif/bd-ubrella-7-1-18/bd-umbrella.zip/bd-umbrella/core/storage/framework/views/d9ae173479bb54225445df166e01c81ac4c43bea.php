 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <form class="col m12  l12  s12 ">
          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-graduation-cap prefix"></i>
              <input type="text" name="first_name" data-error="15" class="validate">
              <label for="icon_prefix">First Name</label>
              <!-- <span class="helper-text" data-error="wrong" data-success="right">Helper text</span> -->
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-graduation-cap prefix"></i>
              <input type="text" name="last_name" class="validate">
              <label>Last Name</label>
              <!-- <span class="helper-text" data-error="wrong" data-success="right">Helper text</span> -->
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-university prefix"></i>
              <input type="text" name="institute_name" class="validate">
              <label for="icon_prefix">Institute Name</label>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-sticky-note prefix"></i>
              <input type="text" name="subject_name" class="validate">
              <label>Subject Name</label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-envelope prefix"></i>
              <input type="text" class="validate">
              <label for="icon_prefix">Email</label>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-pencil prefix"></i>
              <input type="text" name="username" class="validate">
              <label>Username </label>
            </div>
          </div>

          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-key prefix"></i>
              <input type="password" name="password" class="validate">
              <label for="icon_prefix">Password</label>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-key prefix"></i>
              <input type="password" name="confirm_password" class="validate">
              <label>Confirm Password </label>
            </div>
          </div>


          <div class="row">
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-calendar prefix"></i>
              <input type="text" class="datepicker">
              <label for="icon_prefix">Date of Birth</label>
            </div>
            <div class="input-field col m6  l6 s12">
              <i class="fa fa-id-badge prefix"></i>
              <input type="number" name="confirm_password" class="validate">
              <label>NID/BID </label>
            </div>
          </div>


          <div class="row">

            <div class="input-field col s12">
              <i class="fa fa-address-book prefix"></i>
              <textarea id="textarea1" class="materialize-textarea" data-length="400"></textarea>
              <label for="textarea1">Write Book List </label>
            </div>
          </div>

          <div class="row">
            <button class="btn-large waves-effect waves-light" style="width: 100%" type="submit" name="action">
                <i class="fa fa-check center"></i>

                <b>
                  REGISTER
                </b>
              </button>
          </div>

        </form>
      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>