 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">

        <div class="row">
          <div class="col m4 s12">
            <ul class="collection with-header">
              <li class="collection-header">
                <h6>
                  <i class="fa fa-book"></i> HSC
                </h6>
              </li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Science</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Commerce</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Arts</li>
            </ul>
            <ul class="collection with-header">
              <li class="collection-header">
                <h6> <i class="fa fa-book"></i> Engineering</h6>
              </li>
              <li class="collection-item"> <i class="fa fa-forward"></i> CSE</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> EEE</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> ETE</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> ECE</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> ME</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> MS</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Civil Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Textile Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Architecture and Planning</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Nutrition and Food Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Robotics and Mechatronics Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Nuclear Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Petroleum and Mineral Resources Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Chemical Engineering</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Materials and Metallurgical Engineering</li>
            </ul>
          </div>
          <div class="col m4 s12">
            <ul class="collection with-header">
              <li class="collection-header">
                <h6> <i class="fa fa-book"></i> Medical </h6>
              </li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Anatomy & Neurobiology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Biological Chemistry</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Biomedical and Translational Science (MS-BATS)</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Environmental Health Sciences</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Epidemiology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Experimental Pathology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Genetic Counseling</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Microbiology & Molecular Genetics</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Pharmacology & Toxicology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Physiology & Biophysics</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Biochemistry and Molecular Biology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Microbiology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Genetic Engineering</li>
            </ul>
            <ul class="collection with-header">
              <li class="collection-header">
                <h6><i class="fa fa-book"></i> General (Hons) Course</h6>
              </li>

              <li class="collection-item"> <i class="fa fa-forward"></i> Management</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Marketing</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Bangla</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Islamic Studies</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Accounting</li>
            </ul>

          </div>
          <div class="col m4 s12">
            <ul class="collection">
              <li class="collection-item"> <i class="fa fa-forward"></i> International Business</li>

              <li class="collection-item"> <i class="fa fa-forward"></i> Pharmacy</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Multimedia and Creative Technology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Architecture and Planning</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> BBA</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> English</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Law(Hons)</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Journalism and Mass Communication</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Physics</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Chemistry</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Tourism and Hospitality Management</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Environmental Science and Disaster Management</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Environmental Science and Disaster Management</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Mathematics</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Biomedical Physics and Technology</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Economics</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Public Administration</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Political Science</li>
              <li class="collection-item"> <i class="fa fa-forward"></i> Finance</li>
            </ul>
          </div>

        </div>


      </div>
    </article>
  </div>
</div>
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('script'); ?>
<script>

</script>




























































































































































<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>