 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <div class="col m4 hide-on-small-only">
          <ul class="collection">
            <li class="collection-item  <?php if(request()->path() == 'user/home'): ?> red <?php else: ?> teal  <?php endif; ?> "> <a class="white-text" href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> Profile</a></li>
            <li class="collection-item 
            <?php if(request()->path() == 'user/sell-request/all-orders'): ?> red            
            <?php elseif(request()->path() == 'user/sell-request/pending-orders'): ?> red            
            <?php elseif(request()->path() == 'user/sell-request/confirm-orders'): ?> red            
            <?php elseif(request()->path() == 'user/sell-request/cancel-orders'): ?> red 
            <?php else: ?> 
            teal
             <?php endif; ?>"> <a class="white-text" href="<?php echo e(route('user.sell-request',['type'=>'all-orders'])); ?>"><i class="fa fa-spinner"></i> Sell Request</a></li>
            <li class="collection-item
            <?php if(request()->path() == 'user/buy-request/all-orders'): ?> red 
            <?php elseif(request()->path() == 'user/buy-request/pending-orders'): ?> red 
            <?php elseif(request()->path() == 'user/buy-request/confirm-orders'): ?> red 
            <?php elseif(request()->path() == 'user/buy-request/cancel-orders'): ?>
            red <?php else: ?> teal <?php endif; ?>
            
            "> <a class="white-text" href="<?php echo e(route('user.buy-request',['type'=>'all-orders'])); ?>"> <i class="fa fa-spinner"></i> Buy Request </a></li>
            <li class="collection-item"> <i class="fa fa-cog"></i> Change Password</li>
          </ul>
        </div>

        <div class="col m8 s12">
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px"><?php echo e($pageTitle); ?> </div>
          <br>

          <a class="waves-effect waves-light btn" href="<?php echo e(route('user.sell-request',['type'=>'pending-orders'])); ?>">Pending</a>/
          <a class="waves-effect waves-light btn" href="<?php echo e(route('user.sell-request',['type'=>'confirm-orders'])); ?>">Confirm</a>/
          <a class="waves-effect waves-light btn" href="<?php echo e(route('user.sell-request',['type'=>'cancel-orders'])); ?>">Cancel</a>


          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <?php if($sellBook->all()): ?> <?php $__currentLoopData = $sellBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(date('Y-m-d'),strtotime($item->created_at)); ?></td>
                <td>
                  <?php if($item->order_status == 0): ?> Pending <?php elseif($item->order_status == 1): ?> Confirm <?php elseif($item->order_status == 2): ?> Cancel
                  <?php endif; ?>

                </td>
                <td>
                  <a href="<?php echo e(route('user.sell-request.detail',$item->id)); ?>"> <i class="fa fa-eye"></i> view</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
              <tr>
                <td colspan="3">
                  <h4 class="center-align red-text">No Record Found......</h4>
                </td>
              </tr>
            </tbody>
            <?php endif; ?>


          </table>



        </div>

      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>