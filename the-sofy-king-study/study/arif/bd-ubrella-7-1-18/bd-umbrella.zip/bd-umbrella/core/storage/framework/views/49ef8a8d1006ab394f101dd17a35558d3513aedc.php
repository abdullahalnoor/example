<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
  <!-- Twitter meta-->
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:site" content="@pratikborsadiya">
  <meta property="twitter:creator" content="@pratikborsadiya">
  <!-- Open Graph Meta-->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Vali Admin">
  <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
  <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
  <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
  <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
  <title> BD-Umbrella | <?php echo $__env->yieldContent('title'); ?></title>

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Main CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/main.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/toastr.min.css')); ?>">
  <!-- Font-icon css-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/font-awesome.min.css')); ?>"> <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body class="app sidebar-mini rtl">


  <!-- Navbar-->
  <?php echo $__env->make('admin.includes._navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Sidebar menu-->
  <?php echo $__env->make('admin.includes._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <main class="app-content">
    <?php echo $__env->yieldContent('content'); ?>
  </main>



  <!-- Essential javascripts for application to work-->
  <script src="<?php echo e(asset('assets/admin/js/jquery-3.2.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>
  <!-- The javascript plugin to display page loading on top-->
  <script src="<?php echo e(asset('assets/admin/js/plugins/pace.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('assets/admin/js/toastr.min.js')); ?>"></script>
  <!-- Google analytics script-->
  <script type="text/javascript">
    if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
  </script>
  <?php echo Toastr::render(); ?> <?php echo $__env->yieldPushContent('js'); ?>


</body>

</html>