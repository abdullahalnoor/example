<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>BD-Umbrella</title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/materialize.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">



</head>

<body>
  <?php echo $__env->make('frontend.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('frontend.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>






  <script src="<?php echo e(asset('assets/frontend/js/materialize.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.min.js')); ?>"></script>
  <script>
    var sideNav = document.querySelector('.sidenav');
    M.Sidenav.init(sideNav, {});
    document.addEventListener('DOMContentLoaded', function() { var elems = document.querySelectorAll('.dropdown-trigger-one'); var
    instances = M.Dropdown.init(elems, {}); });
    document.addEventListener('DOMContentLoaded', function() { var elems = document.querySelectorAll('.dropdown-trigger-two');
    var instances = M.Dropdown.init(elems, {}); });
  </script>

  <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>