<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
  <div class="app-sidebar__user">
    <i class="fa fa-umbrella" style="font-size:30px;padding:5px;"></i>
    <div>
      <p class="app-sidebar__user-name">Welcome</p>
      <p class="app-sidebar__user-designation text-right" style="text-transform:capitalize;">
        <em><?php echo e(Auth::guard('admin')->user()->name); ?></em>
      </p>
    </div>
  </div>
  <ul class="app-menu">
    <li>
      <a class="app-menu__item" href="index.html">
        <i class="app-menu__icon fa fa-dashboard"></i>
        <span class="app-menu__label">Dashboard</span>
      </a>
    </li>

    <li class="treeview">
      <a class="app-menu__item <?php if(request()->path() == 'admin/general-setting'): ?>
      active  <?php endif; ?>" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-laptop"></i>
        <span class="app-menu__label">Website Control</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item <?php if(request()->path() == 'admin/general-setting'): ?>
          active <?php endif; ?>" href="<?php echo e(route('admin.general-setting')); ?>">
            <i class="icon fa fa-circle-o"></i> General Setting </a>
        </li>
        <li>
          <a class="treeview-item" href="<?php echo e(route('admin.rules-setting')); ?>">
            <i class="icon fa fa-circle-o"></i> Rules Setting</a>
        </li>
        <li>
          <a class="treeview-item" href="#">
            <i class="icon fa fa-circle-o"></i> SMS Setting</a>
        </li>
      </ul>
    </li>

    <li class="treeview">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-umbrella"></i>
        <span class="app-menu__label">Interface Control</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item" href="<?php echo e(route('admin.social-link')); ?>">
            <i class="icon fa fa-circle-o"></i> Social Link </a>
        </li>
        <li>
          <a class="treeview-item" href="#">
            <i class="icon fa fa-circle-o"></i> Category </a>
        </li>
        <li>
          <a class="treeview-item" href="#">
            <i class="icon fa fa-circle-o"></i> SMS Setting</a>
        </li>
      </ul>
    </li>


    <li class="treeview
    <?php if(request()->path() == 'admin/sell/all-orders'): ?> is-expanded
    <?php elseif(request()->path() == 'admin/sell/pending-orders'): ?> is-expanded
    <?php elseif(request()->path() == 'admin/sell/confirm-orders'): ?> is-expanded
    <?php elseif(request()->path() == 'admin/sell/cancel-orders'): ?> is-expanded
    <?php endif; ?>
    ">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-cart-plus"></i>
        <span class="app-menu__label">Sell Management </span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item
          <?php if(request()->path() == 'admin/sell/all-orders'): ?> active
          <?php endif; ?>
          " href="<?php echo e(route('admin.sell-orders',['type'=>'all-orders'])); ?>">
            <i class="icon fa fa-circle-o"></i> All Orders </a>
        </li>
        <li>
          <a class="treeview-item
          <?php if(request()->path() == 'admin/sell/pending-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.sell-orders',['type'=>'pending-orders'])); ?>">
            <i class="icon fa fa-check"></i> Pending Orders </a>
        </li>
        <li>
          <a class="treeview-item
          <?php if(request()->path() == 'admin/sell/confirm-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.sell-orders',['type'=>'confirm-orders'])); ?>">
            <i class="icon fa fa-times"></i> Confirm Orders</a>
        </li>
        <li>
          <a class="treeview-item
          <?php if(request()->path() == 'admin/sell/cancel-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.sell-orders',['type'=>'cancel-orders'])); ?>">
            <i class="icon fa fa-ban"></i> Cancel Orders</a>
        </li>
      </ul>
    </li>


    <li class="treeview
    <?php if(request()->path() == 'admin/buy/all-orders'): ?> is-expanded 
    <?php elseif(request()->path() == 'admin/buy/pending-orders'): ?> is-expanded
    <?php elseif(request()->path() == 'admin/buy/confirm-orders'): ?> is-expanded 
    <?php elseif(request()->path() == 'admin/buy/cancel-orders'): ?>
    is-expanded <?php endif; ?>
    ">
      <a class="app-menu__item" href="#" data-toggle="treeview">
              <i class="app-menu__icon fa fa-shopping-cart"></i>
              <span class="app-menu__label">Buy Management </span>
              <i class="treeview-indicator fa fa-angle-right"></i>
            </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item
          <?php if(request()->path() == 'admin/buy/all-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.view.buy-orders',['type'=>'all-orders'])); ?>">
                  <i class="icon fa fa-circle-o"></i> All Orders </a>
        </li>
        <li>
          <a class="treeview-item 
          <?php if(request()->path() == 'admin/buy/pending-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.view.buy-orders',['type'=>'pending-orders'])); ?>">
                  <i class="icon fa fa-check"></i> Pending Orders </a>
        </li>
        <li>
          <a class="treeview-item 
          <?php if(request()->path() == 'admin/buy/confirm-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.view.buy-orders',['type'=>'confirm-orders'])); ?>">
                  <i class="icon fa fa-times"></i> Confirm Orders</a>
        </li>
        <li>
          <a class="treeview-item 
          <?php if(request()->path() == 'admin/buy/cancel-orders'): ?> active <?php endif; ?>
          " href="<?php echo e(route('admin.view.buy-orders',['type'=>'cancel-orders'])); ?>">
                  <i class="icon fa fa-ban"></i> Cancel Orders</a>
        </li>
      </ul>
    </li>





    <li class="treeview">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-users"></i>
        <span class="app-menu__label">User Management </span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item" href="<?php echo e(route('admin.view.users',['type'=>'all-users'])); ?>">
            <i class="icon fa fa-circle-o"></i> All Users </a>
        </li>
        <li>
          <a class="treeview-item" href="<?php echo e(route('admin.view.users',['type'=>'verified-users'])); ?>">
            <i class="icon fa fa-check"></i> Verified Users </a>
        </li>
        <li>
          <a class="treeview-item" href="<?php echo e(route('admin.view.users',['type'=>'unverified-users'])); ?>">
            <i class="icon fa fa-times"></i> Unverified Users</a>
        </li>
        <li>
          <a class="treeview-item" href="<?php echo e(route('admin.view.users',['type'=>'banned-users'])); ?>">
            <i class="icon fa fa-ban"></i> Banned Users</a>
        </li>
      </ul>
    </li>




  </ul>
</aside>