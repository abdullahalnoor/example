 
<?php $__env->startSection('content'); ?>

<div class="main-content">
  <div class="row">
    <article class="article-side">
      <div class="container">
        <div class="col m4 hide-on-small-only">
          <ul class="collection">
            <li class="collection-item  <?php if(request()->path() == 'user/home'): ?> red <?php else: ?> teal  <?php endif; ?> "> <a class="white-text" href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> Profile</a></li>
            <li class="collection-item 
                      <?php if(request()->path() == 'user/sell-request/all-orders'): ?> red            
                      <?php elseif(request()->path() == 'user/sell-request/pending-orders'): ?> red            
                      <?php elseif(request()->path() == 'user/sell-request/confirm-orders'): ?> red            
                      <?php elseif(request()->path() == 'user/sell-request/cancel-orders'): ?> red 
                      <?php else: ?> 
                      teal
                       <?php endif; ?>"> <a class="white-text" href="<?php echo e(route('user.sell-request',['type'=>'all-orders'])); ?>"><i class="fa fa-spinner"></i> Sell Request</a></li>
            <li class="collection-item
                      <?php if(request()->path() == 'user/buy-request/all-orders'): ?> red 
                      <?php elseif(request()->path() == 'user/buy-request/pending-orders'): ?> red 
                      <?php elseif(request()->path() == 'user/buy-request/confirm-orders'): ?> red 
                      <?php elseif(request()->path() == 'user/buy-request/cancel-orders'): ?>
                      red <?php else: ?> teal <?php endif; ?>
                      
                      "> <a class="white-text" href="<?php echo e(route('user.buy-request',['type'=>'all-orders'])); ?>"> <i class="fa fa-spinner"></i> Buy Request </a></li>
            <li class="collection-item teal"> <a class="white-text" href=""><i class="fa fa-cog"></i> Change Password</a> </li>
          </ul>
        </div>

        <div class="col m8 s12">
          <div class=" teal lighten-2 align-center" style="font-size:25px;padding:7px">Personal Information </div>
          <table>
            <tr>
              <td>Name</td>
              <td><?php echo e(Auth::user()->name); ?></td>
            </tr>
            <tr>
              <td>Father Name</td>
              <td><?php echo e(Auth::user()->father_name); ?></td>
            </tr>
            <tr>
              <td>Mother Name</td>
              <td><?php echo e(Auth::user()->mother_name); ?></td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>
                <?php if(Auth::user()->gender == 1): ?> Male <?php elseif(Auth::user()->gender == 2): ?> Female <?php elseif(Auth::user()->gender == 3): ?> Others <?php endif; ?>
              </td>
            </tr>
            <tr>
              <td>Permanent Address</td>
              <td><?php echo e(Auth::user()->permanent_address); ?></td>
            </tr>
            <tr>
              <td>Present Address</td>
              <td><?php echo e(Auth::user()->present_address); ?></td>
            </tr>
            <tr>
              <td>Contact Number</td>
              <td><?php echo e(Auth::user()->contact_number); ?></td>
            </tr>
            <tr>
              <td>Reference Contact Number</td>
              <td><?php echo e(Auth::user()->reference_contact_number); ?></td>
            </tr>
            <tr>
              <td>Birth Date</td>
              <td><?php echo e(Auth::user()->birth_date); ?></td>
            </tr>
            <tr>
              <td>Institue Name</td>
              <td><?php echo e(Auth::user()->institue_name); ?></td>
            </tr>
            <tr>
              <td>Department Name</td>
              <td><?php echo e(Auth::user()->department_name); ?></td>
            </tr>
            <tr>
              <td>Email</td>
              <td><?php echo e(Auth::user()->email); ?></td>
            </tr>
            <tr>
              <td>Username</td>
              <td><?php echo e(Auth::user()->username); ?></td>
            </tr>
          </table>
        </div>

      </div>


    </article>



  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>